Unzip to your QBasic folder or a different folder or make a game folder and unzip files into it.

NOTE: This game requires graphics files created by any accompanying .bas programs in the zip file. If two or more accompanying .bas files are present, run the first on only. It will automatically chain (run) the second file. After you run the accompanying .bas file, the main program ready to use!
