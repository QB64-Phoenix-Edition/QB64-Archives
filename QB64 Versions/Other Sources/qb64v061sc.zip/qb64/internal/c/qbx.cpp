/*
cost is the estimated cpu cost of executing a block of code
cost is incremented if:
i) a loop/branch in the code is reached (calls a function)
ii) the compiler's calculated cost reaches a threshhold (after any statement)

the cost of a regular equation containing no special functions should
be considered 1
a regular statement used for comparison could be
a%=10.3!*4.4#+y&

a posible implementation could be...
if ((cost+=100)>65536){cost=0; SleepEx(10,0);}
                ^a suggested threshold value is 65536

if ((cost+=100)>65536){cost=0; SleepEx(10,0);}


*/

//WINDOWS SPECIFIC CONTENT
#include "stdafx2.h"
#include "winbase.h"
//END WINDOWS SPECIFIC CONTENT

//#include "stdafx.h"
#include "SDL.h"
#include "SDL_audio.h"
#include "SDL_thread.h"
#include "math.h"
#include "time.h"
#include <iostream>
#include <fstream>
using namespace std;



#include "SDL_mixer.h"



SDL_Thread *thread;






#define cost_limit 10000
#define cost_delay 0
unsigned long cost=0;

//WINDOWS SPECIFIC CONTENT
inline void SDL_Delay(Uint32 milliseconds){
Sleep(milliseconds);
}
//END WINDOWS SPECIFIC CONTENT

#include "msbin.c"
#include "bit.cpp"

int QBMAIN(void *unused);

__int64 build_int64(unsigned long val2,unsigned long val1){
static __int64 val;
val=val2;
val<<=32;
val|=val1;
return val;
}

unsigned __int64 build_uint64(unsigned long val2,unsigned long val1){
static unsigned __int64 val;
val=val2;
val<<=32;
val|=val1;
return val;
}


struct byte_element_struct
{
unsigned __int64 offset;
unsigned long length;
};




//nb. abreviations are used in variable names to save typing, here are some of the expansions
//cmem=conventional memory
//qbs=qbick basic string (refers to the emulation of quick basic strings)
//sp=stack pointer
//dblock=a 64K memory block in conventional memory holding single variables and strings
unsigned char cmem[1114098];//16*65535+65535+3 (enough for highest referencable dword in conv memory)
unsigned char *cmem_static_pointer=&cmem[0]+1280+65536;
unsigned char *cmem_static_base=&cmem[0]+1280+65536;
unsigned char *cmem_dynamic_base=&cmem[0]+655360;
//[1280][DBLOCK][STATIC-><-DYNAMIC][A000-]

unsigned long qbs_cmem_descriptor_space=256; //enough for 64 strings before expansion
unsigned long qbs_cmem_sp=256;
unsigned long cmem_sp=65536;
unsigned long dblock;//32bit offset of dblock
unsigned __int64 *nothingvalue;



unsigned long qb64_firsttimervalue;
unsigned long sdl_firsttimervalue;

unsigned char qbevent=0;
unsigned char wait_needed=1;

SDL_Surface * screen;
unsigned char full_screen=0;
unsigned char full_screen_in_use=0;

long vertical_retrace_in_progress=0;
long vertical_retrace_happened=0;


inline __int64 qbr(long double f){if (f<0) return(f-0.5f); else return(f+0.5f);}
inline unsigned __int64 qbr_longdouble_to_uint64(long double f){if (f<0) return(f-0.5f); else return(f+0.5f);}
inline long qbr_float_to_long(float f){if (f<0) return(f-0.5f); else return(f+0.5f);}
inline long qbr_double_to_long(double f){if (f<0) return(f-0.5f); else return(f+0.5f);}

static const char *arrow[] = {
  /* width height num_colors chars_per_pixel */
  "    32    32        3            1",
  /* colors */
  "X c #000000",
  ". c #ffffff",
  "  c None",
  /* pixels */
"X                               ",
"XX                              ",
"X.X                             ",
"X..X                            ",
"X...X                           ",
"X....X                          ",
"X.....X                         ",
"X......X                        ",
"X.......X                       ",
"X........X                      ",
"X.........X                     ",
"X......XXXXX                    ",
"X...X..X                        ",
"X..XX..X                        ",
"X.X  X..X                       ",
"XX   X..X                       ",
"X     X..X                      ",
"      X..X                      ",
"       X..X                     ",
"       X..X                     ",
"        XX                      ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
  "0,0"
};

static SDL_Cursor *init_system_cursor(const char *image[])
{
  int i, row, col;
  Uint8 data[4*32];
  Uint8 mask[4*32];
  int hot_x, hot_y;

  i = -1;
  for ( row=0; row<32; ++row ) {
    for ( col=0; col<32; ++col ) {
      if ( col % 8 ) {
        data[i] <<= 1;
        mask[i] <<= 1;
      } else {
        ++i;
        data[i] = mask[i] = 0;
      }
      switch (image[4+row][col]) {
        case 'X':
          data[i] |= 0x01;
          mask[i] |= 0x01;//?
          break;
        case '.':
          mask[i] |= 0x01;
          break;
        case ' ':
          break;
      }
    }
  }
  sscanf(image[4+row], "%d,%d", &hot_x, &hot_y);
  return SDL_CreateCursor(data, mask, 32, 32, hot_x, hot_y);
}



unsigned char lock_subsystem=0;
unsigned char stop_program=0;
unsigned char close_program=0;
unsigned char program_wait=0;
unsigned char suspend_program=0;

long global_counter=0;

double last_line=0;

unsigned long error_err=0;
double error_erl=0;

unsigned long error_retry=0;

unsigned long error_occurred=0;
unsigned long error_goto_line=0;
unsigned long error_handling=0;

void error(unsigned long err){

if ((!error_goto_line)||error_handling){
long v;
v=0;
if (err==1) v=MessageBox(NULL,"NEXT without FOR\nContinue?","Unhandled Error #1",MB_YESNO);
if (err==2) v=MessageBox(NULL,"Syntax error\nContinue?","Unhandled Error #2",MB_YESNO);
if (err==3) v=MessageBox(NULL,"RETURN without GOSUB\nContinue?","Unhandled Error #3",MB_YESNO);
if (err==4) v=MessageBox(NULL,"Out of DATA\nContinue?","Unhandled Error #4",MB_YESNO);
if (err==5) v=MessageBox(NULL,"Illegal function call\nContinue?","Unhandled Error #5",MB_YESNO);
if (err==6) v=MessageBox(NULL,"Overflow\nContinue?","Unhandled Error #6",MB_YESNO);
if (err==7) v=MessageBox(NULL,"Out of memory\nContinue?","Unhandled Error #7",MB_YESNO);
if (err==8) v=MessageBox(NULL,"Label not defined\nContinue?","Unhandled Error #8",MB_YESNO);
if (err==9) v=MessageBox(NULL,"Subscript out of range\nContinue?","Unhandled Error #9",MB_YESNO);
if (err==10) v=MessageBox(NULL,"Duplicate definition\nContinue?","Unhandled Error #10",MB_YESNO);
if (err==11) v=MessageBox(NULL,"Division by zero\nContinue?","Unhandled Error #11",MB_YESNO);
if (err==12) v=MessageBox(NULL,"Illegal in direct mode\nContinue?","Unhandled Error #12",MB_YESNO);
if (err==13) v=MessageBox(NULL,"Type mismatch\nContinue?","Unhandled Error #13",MB_YESNO);
if (err==14) v=MessageBox(NULL,"Out of string space\nContinue?","Unhandled Error #14",MB_YESNO);
//err 15 undefined
if (err==16) v=MessageBox(NULL,"String formula too complex\nContinue?","Unhandled Error #16",MB_YESNO);
if (err==17) v=MessageBox(NULL,"Cannot continue\nContinue?","Unhandled Error #17",MB_YESNO);
if (err==18) v=MessageBox(NULL,"Function not defined\nContinue?","Unhandled Error #18",MB_YESNO);
if (err==19) v=MessageBox(NULL,"No RESUME\nContinue?","Unhandled Error #19",MB_YESNO);
if (err==20) v=MessageBox(NULL,"RESUME without error\nContinue?","Unhandled Error #20",MB_YESNO);
//err 21-23 undefined
if (err==24) v=MessageBox(NULL,"Device timeout\nContinue?","Unhandled Error #24",MB_YESNO);
if (err==25) v=MessageBox(NULL,"Device fault\nContinue?","Unhandled Error #25",MB_YESNO);
if (err==26) v=MessageBox(NULL,"FOR without NEXT\nContinue?","Unhandled Error #26",MB_YESNO);
if (err==27) v=MessageBox(NULL,"Out of paper\nContinue?","Unhandled Error #27",MB_YESNO);
//err 28 undefined
if (err==29) v=MessageBox(NULL,"WHILE without WEND\nContinue?","Unhandled Error #28",MB_YESNO);
if (err==30) v=MessageBox(NULL,"WEND without WHILE\nContinue?","Unhandled Error #29",MB_YESNO);
//err 31-32 undefined
if (err==33) v=MessageBox(NULL,"Duplicate label\nContinue?","Unhandled Error #33",MB_YESNO);
//err 34 undefined
if (err==35) v=MessageBox(NULL,"Subprogram not defined\nContinue?","Unhandled Error #35",MB_YESNO);
if (err==37) v=MessageBox(NULL,"Argument-count mismatch\nContinue?","Unhandled Error #37",MB_YESNO);
if (err==38) v=MessageBox(NULL,"Array not defined\nContinue?","Unhandled Error #38",MB_YESNO);
if (err==40) v=MessageBox(NULL,"Variable required\nContinue?","Unhandled Error #40",MB_YESNO);
if (err==50) v=MessageBox(NULL,"FIELD overflow\nContinue?","Unhandled Error #50",MB_YESNO);
if (err==51) v=MessageBox(NULL,"Internal error\nContinue?","Unhandled Error #51",MB_YESNO);
if (err==52) v=MessageBox(NULL,"Bad file name or number\nContinue?","Unhandled Error #52",MB_YESNO);
if (err==53) v=MessageBox(NULL,"File not found\nContinue?","Unhandled Error #53",MB_YESNO);
if (err==54) v=MessageBox(NULL,"Bad file mode\nContinue?","Unhandled Error #54",MB_YESNO);
if (err==55) v=MessageBox(NULL,"File already open\nContinue?","Unhandled Error #55",MB_YESNO);
if (err==56) v=MessageBox(NULL,"FIELD statement active\nContinue?","Unhandled Error #56",MB_YESNO);
if (err==57) v=MessageBox(NULL,"Device I/O error\nContinue?","Unhandled Error #57",MB_YESNO);
if (err==58) v=MessageBox(NULL,"File already exists\nContinue?","Unhandled Error #58",MB_YESNO);
if (err==59) v=MessageBox(NULL,"Bad record length\nContinue?","Unhandled Error #59",MB_YESNO);
if (err==61) v=MessageBox(NULL,"Disk full\nContinue?","Unhandled Error #61",MB_YESNO);
if (err==62) v=MessageBox(NULL,"Input past end of file\nContinue?","Unhandled Error #62",MB_YESNO);
if (err==63) v=MessageBox(NULL,"Bad record number\nContinue?","Unhandled Error #63",MB_YESNO);
if (err==64) v=MessageBox(NULL,"Bad file name\nContinue?","Unhandled Error #64",MB_YESNO);
if (err==67) v=MessageBox(NULL,"Too many files\nContinue?","Unhandled Error #67",MB_YESNO);
if (err==68) v=MessageBox(NULL,"Device unavailable\nContinue?","Unhandled Error #68",MB_YESNO);
if (err==69) v=MessageBox(NULL,"Communication-buffer overflow\nContinue?","Unhandled Error #69",MB_YESNO);
if (err==70) v=MessageBox(NULL,"Permission denied\nContinue?","Unhandled Error #70",MB_YESNO);
if (err==71) v=MessageBox(NULL,"Disk not ready\nContinue?","Unhandled Error #71",MB_YESNO);
if (err==72) v=MessageBox(NULL,"Disk-media error\nContinue?","Unhandled Error #72",MB_YESNO);
if (err==73) v=MessageBox(NULL,"Feature unavailable\nContinue?","Unhandled Error #73",MB_YESNO);
if (err==74) v=MessageBox(NULL,"Rename across disks\nContinue?","Unhandled Error #74",MB_YESNO);
if (err==75) v=MessageBox(NULL,"Path/File access error\nContinue?","Unhandled Error #75",MB_YESNO);
if (err==76) v=MessageBox(NULL,"Path not found\nContinue?","Unhandled Error #76",MB_YESNO);
if (err==256) v=MessageBox(NULL,"Out of stack space","Critical Error",MB_OK);
if (err==257) v=MessageBox(NULL,"Out of memory","Critical Error",MB_OK);

if (v==0) v=MessageBox(NULL,"Unprintable error\nContinue?","Unhandled Error",MB_YESNO);
if ((v==IDNO)||(v==IDOK)) exit(0);//hard exit
return;
}

error_err=err;
error_erl=last_line;
error_occurred=1;
QBMAIN(NULL);
return;
}

double get_error_erl(){
return error_erl;
}

unsigned long get_error_err(){
return error_err;
}

void end(void){
while(!stop_program) Sleep(100);
SDL_KillThread(thread);
while(1) Sleep(100);
}



//MEM_STATIC memory manager
/*
mem_static uses a pointer called mem_static_pointer to allocate linear memory.
It can also change mem_static_pointer back to a previous location, effectively erasing
any memory after that point.
Because memory cannot be guaranteed to be allocated in exactly the same location
after realloc which QB64 requires to keep functionality of previous pointers when
the current block of memory is full QB64 creates an entirely new block, much larger
than the previous block (at least 2x), and "writes-off" the previous block as un-
reclaimable memory. This tradeoff is worth the speed it recovers.
This allocation strategy can be shown as follows: (X=1MB)
X
XX
XXXX
XXXXXXXX
XXXXXXXXXXXXXXXX
etc.
*/
unsigned long mem_static_size;
unsigned char *mem_static;
unsigned char *mem_static_pointer;
unsigned char *mem_static_limit;
inline unsigned char *mem_static_malloc(unsigned long size){
if ((mem_static_pointer+=size)<mem_static_limit) return mem_static_pointer-size;
mem_static_size=(mem_static_size<<1)+size;
mem_static=(unsigned char*)malloc(mem_static_size);
if (!mem_static) error(257);
mem_static_pointer=mem_static+size;
mem_static_limit=mem_static+mem_static_size;
return mem_static_pointer-size;
}
inline void mem_static_restore(unsigned char* restore_point){
if ((restore_point>=mem_static)&&(restore_point<=mem_static_limit)){
mem_static_pointer=restore_point;
}else{
//if restore_point is not in the current block, use t=start of current block as a new base
mem_static_pointer=mem_static;
}
}

//CMEM_FAR_DYNAMIC memory manager
/*
(uses a custom "links" based memory manager)
*/
//           &HA000    DBLOCK SIZE        DBLOCK OFFSET
//           655360 - (65536            + 1280         )=588544 links possible
//links limited to 588544/4=147136 (do not have enough links if avg. block size less than 4 bytes)
//stores blocks, not free memory, because blocks are easier to identify
//always scanned from beginning to end, so prev. pointer is unnecessary
struct cmem_dynamic_link_type{
unsigned char *offset;
unsigned char *top;
unsigned long size;
unsigned long i;
cmem_dynamic_link_type *next;
};
cmem_dynamic_link_type cmem_dynamic_link[147136+1]; //+1 is added because array is used from index 1
cmem_dynamic_link_type *cmem_dynamic_link_first=NULL;
long cmem_dynamic_next_link=0;
long cmem_dynamic_free_link=0;
unsigned long cmem_dynamic_free_list[147136];
unsigned char *cmem_dynamic_malloc(unsigned long size){
static long i;
static unsigned char *top;
static cmem_dynamic_link_type *link;
static cmem_dynamic_link_type *newlink;
if (size>65536) error(257);//>64K
top=&cmem[0]+655360;
if (link=cmem_dynamic_link_first){
cmem_dynamic_findspace:
top=link->offset;
if ((top-link->top)>=size){
//found free space
goto cmem_dynamic_make_new_link;
}
if (link=link->next) goto cmem_dynamic_findspace;
}
//no space between existing blocks is large enough
if ((top-cmem_static_pointer)<size) error(257);//a large enough block cannot be created!
cmem_dynamic_base=top-size;
cmem_dynamic_make_new_link:
if (cmem_dynamic_free_link){
i=cmem_dynamic_free_list[cmem_dynamic_free_link--];
}else{
i=cmem_dynamic_next_link++; if (i>=147136) error(257);//not enough blocks
}
newlink=(cmem_dynamic_link_type*)&cmem_dynamic_link[i];
newlink->i=i;
newlink->offset=top-size;
newlink->size=size;
newlink->top=top;
if (cmem_dynamic_link_first){
newlink->next=link->next;
link->next=newlink;
}else{
cmem_dynamic_link_first=newlink;
newlink->next=NULL;
}
return newlink->offset;
}
void cmem_dynamic_free(unsigned char *block){
static cmem_dynamic_link_type *link;
static cmem_dynamic_link_type *prev_link;
prev_link=NULL;
if (link=cmem_dynamic_link_first){
check_next:
if (link->offset==block){
//unlink
if (link->next){
if (prev_link) prev_link->next=link->next; else cmem_dynamic_link_first=link->next;
}else{
if (prev_link) prev_link->next=NULL; else cmem_dynamic_link_first=NULL;
}
//free link
cmem_dynamic_free_link++;
cmem_dynamic_free_list[cmem_dynamic_free_link]=link->i;
//memory freed successfully!
return;
}
prev_link=link;
if (link=link->next) goto check_next;
}
return;
}

unsigned char *defseg=&cmem[1280];//set to base of DBLOCK

void sub_defseg(long segment,long passed){
if (!passed){
defseg=&cmem[1280];
return;
}
if ((segment<-65536)||(segment>65535)){//same range as QB checks
error(6);
}else{
defseg=&cmem[0]+((unsigned short)segment)*16;
}
}

long func_peek(long offset){
if ((offset<-65536)||(offset>65535)){//same range as QB checks
error(6);
return 0;
}
return defseg[(unsigned short)offset];
}

void sub_poke(long offset,long value){
if ((offset<-65536)||(offset>65535)){//same range as QB checks
error(6);
return;
}
defseg[(unsigned short)offset]=value;
}

long array_ok=1;//1=no overflow, 0=overflow has occurred
inline long array_check(unsigned long index,unsigned long limit){
//nb. forces signed index into an unsigned variable for quicker comparison
if (index<limit) return index;
if (array_ok){
array_ok=0;
error(9);
}
return 0;
}

//gosub-return handling
unsigned long next_return_point=0;
unsigned long *return_point=(unsigned long*)malloc(4*16384);
unsigned long return_points=16384;
void more_return_points(){
if (return_points>2147483647) error(256);
return_points*=2;
return_point=(unsigned long*)realloc(return_point,return_points*4);
if (return_point==NULL) error(256);
}


unsigned long sndqueue[10000];
long sndqueue_next=0;
long sndqueue_first=0;
long sndqueue_lastindex=9999;
long sndqueue_wait=-1;
long sndqueue_played=0;

unsigned long func__sndraw(unsigned char* data,unsigned long bytes);
void sub__sndplay(unsigned long);
void qb64_generatesound(double f,double l,unsigned char wait){


//f=frequency (ie. waves per second)
//l=length in seconds
//always creates a triangular wave
static short shortval;
static long i;
static short *p,*firstp;
static long s;//number of samples needed
static long b;//bytes needed
static double v;
static long dir;
static double rate;//rate of change per sample
s=l*22050.0; s++;//samples
b=s*4;
p=(short*)malloc(b);
firstp=p;
v=0;
dir=1;//up
//rate=number of ossilations in one second*distance per ossilation/samples per sec
//note:131072=32768*4
rate=f*131072.0/22050.0;
for (i=0;i<s;i++){
shortval=((long)v)-32768;
*p=shortval;
p++;
*p=shortval;
p++;
if (dir){
v+=rate;
if (v>=65536.0){v=65536.0-(v-65536.0); dir=0;}
}else{
v-=rate;
if (v<0.0){v=-v; dir=1;}
}
}//i
static unsigned long handle=NULL;
handle=func__sndraw((unsigned char*)firstp,b);
if (handle){
if (wait){
sndqueue_wait=sndqueue_next;
suspend_program|=2;
qbevent=1;
}
sndqueue[sndqueue_next]=handle;
sndqueue_next++; if (sndqueue_next>sndqueue_lastindex) sndqueue_next=0;
}
}



unsigned char keyon[65536];



struct qbs
{
unsigned char *chr; //a 32 bit pointer to the string's data
unsigned long len;
unsigned char in_cmem; //set to 1 if in the conventional memory DBLOCK
unsigned short *cmem_descriptor;
unsigned short cmem_descriptor_offset;
unsigned long listi; //the index in the list of strings that references it
unsigned char tmp; //set to 1 if the string can be deleted immediately after being processed
unsigned long tmplisti; //the index in the list of strings that references it
unsigned char fixed; //fixed length string
unsigned char readonly; //set to 1 if string is read only
};
qbs* nothingstring;
qbs* tqbs;

qbs *qbs_malloc=(qbs*)calloc(sizeof(qbs)*65536,1);//~1MEG
unsigned long qbs_malloc_next=0;//the next idex in qbs_malloc to use
unsigned long *qbs_malloc_freed=(unsigned long*)malloc(4*65536);
unsigned long qbs_malloc_freed_size=65536;
unsigned long qbs_malloc_freed_num=0;//number of freed qbs descriptors
qbs *qbs_new_descriptor(){
if (qbs_malloc_freed_num){
return (qbs*)memset((void *)qbs_malloc_freed[--qbs_malloc_freed_num],0,sizeof(qbs));
}
if (qbs_malloc_next==65536){
qbs_malloc=(qbs*)calloc(sizeof(qbs)*65536,1);//~1MEG
qbs_malloc_next=0;
}
return &qbs_malloc[qbs_malloc_next++];
}
void qbs_free_descriptor(qbs *str){
if (qbs_malloc_freed_num==qbs_malloc_freed_size){
 qbs_malloc_freed_size*=2;
 qbs_malloc_freed=(unsigned long*)realloc(qbs_malloc_freed,qbs_malloc_freed_size*4);
 if (!qbs_malloc_freed) error(257);
}
qbs_malloc_freed[qbs_malloc_freed_num]=(unsigned long)str;
qbs_malloc_freed_num++;
return;
}

//Used to track strings in 16bit memory
unsigned long *qbs_cmem_list=(unsigned long*)malloc(65536*4);
unsigned long  qbs_cmem_list_lasti=65535;
unsigned long  qbs_cmem_list_nexti=0;
//Used to track strings in 32bit memory
unsigned long *qbs_list=(unsigned long*)malloc(65536*4);
unsigned long  qbs_list_lasti=65535;
unsigned long  qbs_list_nexti=0;
//Used to track temporary strings for later removal when they fall out of scope
//*Some string functions delete a temporary string automatically after they have been
// passed one to save memory. In this case qbstring_templist[?]=0xFFFFFFFF
unsigned long *qbs_tmp_list=(unsigned long*)calloc(65536*4,1);//first index MUST be 0
unsigned long  qbs_tmp_list_lasti=65535;
unsigned long  qbs_tmp_list_nexti=1;
//entended string memory

unsigned char *qbs_data=(unsigned char*)malloc(1048576);
unsigned long qbs_data_size=1048576;
unsigned long qbs_sp=0;

void qbs_free(qbs *str){
if (str->tmplisti){
 qbs_tmp_list[str->tmplisti]=0xFFFFFFFF;
 while (qbs_tmp_list[qbs_tmp_list_nexti-1]==0xFFFFFFFF){
 qbs_tmp_list_nexti--;
 }
}
if (str->fixed||str->readonly){
 qbs_free_descriptor(str);
 return;
}
if (str->in_cmem){
 qbs_cmem_list[str->listi]=0xFFFFFFFF;
 if ((qbs_cmem_list_nexti-1)==str->listi) qbs_cmem_list_nexti--;
}else{
 qbs_list[str->listi]=0xFFFFFFFF;
 retry:
 if (qbs_list[qbs_list_nexti-1]==0xFFFFFFFF){
 qbs_list_nexti--;
 if (qbs_list_nexti) goto retry;
 }
 if (qbs_list_nexti){
 qbs_sp=((qbs*)qbs_list[qbs_list_nexti-1])->chr-qbs_data+((qbs*)qbs_list[qbs_list_nexti-1])->len+32;
 if (qbs_sp>qbs_data_size) qbs_sp=qbs_data_size;//adding 32 could overflow buffer!
 }else{
 qbs_sp=0;
 }
}
qbs_free_descriptor(str);
return;
}

void qbs_cmem_concat_list(){
unsigned long i;
unsigned long d;
qbs *tqbs;
d=0;
for (i=0;i<qbs_cmem_list_nexti;i++){
 if (qbs_cmem_list[i]!=0xFFFFFFFF){ 
  if (i!=d){  
   tqbs=(qbs*)qbs_cmem_list[i];
   tqbs->listi=d;
   qbs_cmem_list[d]=(unsigned long)tqbs;
  }
 d++;
 }
}
qbs_cmem_list_nexti=d;
//if string listings are taking up more than half of the list array double the list array's size
if (qbs_cmem_list_nexti>=(qbs_cmem_list_lasti/2)){
qbs_cmem_list_lasti*=2;
qbs_cmem_list=(unsigned long*)realloc(qbs_cmem_list,(qbs_cmem_list_lasti+1)*4);
if (!qbs_cmem_list) error(257);
}
return;
}

void qbs_concat_list(){
unsigned long i;
unsigned long d;
qbs *tqbs;
d=0;
for (i=0;i<qbs_list_nexti;i++){
 if (qbs_list[i]!=0xFFFFFFFF){
  if (i!=d){
   tqbs=(qbs*)qbs_list[i];
   tqbs->listi=d;
   qbs_list[d]=(unsigned long)tqbs;
  }
 d++;
 }
}
qbs_list_nexti=d;
//if string listings are taking up more than half of the list array double the list array's size
if (qbs_list_nexti>=(qbs_list_lasti/2)){
qbs_list_lasti*=2;
qbs_list=(unsigned long*)realloc(qbs_list,(qbs_list_lasti+1)*4);
if (!qbs_list) error(257);
}
return;
}

void qbs_tmp_concat_list(){
if (qbs_tmp_list_nexti>=(qbs_tmp_list_lasti/2)){
qbs_tmp_list_lasti*=2;
qbs_tmp_list=(unsigned long*)realloc(qbs_tmp_list,(qbs_tmp_list_lasti+1)*4);
if (!qbs_tmp_list) error(257);
}
return;
}




void qbs_concat(unsigned long bytesrequired){
//this does not change indexing, only ->chr pointers and the location of their data
static long i;
static unsigned char *dest;
static qbs *tqbs;
dest=(unsigned char*)qbs_data;
if (qbs_list_nexti){
qbs_sp=0;
 for (i=0;i<qbs_list_nexti;i++){
  if (qbs_list[i]!=0xFFFFFFFF){
   tqbs=(qbs*)qbs_list[i];
   if ((tqbs->chr-dest)>32){
   if (tqbs->len) {memmove(dest,tqbs->chr,tqbs->len);}
   tqbs->chr=dest;       
   }
   dest=tqbs->chr+tqbs->len;
   qbs_sp=dest-qbs_data;
  }
 }
}

if (((qbs_sp*2)+(bytesrequired+32))>=qbs_data_size){
static unsigned char *oldbase;
oldbase=qbs_data;
qbs_data_size=qbs_data_size*2+bytesrequired;
qbs_data=(unsigned char*)realloc(qbs_data,qbs_data_size);
if (qbs_data==NULL) error(257);//realloc failed!
for (i=0;i<qbs_list_nexti;i++){
if (qbs_list[i]!=0xFFFFFFFF){
tqbs=(qbs*)qbs_list[i];
tqbs->chr=tqbs->chr-oldbase+qbs_data;
}
}
}
return;
}

//as the cmem stack has a limit if bytesrequired cannot be met this exits and returns an error
//the cmem stack cannot after all be extended!
//so bytesrequired is only passed to possibly generate an error, or not generate one
void qbs_concat_cmem(unsigned long bytesrequired){
//this does not change indexing, only ->chr pointers and the location of their data
long i;
unsigned char *dest;
qbs *tqbs;
dest=(unsigned char*)dblock;
qbs_cmem_sp=qbs_cmem_descriptor_space;
if (qbs_cmem_list_nexti){
 for (i=0;i<qbs_cmem_list_nexti;i++){
  if (qbs_cmem_list[i]!=0xFFFFFFFF){
   tqbs=(qbs*)qbs_cmem_list[i];
   if (tqbs->chr!=dest){
   if (tqbs->len) {memmove(dest,tqbs->chr,tqbs->len);}
   tqbs->chr=dest;
      //update cmem_descriptor [length][offset]
      if (tqbs->cmem_descriptor){tqbs->cmem_descriptor[0]=tqbs->len; tqbs->cmem_descriptor[1]=(unsigned short)(tqbs->chr-dblock);}
   }
   dest+=tqbs->len;
   qbs_cmem_sp+=tqbs->len;
  }
 }
}
if ((qbs_cmem_sp+bytesrequired)>cmem_sp) error(257);
return;
}

qbs *qbs_new_cmem(long size,unsigned char tmp){
if ((qbs_cmem_sp+size)>cmem_sp) qbs_concat_cmem(size);
qbs *newstr;
newstr=qbs_new_descriptor();
newstr->len=size;
if ((qbs_cmem_sp+size)>cmem_sp) qbs_concat_cmem(size);
newstr->chr=(unsigned char*)dblock+qbs_cmem_sp;
qbs_cmem_sp+=size;
newstr->in_cmem=1;
if (qbs_cmem_list_nexti>qbs_cmem_list_lasti) qbs_cmem_concat_list();
newstr->listi=qbs_cmem_list_nexti; qbs_cmem_list[newstr->listi]=(unsigned long)newstr; qbs_cmem_list_nexti++;
if (tmp){
if (qbs_tmp_list_nexti>qbs_tmp_list_lasti) qbs_tmp_concat_list();
newstr->tmplisti=qbs_tmp_list_nexti; qbs_tmp_list[newstr->tmplisti]=(unsigned long)newstr; qbs_tmp_list_nexti++;
newstr->tmp=1;
}else{
//alloc string descriptor in DBLOCK (4 bytes)
cmem_sp-=4; newstr->cmem_descriptor=(unsigned short*)(dblock+cmem_sp); if (cmem_sp<qbs_cmem_sp) error(257);
newstr->cmem_descriptor_offset=cmem_sp;
  //update cmem_descriptor [length][offset]
  newstr->cmem_descriptor[0]=newstr->len; newstr->cmem_descriptor[1]=(unsigned short)(newstr->chr-dblock);
}
return newstr;
}

qbs *qbs_new(long,unsigned char);

qbs *qbs_new_txt(const char *txt){
qbs *newstr;
newstr=qbs_new_descriptor();
newstr->len=strlen(txt);
newstr->chr=(unsigned char*)txt;
if (qbs_tmp_list_nexti>qbs_tmp_list_lasti) qbs_tmp_concat_list();
newstr->tmplisti=qbs_tmp_list_nexti; qbs_tmp_list[newstr->tmplisti]=(unsigned long)newstr; qbs_tmp_list_nexti++;
newstr->tmp=1;
newstr->readonly=1;
return newstr;
}

qbs *qbs_new_txt_len(const char *txt,long len){
qbs *newstr;
newstr=qbs_new_descriptor();
newstr->len=len;
newstr->chr=(unsigned char*)txt;
if (qbs_tmp_list_nexti>qbs_tmp_list_lasti) qbs_tmp_concat_list();
newstr->tmplisti=qbs_tmp_list_nexti; qbs_tmp_list[newstr->tmplisti]=(unsigned long)newstr; qbs_tmp_list_nexti++;
newstr->tmp=1;
newstr->readonly=1;
return newstr;
}







//note: qbs_new_fixed detects if string is in DBLOCK
qbs *qbs_new_fixed(unsigned char *offset,unsigned long size,unsigned char tmp){
qbs *newstr;
newstr=qbs_new_descriptor();
newstr->len=size;
newstr->chr=offset;
newstr->fixed=1;
if (tmp){
if (qbs_tmp_list_nexti>qbs_tmp_list_lasti) qbs_tmp_concat_list();
newstr->tmplisti=qbs_tmp_list_nexti; qbs_tmp_list[newstr->tmplisti]=(unsigned long)newstr; qbs_tmp_list_nexti++;
newstr->tmp=1;
}else{
//is it in DBLOCK?
if ((offset>(cmem+1280))&&(offset<(cmem+66816))){
//alloc string descriptor in DBLOCK (4 bytes)
cmem_sp-=4; newstr->cmem_descriptor=(unsigned short*)(dblock+cmem_sp); if (cmem_sp<qbs_cmem_sp) error(257);
newstr->cmem_descriptor_offset=cmem_sp;
  //update cmem_descriptor [length][offset]
  newstr->cmem_descriptor[0]=newstr->len; newstr->cmem_descriptor[1]=(unsigned short)(newstr->chr-dblock);
}
}
return newstr;
}

qbs *qbs_new(long size,unsigned char tmp){
static qbs *newstr;
if ((qbs_sp+size+32)>qbs_data_size) qbs_concat(size+32);
newstr=qbs_new_descriptor();
newstr->len=size;
newstr->chr=qbs_data+qbs_sp;
qbs_sp+=size+32;
if (qbs_list_nexti>qbs_list_lasti) qbs_concat_list();
newstr->listi=qbs_list_nexti; qbs_list[newstr->listi]=(unsigned long)newstr; qbs_list_nexti++;
if (tmp){
if (qbs_tmp_list_nexti>qbs_tmp_list_lasti) qbs_tmp_concat_list();
newstr->tmplisti=qbs_tmp_list_nexti; qbs_tmp_list[newstr->tmplisti]=(unsigned long)newstr; qbs_tmp_list_nexti++;
newstr->tmp=1;
}
return newstr;
}

qbs *qbs_set(qbs *deststr,qbs *srcstr){
long i;
qbs *tqbs;

//fixed deststr
if (deststr->fixed){
 if (srcstr->len>=deststr->len){
  memcpy(deststr->chr,srcstr->chr,deststr->len);
 }else{
  memcpy(deststr->chr,srcstr->chr,srcstr->len);
  memset(deststr->chr+srcstr->len,32,deststr->len-srcstr->len);//pad with spaces
 }
 goto qbs_set_return;
}
//non-fixed deststr

//can srcstr be aquired by deststr?
if (srcstr->tmp){
if (srcstr->fixed==0){
if (srcstr->readonly==0){
if (srcstr->in_cmem==deststr->in_cmem){
if (deststr->in_cmem){
 //unlist deststr and acquire srcstr's list index
 qbs_cmem_list[deststr->listi]=0xFFFFFFFF;
 qbs_cmem_list[srcstr->listi]=(unsigned long)deststr;
 deststr->listi=srcstr->listi;
}else{
 //unlist deststr and acquire srcstr's list index
 qbs_list[deststr->listi]=0xFFFFFFFF;
 qbs_list[srcstr->listi]=(unsigned long)deststr;
 deststr->listi=srcstr->listi;
}

qbs_tmp_list[srcstr->tmplisti]=0xFFFFFFFF;
if (srcstr->tmplisti==(qbs_tmp_list_nexti-1)) qbs_tmp_list_nexti--;//correct last tmp index for performance

deststr->chr=srcstr->chr;
deststr->len=srcstr->len;
qbs_free_descriptor(srcstr);
  //update cmem_descriptor [length][offset]
  if (deststr->cmem_descriptor){deststr->cmem_descriptor[0]=deststr->len; deststr->cmem_descriptor[1]=(unsigned short)(deststr->chr-dblock);}
return deststr;//nb. This return cannot be changed to a goto qbs_set_return!
}}}}

//srcstr is equal length or shorter
if (srcstr->len<=deststr->len){
 memcpy(deststr->chr,srcstr->chr,srcstr->len);
 deststr->len=srcstr->len;
 goto qbs_set_return;
}

//srcstr is longer
if (deststr->in_cmem){
 if (deststr->listi==(qbs_cmem_list_nexti-1)){//last index
  if (((unsigned long)deststr->chr+srcstr->len)<=(dblock+cmem_sp)){//space available
   memcpy(deststr->chr,srcstr->chr,srcstr->len);
   deststr->len=srcstr->len;  
   qbs_cmem_sp=(unsigned long)deststr->chr+deststr->len-(unsigned long)dblock;
   goto qbs_set_return;
  }
  goto qbs_set_cmem_concat_required;
 }
 //deststr is not the last index so locate next valid index
 i=deststr->listi+1;
 qbs_set_nextindex:
 if (qbs_cmem_list[i]!=0xFFFFFFFF){
  tqbs=(qbs*)qbs_cmem_list[i];
  if (tqbs==srcstr){
   if (srcstr->tmp==1) goto skippedtmpsrcindex;
  }
  if ((deststr->chr+srcstr->len)>tqbs->chr) goto qbs_set_cmem_concat_required;
  memcpy(deststr->chr,srcstr->chr,srcstr->len);
  deststr->len=srcstr->len;
  goto qbs_set_return;
 }
 skippedtmpsrcindex:
 i++;
 if (i!=qbs_cmem_list_nexti) goto qbs_set_nextindex;
 //all next indexes invalid!
 qbs_cmem_list_nexti=deststr->listi+1;//adjust nexti
 if (((unsigned long)deststr->chr+srcstr->len)<=(dblock+cmem_sp)){//space available
   memmove(deststr->chr,srcstr->chr,srcstr->len);//overlap possible due to sometimes aquiring srcstr's space
   deststr->len=srcstr->len;
   qbs_cmem_sp=(unsigned long)deststr->chr+deststr->len-(unsigned long)dblock;
   goto qbs_set_return;
 }
qbs_set_cmem_concat_required:
//srcstr could not fit in deststr
//"realloc" deststr
qbs_cmem_list[deststr->listi]=0xFFFFFFFF;//unlist
if ((qbs_cmem_sp+srcstr->len)>cmem_sp){//must concat!
qbs_concat_cmem(srcstr->len);
}
if (qbs_cmem_list_nexti>qbs_cmem_list_lasti) qbs_cmem_concat_list();
deststr->listi=qbs_cmem_list_nexti;
qbs_cmem_list[qbs_cmem_list_nexti]=(unsigned long)deststr; qbs_cmem_list_nexti++; //relist
deststr->chr=(unsigned char*)dblock+qbs_cmem_sp;
deststr->len=srcstr->len;
qbs_cmem_sp+=deststr->len;
memcpy(deststr->chr,srcstr->chr,srcstr->len);
goto qbs_set_return;
}


//not in cmem
 if (deststr->listi==(qbs_list_nexti-1)){//last index
  if (((unsigned long)deststr->chr+srcstr->len)<=((unsigned long)qbs_data+qbs_data_size)){//space available
   memcpy(deststr->chr,srcstr->chr,srcstr->len);
   deststr->len=srcstr->len;
   qbs_sp=(unsigned long)deststr->chr+deststr->len-(unsigned long)qbs_data;
   goto qbs_set_return;
  }
  goto qbs_set_concat_required;
 }
 //deststr is not the last index so locate next valid index
 i=deststr->listi+1;
 qbs_set_nextindex2:
 if (qbs_list[i]!=0xFFFFFFFF){
  tqbs=(qbs*)qbs_list[i];
  if (tqbs==srcstr){
   if (srcstr->tmp==1) goto skippedtmpsrcindex2;
  }
  if ((deststr->chr+srcstr->len)>tqbs->chr) goto qbs_set_concat_required;
  memcpy(deststr->chr,srcstr->chr,srcstr->len);
  deststr->len=srcstr->len;
  goto qbs_set_return;
 }
 skippedtmpsrcindex2:
 i++;
 if (i!=qbs_list_nexti) goto qbs_set_nextindex2;
 //all next indexes invalid!

 qbs_list_nexti=deststr->listi+1;//adjust nexti 
 if (((unsigned long)deststr->chr+srcstr->len)<=((unsigned long)qbs_data+qbs_data_size)){//space available
   memmove(deststr->chr,srcstr->chr,srcstr->len);//overlap possible due to sometimes aquiring srcstr's space
   deststr->len=srcstr->len;
   qbs_sp=(unsigned long)deststr->chr+deststr->len-(unsigned long)qbs_data;
   goto qbs_set_return;
 }

qbs_set_concat_required:
//srcstr could not fit in deststr
//"realloc" deststr
qbs_list[deststr->listi]=0xFFFFFFFF;//unlist
if ((qbs_sp+srcstr->len)>qbs_data_size){//must concat!
qbs_concat(srcstr->len);
}
if (qbs_list_nexti>qbs_list_lasti) qbs_concat_list();
deststr->listi=qbs_list_nexti;
qbs_list[qbs_list_nexti]=(unsigned long)deststr; qbs_list_nexti++; //relist

deststr->chr=qbs_data+qbs_sp;
deststr->len=srcstr->len;
qbs_sp+=deststr->len;
memcpy(deststr->chr,srcstr->chr,srcstr->len);

//(fall through to qbs_set_return)
qbs_set_return:
if (srcstr->tmp){//remove srcstr if it is a tmp string
qbs_free(srcstr);
}
  //update cmem_descriptor [length][offset]
  if (deststr->cmem_descriptor){deststr->cmem_descriptor[0]=deststr->len; deststr->cmem_descriptor[1]=(unsigned short)(deststr->chr-dblock);}
return deststr;
}

qbs *qbs_add(qbs *str1,qbs *str2){
qbs *tqbs;
if (!str2->len) return str1;//pass on
if (!str1->len) return str2;//pass on
//may be possible to acquire str1 or str2's space but...
//1. check if dest has enough space (because its data is already in the correct place)
//2. check if source has enough space
//3. give up
//nb. they would also have to be a tmp, var. len str in ext memory!
//brute force method...
tqbs=qbs_new(str1->len+str2->len,1);
memcpy(tqbs->chr,str1->chr,str1->len);
memcpy(tqbs->chr+str1->len,str2->chr,str2->len);

//exit(qbs_sp);
if (str1->tmp) qbs_free(str1);
if (str2->tmp) qbs_free(str2);
return tqbs;
}

qbs *qbs_ucase(qbs *str){
unsigned long i;
unsigned char *c;
if (!str->len) return str;//pass on
qbs *tqbs=NULL;
if (str->tmp){ if (!str->fixed){ if (!str->readonly){ if (!str->in_cmem){ tqbs=str; }}}}
if (!tqbs){
//also pass on if already uppercase
c=str->chr;
for (i=0;i<str->len;i++){
 if ((*c>=97)&&(*c<=122)) goto qbs_ucase_cantpass;
 c++;
}
return str;
qbs_ucase_cantpass:
tqbs=qbs_new(str->len,1); memcpy(tqbs->chr,str->chr,str->len);
}
c=tqbs->chr;
for (i=0;i<tqbs->len;i++){
 if ((*c>=97)&&(*c<=122)) *c-=32;
 c++;
}
if (tqbs!=str) if (str->tmp) qbs_free(str);
return tqbs;
}

qbs *qbs_lcase(qbs *str){
unsigned long i;
unsigned char *c;
if (!str->len) return str;//pass on
qbs *tqbs=NULL;
if (str->tmp){ if (!str->fixed){ if (!str->readonly){ if (!str->in_cmem){ tqbs=str; }}}}
if (!tqbs){
//also pass on if already lowercase
c=str->chr;
for (i=0;i<str->len;i++){
 if ((*c>=65)&&(*c<=90)) goto qbs_lcase_cantpass;
 c++;
}
return str;
qbs_lcase_cantpass:
tqbs=qbs_new(str->len,1); memcpy(tqbs->chr,str->chr,str->len);
}
c=tqbs->chr;
for (i=0;i<tqbs->len;i++){
 if ((*c>=65)&&(*c<=90)) *c+=32;
 c++;
}
if (tqbs!=str) if (str->tmp) qbs_free(str);
return tqbs;
}

qbs *func_chr(long value){
qbs *tqbs;
if ((value<0)||(value>255)){
tqbs=qbs_new(0,1);
error(5);
}else{
tqbs=qbs_new(1,1);
tqbs->chr[0]=value;
}
return tqbs;
}


qbs *func_varptr_helper(unsigned char type,unsigned short offset){
//*creates a 3 byte string using the values given
qbs *tqbs;
tqbs=qbs_new(3,1);
tqbs->chr[0]=type;
tqbs->chr[1]=offset&255;
tqbs->chr[2]=offset>>8;
return tqbs;
}

qbs *qbs_left(qbs *str,long l){
if (l>str->len) l=str->len;
if (l<0) l=0;
if (l==str->len) return str;//pass on
if (str->tmp){ if (!str->fixed){ if (!str->readonly){ if (!str->in_cmem){ str->len=l; return str; }}}}
qbs *tqbs;
tqbs=qbs_new(l,1);
if (l) memcpy(tqbs->chr,str->chr,l);
if (str->tmp) qbs_free(str);
return tqbs;
}

qbs *qbs_right(qbs *str,long l){
if (l>str->len) l=str->len;
if (l<0) l=0;
if (l==str->len) return str;//pass on
if (str->tmp){ if (!str->fixed){ if (!str->readonly){ if (!str->in_cmem){
str->chr=str->chr+(str->len-l);
str->len=l; return str;
}}}}
qbs *tqbs;
tqbs=qbs_new(l,1);
if (l) memcpy(tqbs->chr,str->chr+str->len-l,l);
tqbs->len=l;
if (str->tmp) qbs_free(str);
return tqbs;
}

qbs *func_mksmbf(float val){
static qbs *tqbs;
tqbs=qbs_new(4,1);
if (_fieeetomsbin(&val,(float*)tqbs->chr)==1) {error(5); tqbs->len=0;}
return tqbs;
}
qbs *func_mkdmbf(double val){
static qbs *tqbs;
tqbs=qbs_new(8,1);
if (_dieeetomsbin(&val,(double*)tqbs->chr)==1) {error(5); tqbs->len=0;}
return tqbs;
}

float func_cvsmbf(qbs *str){
static float val;
if (str->len<4) {error(5); return 0;}
if (_fmsbintoieee((float*)str->chr,&val)==1) {error(5); return 0;}
return val;
}
double func_cvdmbf(qbs *str){
static double val;
if (str->len<8) {error(5); return 0;}
if (_dmsbintoieee((double*)str->chr,&val)==1) {error(5); return 0;}
return val;
}

qbs *b2string(char v){ static qbs *tqbs; tqbs=qbs_new(1,1); *((char*)(tqbs->chr))=v; return tqbs;}
qbs *ub2string(char v){ static qbs *tqbs; tqbs=qbs_new(1,1); *((unsigned char*)(tqbs->chr))=v; return tqbs;}
qbs *i2string(short v){ static qbs *tqbs; tqbs=qbs_new(2,1); *((short*)(tqbs->chr))=v; return tqbs;}
qbs *ui2string(short v){ static qbs *tqbs; tqbs=qbs_new(2,1); *((unsigned short*)(tqbs->chr))=v; return tqbs;}
qbs *l2string(long v){ static qbs *tqbs; tqbs=qbs_new(4,1); *((long*)(tqbs->chr))=v; return tqbs;}
qbs *ul2string(unsigned long v){ static qbs *tqbs; tqbs=qbs_new(4,1); *((unsigned long*)(tqbs->chr))=v; return tqbs;}
qbs *i642string(__int64 v){ static qbs *tqbs; tqbs=qbs_new(8,1); *((__int64*)(tqbs->chr))=v; return tqbs;}
qbs *i642string(unsigned __int64 v){ static qbs *tqbs; tqbs=qbs_new(8,1); *((unsigned __int64*)(tqbs->chr))=v; return tqbs;}
qbs *s2string(float v){ static qbs *tqbs; tqbs=qbs_new(4,1); *((float*)(tqbs->chr))=v; return tqbs;}
qbs *d2string(double v){ static qbs *tqbs; tqbs=qbs_new(8,1); *((double*)(tqbs->chr))=v; return tqbs;}
qbs *f2string(long double v){ static qbs *tqbs; tqbs=qbs_new(32,1); memset(tqbs->chr,0,32); *((long double*)(tqbs->chr))=v; return tqbs;}
qbs *bit2string(unsigned long bsize,__int64 v){
tqbs=qbs_new(8,1);
bmask=~(-(1<<bsize));
*((__int64*)(tqbs->chr))=v&bmask;
tqbs->len=(bsize+7)>>3;
return tqbs;
}
qbs *ubit2string(unsigned long bsize,unsigned __int64 v){
tqbs=qbs_new(8,1);
bmask=~(-(1<<bsize));
*((unsigned __int64*)(tqbs->chr))=v&bmask;
tqbs->len=(bsize+7)>>3;
return tqbs;
}

char string2b(qbs*str){ if (str->len<1) {error(5); return 0;} else {return *((char*)str->chr);} }
unsigned char string2ub(qbs*str){ if (str->len<1) {error(5); return 0;} else {return *((unsigned char*)str->chr);} }
short string2i(qbs*str){ if (str->len<2) {error(5); return 0;} else {return *((short*)str->chr);} }
unsigned short string2ui(qbs*str){ if (str->len<2) {error(5); return 0;} else {return *((unsigned short*)str->chr);} }
long string2l(qbs*str){ if (str->len<4) {error(5); return 0;} else {return *((long*)str->chr);} }
unsigned long string2ul(qbs*str){ if (str->len<4) {error(5); return 0;} else {return *((unsigned long*)str->chr);} }
__int64 string2i64(qbs*str){ if (str->len<8) {error(5); return 0;} else {return *((__int64*)str->chr);} }
unsigned __int64 string2ui64(qbs*str){ if (str->len<8) {error(5); return 0;} else {return *((unsigned __int64*)str->chr);} }
float string2s(qbs*str){ if (str->len<4) {error(5); return 0;} else {return *((float*)str->chr);} }
double string2d(qbs*str){ if (str->len<8) {error(5); return 0;} else {return *((double*)str->chr);} }
long double string2f(qbs*str){ if (str->len<32) {error(5); return 0;} else {return *((long double*)str->chr);} }
unsigned __int64 string2ubit(qbs*str,unsigned long bsize){
if (str->len<((bsize+7)>>3)) {error(5); return 0;}
bmask=~(-(1<<bsize));
return (*(unsigned __int64*)str->chr)&bmask;
}
__int64 string2bit(qbs*str,unsigned long bsize){
if (str->len<((bsize+7)>>3)) {error(5); return 0;}
bmask=~(-(1<<bsize));
bval64=((*(unsigned __int64*)str->chr)&bmask)<<boff;
if (bval64&(1<<(bsize-1))) return (bval64|(~bmask));
return bval64;
}

void sub_lset(qbs *dest,qbs *source){
if (source->len>=dest->len){
if (dest->len) memcpy(dest->chr,source->chr,dest->len);
return;
}
if (source->len) memcpy(dest->chr,source->chr,source->len);
memset(dest->chr+source->len,32,dest->len-source->len);
}

void sub_rset(qbs *dest,qbs *source){
if (source->len>=dest->len){
if (dest->len) memcpy(dest->chr,source->chr,dest->len);
return;
}
if (source->len) memcpy(dest->chr+dest->len-source->len,source->chr,source->len);
memset(dest->chr,32,dest->len-source->len);
}




qbs *func_space(long spaces){
static qbs *tqbs;
if (spaces<0) spaces=0;
tqbs=qbs_new(spaces,1);
if (spaces) memset(tqbs->chr,32,spaces);
return tqbs;
}

qbs *func_string(long characters,long asciivalue){
static qbs *tqbs;
if (characters<0) characters=0;
tqbs=qbs_new(characters,1);
if (characters) memset(tqbs->chr,asciivalue&0xFF,characters);
return tqbs;
}

long func_instr(long start,qbs *str,qbs *substr,long passed){
//QB64 difference: start can be 0 or negative
//justification-start could be larger than the length of string to search in QBASIC
static unsigned char *limit,*base;
static unsigned char firstc;
if (!passed) start=1;
if (!str->len) return 0;
if (start<1){
start=1;
if (!substr->len) return 0;
}
if (start>str->len) return 0;
if (!substr->len) return start;
if ((start+substr->len-1)>str->len) return 0;
limit=str->chr+str->len;
firstc=substr->chr[0];
base=str->chr+start-1;
nextchar:
base=(unsigned char*)memchr(base,firstc,limit-base);
if (!base) return 0;
if ((base+substr->len)>limit) return 0;
if (!memcmp(base,substr->chr,substr->len)) return base-str->chr+1;
base++;
if ((base+substr->len)>limit) return 0;
goto nextchar;
}

void sub_mid(qbs *dest,long start,long l,qbs* src,long passed){
static long src_offset;
if (!passed) l=src->len;
src_offset=0;
if (dest==nothingstring) return;//quiet exit, error has already been reported!
if (start<1){
l=l+start-1;
src_offset=-start+1;//src_offset is a byte offset with base 0!
start=1;
}
if (l<=0) return;
if (start>dest->len) return;
if ((start+l-1)>dest->len) l=dest->len-start+1;
//start and l are now reflect a valid region within dest
if (src_offset>=src->len) return;
if (l>(src->len-src_offset)) l=src->len-src_offset;
//src_offset and l now reflect a valid region within src
if (dest==src){
if ((start-1)!=src_offset) memmove(dest->chr+start-1,src->chr+src_offset,l);
}else{
memcpy(dest->chr+start-1,src->chr+src_offset,l);
}
}

qbs *func_mid(qbs *str,long start,long l,long passed){
static qbs *tqbs;
if (passed){
 if (start<1) {l=l-1+start; start=1;}
 if ((l>=1)&&(start<=str->len)){
 if ((start+l)>str->len) l=str->len-start+1;
 }else{
 l=0; start=1;//nothing!
 }
}else{
 if (start<1) start=1;
 l=str->len-start+1;
 if (l<1){
 l=0; start=1;//nothing!
 }
}
if ((start==1)&&(l==str->len)) return str;//pass on
if (str->tmp){ if (!str->fixed){ if (!str->readonly){ if (!str->in_cmem){//acquire
str->chr=str->chr+(start-1);
str->len=l;
return str;
}}}}
tqbs=qbs_new(l,1);
if (l) memcpy(tqbs->chr,str->chr+start-1,l);
if (str->tmp) qbs_free(str);
return tqbs;
}

qbs *qbs_ltrim(qbs *str){
if (!str->len) return str;//pass on
if (*str->chr!=32) return str;//pass on
if (str->tmp){ if (!str->fixed){ if (!str->readonly){ if (!str->in_cmem){//acquire?
qbs_ltrim_nextchar:
if (*str->chr==32){
str->chr++;
if (--str->len) goto qbs_ltrim_nextchar;
}
return str;
}}}}
long i;
i=0;
qbs_ltrim_nextchar2: if (str->chr[i]==32) {i++; if (i<str->len) goto qbs_ltrim_nextchar2;}
qbs *tqbs;
tqbs=qbs_new(str->len-i,1);
if (tqbs->len) memcpy(tqbs->chr,str->chr+i,tqbs->len);
if (str->tmp) qbs_free(str);
return tqbs;
}

qbs *qbs_rtrim(qbs *str){
if (!str->len) return str;//pass on
if (str->chr[str->len-1]!=32) return str;//pass on
if (str->tmp){ if (!str->fixed){ if (!str->readonly){ if (!str->in_cmem){//acquire?
qbs_rtrim_nextchar:
if (str->chr[str->len-1]==32){
if (--str->len) goto qbs_rtrim_nextchar;
}
return str;
}}}}
long i;
i=str->len;
qbs_rtrim_nextchar2: if (str->chr[i-1]==32) {i--; if (i) goto qbs_rtrim_nextchar2;}
//i is the number of characters to keep
qbs *tqbs;
tqbs=qbs_new(i,1);
if (i) memcpy(tqbs->chr,str->chr,i);
if (str->tmp) qbs_free(str);
return tqbs;
}

qbs *qbs_inkey(){
qbs *tqbs;
Sleep(0);
tqbs=qbs_new(2,1);
if (cmem[0x41a]!=cmem[0x41c]){
//MessageBox(NULL,"Key detected","Key detected",MB_OK);

tqbs->chr[0]=cmem[0x400+cmem[0x41a]];
tqbs->chr[1]=cmem[0x400+cmem[0x41a]+1];
if (tqbs->chr[0]) tqbs->len=1;
cmem[0x41a]+=2;
if (cmem[0x41a]==62) cmem[0x41a]=30;
}else{
tqbs->len=0;
}
return tqbs;
}

//STR() functions
//singed integers
qbs *qbs_str(__int64 value){
qbs *tqbs;
tqbs=qbs_new(20,1);
tqbs->len=sprintf((char*)tqbs->chr,"% I64i",value);
return tqbs;
}
qbs *qbs_str(long value){
qbs *tqbs;
tqbs=qbs_new(11,1);
tqbs->len=sprintf((char*)tqbs->chr,"% i",value);
return tqbs;
}
qbs *qbs_str(short value){
qbs *tqbs;
tqbs=qbs_new(6,1);
tqbs->len=sprintf((char*)tqbs->chr,"% i",value);
return tqbs;
}
qbs *qbs_str(char value){
qbs *tqbs;
tqbs=qbs_new(4,1);
tqbs->len=sprintf((char*)tqbs->chr,"% i",value);
return tqbs;
}
//unsigned integers
qbs *qbs_str(unsigned __int64 value){
qbs *tqbs;
tqbs=qbs_new(21,1);
tqbs->len=sprintf((char*)tqbs->chr,"% I64u",value);
return tqbs;
}
qbs *qbs_str(unsigned long value){
qbs *tqbs;
tqbs=qbs_new(11,1);
tqbs->len=sprintf((char*)tqbs->chr,"% u",value);
return tqbs;
}
qbs *qbs_str(unsigned short value){
qbs *tqbs;
tqbs=qbs_new(6,1);
tqbs->len=sprintf((char*)tqbs->chr,"% u",value);
return tqbs;
}
qbs *qbs_str(unsigned char value){
qbs *tqbs;
tqbs=qbs_new(4,1);
tqbs->len=sprintf((char*)tqbs->chr,"% u",value);
return tqbs;
}



unsigned char func_str_fmt[7];
unsigned char qbs_str_buffer[32];
unsigned char qbs_str_buffer2[32];

qbs *qbs_str(float value){
static qbs *tqbs;
tqbs=qbs_new(16,1);
static long l,i,i2,i3,digits,exponent;
l=sprintf((char*)&qbs_str_buffer,"% .6E",value);
//IMPORTANT: assumed l==14
digits=7;
for (i=8;i>=1;i--){
if (qbs_str_buffer[i]==48){
digits--;
}else{
if (qbs_str_buffer[i]!=46) break;
}
}//i
//no significant digits? simply return 0
if (digits==0){
tqbs->len=2; tqbs->chr[0]=32; tqbs->chr[1]=48;//tqbs=[space][0]
return tqbs;
}
//calculate exponent
exponent=(qbs_str_buffer[11]-48)*100+(qbs_str_buffer[12]-48)*10+(qbs_str_buffer[13]-48);
if (qbs_str_buffer[10]==45) exponent=-exponent;
if ((exponent<=6)&&((exponent-digits)>=-8)) goto asdecimal;
//fix up exponent to conform to QBASIC standards
//i. cull trailing 0's after decimal point (use digits to help)
//ii. cull leading 0's of exponent
i3=0;
i2=digits+2;
if (digits==1) i2--;//don't include decimal point
for (i=0;i<i2;i++) {tqbs->chr[i3]=qbs_str_buffer[i]; i3++;}
for (i=9;i<=10;i++) {tqbs->chr[i3]=qbs_str_buffer[i]; i3++;}
exponent=abs(exponent);
//i2=13;
//if (exponent>9) i2=12;
i2=12;//override: if exponent is less than 10 still display a leading 0
if (exponent>99) i2=11;
for (i=i2;i<=13;i++) {tqbs->chr[i3]=qbs_str_buffer[i]; i3++;}
tqbs->len=i3;
return tqbs;
/////////////////////
asdecimal:
//calculate digits after decimal point in var. i
i=-(exponent-digits+1);
if (i<0) i=0;
func_str_fmt[0]=37;//"%"
func_str_fmt[1]=32;//" "
func_str_fmt[2]=46;//"."
func_str_fmt[3]=i+48;
func_str_fmt[4]=102;//"f"
func_str_fmt[5]=0;
tqbs->len=sprintf((char*)tqbs->chr,(const char*)&func_str_fmt,value);
if (tqbs->chr[1]==48){//must manually cull leading 0
memmove(tqbs->chr+1,tqbs->chr+2,tqbs->len-2);
tqbs->len--;
}
return tqbs;
}

qbs *qbs_str(double value){
static qbs *tqbs;
tqbs=qbs_new(32,1);
static long l,i,i2,i3,digits,exponent;

l=sprintf((char*)&qbs_str_buffer,"% .15E",value);
//IMPORTANT: assumed l==23
//check if the 16th significant digit is 9, if it is round to 15 significant digits
if (qbs_str_buffer[17]==57){
sprintf((char*)&qbs_str_buffer2,"% .14E",value);
memmove(&qbs_str_buffer,&qbs_str_buffer2,17);
qbs_str_buffer[17]=48;
}
qbs_str_buffer[18]=68; //change E to D (QBASIC standard)
digits=16;
for (i=17;i>=1;i--){
if (qbs_str_buffer[i]==48){
digits--;
}else{
if (qbs_str_buffer[i]!=46) break;
}
}//i
//no significant digits? simply return 0
if (digits==0){
tqbs->len=2; tqbs->chr[0]=32; tqbs->chr[1]=48;//tqbs=[space][0]
return tqbs;
}
//calculate exponent
exponent=(qbs_str_buffer[20]-48)*100+(qbs_str_buffer[21]-48)*10+(qbs_str_buffer[22]-48);
if (qbs_str_buffer[19]==45) exponent=-exponent;
//OLD if ((exponent<=15)&&((exponent-digits)>=-16)) goto asdecimal;
if ((exponent<=15)&&((exponent-digits)>=-17)) goto asdecimal;
//fix up exponent to conform to QBASIC standards
//i. cull trailing 0's after decimal point (use digits to help)
//ii. cull leading 0's of exponent
i3=0;
i2=digits+2;
if (digits==1) i2--;//don't include decimal point
for (i=0;i<i2;i++) {tqbs->chr[i3]=qbs_str_buffer[i]; i3++;}
for (i=18;i<=19;i++) {tqbs->chr[i3]=qbs_str_buffer[i]; i3++;}
exponent=abs(exponent);
//i2=22;
//if (exponent>9) i2=21;
i2=21;//override: if exponent is less than 10 still display a leading 0
if (exponent>99) i2=20;
for (i=i2;i<=22;i++) {tqbs->chr[i3]=qbs_str_buffer[i]; i3++;}
tqbs->len=i3;
return tqbs;
/////////////////////
asdecimal:
//calculate digits after decimal point in var. i
i=-(exponent-digits+1);
if (i<0) i=0;
func_str_fmt[0]=37;//"%"
func_str_fmt[1]=32;//" "
func_str_fmt[2]=46;//"."
if (i>9){
func_str_fmt[3]=49;//"1"
func_str_fmt[4]=(i-10)+48;
}else{
func_str_fmt[3]=48;//"0"
func_str_fmt[4]=i+48;
}
func_str_fmt[5]=102;//"f"
func_str_fmt[6]=0;
tqbs->len=sprintf((char*)tqbs->chr,(const char*)&func_str_fmt,value);
if (tqbs->chr[1]==48){//must manually cull leading 0
memmove(tqbs->chr+1,tqbs->chr+2,tqbs->len-2);
tqbs->len--;
}
return tqbs;
}

qbs *qbs_str(long double value){
//not fully implemented
return qbs_str((double)value);
}


long qbs_equal(qbs *str1,qbs *str2){
if (str1->len!=str2->len) return 0;
if (memcmp(str1->chr,str2->chr,str1->len)==0) return -1;
return 0;
}
long qbs_notequal(qbs *str1,qbs *str2){
if (str1->len!=str2->len) return -1;
if (memcmp(str1->chr,str2->chr,str1->len)==0) return 0;
return -1;
}
long qbs_greaterthan(qbs *str1,qbs *str2){
static long i;
if (str1->len<=str2->len){
i=memcmp(str1->chr,str2->chr,str1->len);
if (i>0) return -1;
return 0;
}else{
i=memcmp(str1->chr,str2->chr,str2->len);
if (i<0) return 0;
return -1;
}
}
long qbs_lessthan(qbs *str1,qbs *str2){
static long i;
if (str1->len<=str2->len){
i=memcmp(str1->chr,str2->chr,str1->len);
if (i<0) return -1;
return 0;
}else{
i=memcmp(str1->chr,str2->chr,str2->len);
if (i>=0) return 0;
return -1;
}
}
long qbs_lessorequal(qbs *str1,qbs *str2){
static long i;
if (str1->len<=str2->len){
i=memcmp(str1->chr,str2->chr,str1->len);
if (i<=0) return -1;
return 0;
}else{
i=memcmp(str1->chr,str2->chr,str2->len);
if (i>=0) return 0;
return -1;
}
}
long qbs_greaterorequal(qbs *str1,qbs *str2){
static long i;
//greater?
if (str1->len<=str2->len){
i=memcmp(str1->chr,str2->chr,str1->len);
if (i>0) return -1;
if (i==0) if (str1->len==str2->len) return -1;//equal?
return 0;
}else{
i=memcmp(str1->chr,str2->chr,str2->len);
if (i<0) return 0;
return -1;
}
}



long qbs_asc(qbs *str){
if (str->len) return str->chr[0];
return 0;
}

long qbs_len(qbs *str){
return str->len;
}

long qbg_program_window_width=320;
long qbg_program_window_height=240;


long qbg_mode=-1;//-1 means not initialized!
long qbg_text_only;
//text & graphics modes
long qbg_height_in_characters, qbg_width_in_characters;
long qbg_top_row, qbg_bottom_row;
long qbg_cursor_x, qbg_cursor_y;
long qbg_character_height, qbg_character_width;
unsigned long qbg_color, qbg_background_color;
//text mode ONLY
long qbg_cursor_show;
long qbg_cursor_firstvalue, qbg_cursor_lastvalue;//these values need revision
//graphics modes ONLY
long qbg_width, qbg_height;
float qbg_x, qbg_y;
long qbg_bits_per_pixel, qbg_pixel_mask; //for monochrome modes 1b, for 16 color 1111b, for 256 color 11111111b
long qbg_bytes_per_pixel;
long qbg_clipping_or_scaling;//1=clipping, 2=clipping and scaling
long qbg_view_x1, qbg_view_y1, qbg_view_x2, qbg_view_y2;
long qbg_view_offset_x, qbg_view_offset_y;
float qbg_scaling_x, qbg_scaling_y;
float qbg_scaling_offset_x, qbg_scaling_offset_y;
float qbg_window_x1, qbg_window_y1, qbg_window_x2, qbg_window_y2;
long qbg_pages;
unsigned long *qbg_pageoffsets;
long *qbg_cursor_x_previous; //used to recover old cursor position
long *qbg_cursor_y_previous;


long qbg_active_page;
unsigned char *qbg_active_page_offset;
long qbg_visual_page;
unsigned char *qbg_visual_page_offset;
long qbg_color_assign[256];//for modes with quasi palettes!

unsigned long pal_mode10[2][9];

unsigned long pal[256];


unsigned char charset8x8[256][8][8];
unsigned char charset8x16[256][16][8];


unsigned long qbg_palette_256[256];
unsigned long qbg_palette_64[64];

long lineclip_draw;//1=draw, 0=don't draw
long lineclip_x1,lineclip_y1,lineclip_x2,lineclip_y2;
long lineclip_skippixels;//the number of pixels from x1,y1 which won't be drawn

void lineclip(long x1,long y1,long x2,long y2,long xmin,long ymin,long xmax,long ymax){
static double mx,my,y,x,d;
static long xdis,ydis;
//is it a single point? (needed to avoid "division by 0" errors)
lineclip_skippixels=0;

if (x1==x2){ if (y1==y2){
if (x1>=xmin){ if (x1<=xmax){ if (y1>=ymin){ if (y1<=ymax){
goto singlepoint;
}}}}
lineclip_draw=0;
return;
}}

if (x1>=xmin){ if (x1<=xmax){ if (y1>=ymin){ if (y1<=ymax){
goto gotx1y1;
}}}}
mx=(x2-x1)/fabs(y2-y1); my=(y2-y1)/fabs(x2-x1);
//right wall from right
if (x1>xmax){
if (mx<0){
y=(double)y1+((double)x1-(double)xmax)*my;
if (y>=ymin){ if (y<=ymax){
  //double space indented values calculate pixels to skip
  xdis=x1; ydis=y1;
x1=xmax; y1=qbr_float_to_long(y);
  xdis=abs(xdis-x1); ydis=abs(ydis-y1);
  if (xdis>=ydis) lineclip_skippixels=xdis; else lineclip_skippixels=ydis;
goto gotx1y1;
}}
}
}
//left wall from left
if (x1<xmin){
if (mx>0){
y=(double)y1+((double)xmin-(double)x1)*my;
if (y>=ymin){ if (y<=ymax){
  //double space indented values calculate pixels to skip
  xdis=x1; ydis=y1;
x1=xmin; y1=qbr_float_to_long(y);
  xdis=abs(xdis-x1); ydis=abs(ydis-y1);
  if (xdis>=ydis) lineclip_skippixels=xdis; else lineclip_skippixels=ydis;
goto gotx1y1;
}}
}
}
//top wall from top
if (y1<ymin){
if (my>0){
x=(double)x1+((double)ymin-(double)y1)*mx;
if (x>=xmin){ if (x<=xmax){
  //double space indented values calculate pixels to skip
  xdis=x1; ydis=y1;
x1=qbr_float_to_long(x); y1=ymin;
  xdis=abs(xdis-x1); ydis=abs(ydis-y1);
  if (xdis>=ydis) lineclip_skippixels=xdis; else lineclip_skippixels=ydis;
goto gotx1y1;
}}
}
}
//bottom wall from bottom
if (y1>ymax){
if (my<0){
x=(double)x1+((double)y2-(double)ymax)*mx;
if (x>=xmin){ if (x<=xmax){
  //double space indented values calculate pixels to skip
  xdis=x1; ydis=y1;
x1=qbr_float_to_long(x); y1=ymax;
  xdis=abs(xdis-x1); ydis=abs(ydis-y1);
  if (xdis>=ydis) lineclip_skippixels=xdis; else lineclip_skippixels=ydis;
goto gotx1y1;
}}
}
}
lineclip_draw=0;
return;
gotx1y1:

if (x2>=xmin){ if (x2<=xmax){ if (y2>=ymin){ if (y2<=ymax){
goto gotx2y2;
}}}}


mx=(x1-x2)/fabs(y1-y2); my=(y1-y2)/fabs(x1-x2);
//right wall from right
if (x2>xmax){
if (mx<0){
y=(double)y2+((double)x2-(double)xmax)*my;
if (y>=ymin){ if (y<=ymax){
x2=xmax; y2=qbr_float_to_long(y);
goto gotx2y2;
}}
}
}
//left wall from left
if (x2<xmin){
if (mx>0){
y=(double)y2+((double)xmin-(double)x2)*my;
if (y>=ymin){ if (y<=ymax){
x2=xmin; y2=qbr_float_to_long(y);
goto gotx2y2;
}}
}
}
//top wall from top
if (y2<ymin){
if (my>0){
x=(double)x2+((double)ymin-(double)y2)*mx;
if (x>=xmin){ if (x<=xmax){
x2=qbr_float_to_long(x); y2=ymin;
goto gotx2y2;
}}
}
}
//bottom wall from bottom
if (y2>ymax){
if (my<0){
x=(double)x2+((double)y2-(double)ymax)*mx;
if (x>=xmin){ if (x<=xmax){
x2=qbr_float_to_long(x); y2=ymax;
goto gotx2y2;
}}
}
}
lineclip_draw=0;
return;
gotx2y2:
singlepoint:
lineclip_draw=1;
lineclip_x1=x1; lineclip_y1=y1; lineclip_x2=x2; lineclip_y2=y2;


return;
}

//initialises the palette data for qbg_mode
void qbg_restorepalette(){

/*
SCREEN Mode 1 Syntax:  COLOR [background][,palette]
   � background is the screen color (range = 0-15)
   � palette is a three-color palette (range = 0-1)
     0 = green, red, and brown         1 = cyan, magenta, and bright white
Note: option 1 is the default, palette can override these though
OPTION 1:*DEFAULT*
0=black(color 0)
1=cyan(color 3)
2=purple(color 5)
3=light grey(color 7)
OPTION 0:
0=black(color 0)
1=green(color 2)
2=red(color 4)
3=brown(color 6)
*/
if (qbg_mode==1){
pal[0]=qbg_palette_256[0];
pal[1]=qbg_palette_256[3];
pal[2]=qbg_palette_256[5];
pal[3]=qbg_palette_256[7];
return;
}

if (qbg_mode==2){//black/white 2 color palette
pal[0]=0;
pal[1]=0xFFFFFF;
return;
}

if (qbg_mode==9){//16 colors selected from 64 possibilities
pal[0]=qbg_palette_64[0];
pal[1]=qbg_palette_64[1];
pal[2]=qbg_palette_64[2];
pal[3]=qbg_palette_64[3];
pal[4]=qbg_palette_64[4];
pal[5]=qbg_palette_64[5];
pal[6]=qbg_palette_64[20];
pal[7]=qbg_palette_64[7];
pal[8]=qbg_palette_64[56];
pal[9]=qbg_palette_64[57];
pal[10]=qbg_palette_64[58];
pal[11]=qbg_palette_64[59];
pal[12]=qbg_palette_64[60];
pal[13]=qbg_palette_64[61];
pal[14]=qbg_palette_64[62];
pal[15]=qbg_palette_64[63];
return;
}

if (qbg_mode==10){//4 colors selected from 9 possibilities (does not use pal[] array)
qbg_color_assign[0]=0;
qbg_color_assign[1]=4;
qbg_color_assign[2]=6;
qbg_color_assign[3]=8;
return;
}

if (qbg_mode==11){//black/white 2 color palette
pal[0]=0;
pal[1]=0xFFFFFF;
return;
}

//default 256 color palette (some screens only access bottom 16 colors)


memcpy(pal,qbg_palette_256,1024);


}

//this is NOT the PALETTE USING sub which still needs to be created
void qbg_palette(long attribute,long col,long passed){

if (!(passed&3)){
if (!passed){
void qbg_restorepalette();
return;
}
goto qbg_palette_error;
}

if (qbg_mode==13){
if ((attribute<0)||(attribute>255)) goto qbg_palette_error;
if (col&0xFFC0C0C0) goto qbg_palette_error;//11111111110000001100000011000000b
long r,g,b;
r=col&63;
g=(col>>8)&63;
b=(col>>16)&63;
r=qbr((double)r*4.063492f-0.4999999f);
g=qbr((double)g*4.063492f-0.4999999f);
b=qbr((double)b*4.063492f-0.4999999f);
pal[attribute]=b+g*256+r*65536;
//pal[attribute]=(((col<<2)&0xFF)<<16)+(((col>>6)&0xFF)<<8)+((col>>14)&0xFF);
return;
}

if (qbg_mode==12){
if ((attribute<0)||(attribute>15)) goto qbg_palette_error;
if (col&0xFFC0C0C0) goto qbg_palette_error;//11111111110000001100000011000000b
pal[attribute]=(((col<<2)&0xFF)<<16)+(((col>>6)&0xFF)<<8)+((col>>14)&0xFF);
return;
}

if (qbg_mode==11){
if ((attribute<0)||(attribute>1)) goto qbg_palette_error;
if (col&0xFFC0C0C0) goto qbg_palette_error;//11111111110000001100000011000000b
pal[attribute]=(((col<<2)&0xFF)<<16)+(((col>>6)&0xFF)<<8)+((col>>14)&0xFF);
return;
}

if (qbg_mode==10){
if ((attribute<0)||(attribute>3)) goto qbg_palette_error;
if ((col<0)||(col>8)) goto qbg_palette_error;
qbg_color_assign[attribute]=col;
return;
}

if (qbg_mode==9){
if ((attribute<0)||(attribute>15)) goto qbg_palette_error;
if ((col<0)||(col>63)) goto qbg_palette_error;
pal[attribute]=qbg_palette_64[col];
return;
}

if (qbg_mode==8){
if ((attribute<0)||(attribute>15)) goto qbg_palette_error;
if ((col<0)||(col>15)) goto qbg_palette_error;
pal[attribute]=qbg_palette_256[col];
return;
}

if (qbg_mode==7){
if ((attribute<0)||(attribute>15)) goto qbg_palette_error;
if ((col<0)||(col>15)) goto qbg_palette_error;
pal[attribute]=qbg_palette_256[col];
return;
}

if (qbg_mode==2){
if ((attribute<0)||(attribute>1)) goto qbg_palette_error;
if ((col<0)||(col>15)) goto qbg_palette_error;
pal[attribute]=qbg_palette_256[col];
return;
}

if (qbg_mode==1){
if ((attribute<0)||(attribute>15)) goto qbg_palette_error;
if ((col<0)||(col>15)) goto qbg_palette_error;
pal[attribute]=qbg_palette_256[col];
return;
}

if (qbg_mode==0){
if ((attribute<0)||(attribute>15)) goto qbg_palette_error;
if ((col<0)||(col>63)) goto qbg_palette_error;
pal[attribute]=qbg_palette_64[col];
return;
}

qbg_palette_error:
error(5);
return;

}//qbg_palette (end)




void qbg_sub_color(long col1,long col2,long bordercolor,long passed){
//PRE-ERROR CHECKING
if (!passed){
//note. many screens (such as 13) change nothing if nothing is passed
//      this has been adopted as the default response in this case
return;
}

if (qbg_mode==13){
if (passed&6) goto qbg_sub_color_error;
if ((col1>255)||(col1<0)) goto qbg_sub_color_error;
qbg_color=col1;
return;
}
if (qbg_mode==12){
if (passed&6) goto qbg_sub_color_error;
if ((col1>15)||(col1<0)) goto qbg_sub_color_error;
qbg_color=col1;
return;
}
if (qbg_mode==11){
if (passed&6) goto qbg_sub_color_error;
if ((col1>1)||(col1<0)) goto qbg_sub_color_error;
qbg_color=col1;
return;
}
if (qbg_mode==10){
if (passed&4) goto qbg_sub_color_error;
if (passed&1) if ((col1>3)||(col1<0)) goto qbg_sub_color_error;
if (passed&2) if ((col2>8)||(col2<0)) goto qbg_sub_color_error;
if (passed&1) qbg_color=col1;
if (passed&2) qbg_color_assign[0]=col2;
return;
}
if (qbg_mode==9){
if (passed&4) goto qbg_sub_color_error;
if (passed&1) if ((col1>15)||(col1<0)) goto qbg_sub_color_error;
if (passed&2) if ((col2>63)||(col2<0)) goto qbg_sub_color_error;
if (passed&1) qbg_color=col1;
if (passed&2) pal[0]=qbg_palette_64[col2];
return;
}
if (qbg_mode==8){
if (passed&4) goto qbg_sub_color_error;
if (passed&1) if ((col1>15)||(col1<0)) goto qbg_sub_color_error;
if (passed&2) if ((col2>15)||(col2<0)) goto qbg_sub_color_error;
if (passed&1) qbg_color=col1;
if (passed&2) pal[0]=qbg_palette_256[col2];
return;
}
if (qbg_mode==7){
if (passed&4) goto qbg_sub_color_error;
if (passed&1) if ((col1>15)||(col1<0)) goto qbg_sub_color_error;
if (passed&2) if ((col2>15)||(col2<0)) goto qbg_sub_color_error;
if (passed&1) qbg_color=col1;
if (passed&2) pal[0]=qbg_palette_256[col2];
return;
}
if (qbg_mode==2){
if (passed&4) goto qbg_sub_color_error;
if (passed&1) if ((col1>1)||(col1<0)) goto qbg_sub_color_error;
if (passed&2) if ((col2>15)||(col2<0)) goto qbg_sub_color_error;
if (passed&1) qbg_color=col1;
if (passed&2) pal[0]=qbg_palette_256[col2];
return;
}
if (qbg_mode==1){
if (passed&4) goto qbg_sub_color_error;
if (passed&1){
if ((col1>15)||(col1<0)) goto qbg_sub_color_error;
pal[0]=qbg_palette_256[col1];
}
if (passed&2){
if (col2&1){
pal[1]=qbg_palette_256[3];
pal[2]=qbg_palette_256[5];
pal[3]=qbg_palette_256[7];
}else{
pal[1]=qbg_palette_256[2];
pal[2]=qbg_palette_256[4];
pal[3]=qbg_palette_256[6];
}
}
return;
}
if (qbg_mode==0){
if (passed&1) if ((col1>31)||(col1<0)) goto qbg_sub_color_error;
if (passed&2) if ((col2>15)||(col2<0)) goto qbg_sub_color_error;
if (passed&1) qbg_color=col1;
if (passed&2) qbg_background_color=col2&7;
return;
}
qbg_sub_color_error:
error(5);
return;
}





void validate_video_page(long pagenumber){
static long i,i2;
static unsigned char *c;
if (pagenumber>=qbg_pages){
i=pagenumber+1;//i=indexes needed
qbg_pageoffsets=(unsigned long*)realloc(qbg_pageoffsets,i*4);
qbg_cursor_x_previous=(long*)realloc(qbg_cursor_x_previous,i*4);
qbg_cursor_y_previous=(long*)realloc(qbg_cursor_y_previous,i*4);
//clear top of realloc'd arrays
for (i=qbg_pages;i<=pagenumber;i++){
qbg_pageoffsets[i]=NULL;
qbg_cursor_x_previous[i]=0; qbg_cursor_y_previous[i]=0;
}
qbg_pages=pagenumber+1;
//clear new video page
if (qbg_mode==0){
i2=qbg_width_in_characters*qbg_height_in_characters*2;
qbg_pageoffsets[pagenumber]=(unsigned long)malloc(i2);
c=(unsigned char*)qbg_pageoffsets[pagenumber];
for (i=0;i<i2;i+=2){c[i]=32; c[i+1]=7;}
}else{
qbg_pageoffsets[pagenumber]=(unsigned long)calloc(qbg_width*qbg_height*qbg_bytes_per_pixel,1);
}
}//pagenumber>=qbg_pages
return;
}

void select_default_colors(){
qbg_color=15; qbg_background_color=0;
if (qbg_mode==0){qbg_color=7; qbg_background_color=0;}
if (qbg_mode==1){qbg_color=3; qbg_background_color=0;}
if (qbg_mode==2){qbg_color=1; qbg_background_color=0;}
if (qbg_mode==10){qbg_color=3; qbg_background_color=0;}
if (qbg_mode==11){qbg_color=1; qbg_background_color=0;}
return;
}


//############### SCREEN SUBS/FUNCTIONS BEGIN HERE
void qbg_screen(long mode,long color_switch,long active_page,long visual_page,long passed){
long i;

//PRE-ERROR CHECKING
//check if anything has changed, if not simply return
i=0;
if (passed&1){
if (qbg_mode!=mode) i=1;
if (mode<0) goto error;
if (mode==3) goto error;
if (mode==4) goto error;
if (mode==5) goto error;
if (mode==6) goto error;
if (mode>13) goto error;
}
if (passed&4){
if (qbg_active_page!=active_page) i=1;
if (active_page<0) goto error;
 if ((passed&8)==0){//if visual page not specified it is assumed to be the active page!
 passed+=8;
 visual_page=active_page;
 }
}
if (passed&8){
if (qbg_visual_page!=visual_page) i=1;
if (visual_page<0) goto error;
}
if (i==0) return;















//assume a standard mode


//change to new mode
if (passed&1){
if (mode!=qbg_mode){


if (full_screen_in_use){
SDL_FillRect(screen,NULL,0);//clear screen
}


//...remove old mode's data...
//...clear A000-C800
//memset(&cmem[655360],0,819200-655360);

//mode=13;
//qbg_width_in_characters=40; qbg_height_in_characters=43;

/*
Screen 13
  � 320 x 200 graphics
  � 40 x 25 text format, character box size of 8 x 8
  � Assignment of up to 256K colors to up to 256 attributes
*/
if (mode==13){
qbg_mode=13;
qbg_text_only=0;
//text & graphics modes
qbg_height_in_characters=25; qbg_width_in_characters=40;
qbg_top_row=1; qbg_bottom_row=24;
qbg_cursor_x=1; qbg_cursor_y=1;
qbg_character_height=8; qbg_character_width=8;
qbg_color=15; qbg_background_color=0;
//text mode ONLY
qbg_cursor_show=0;
qbg_cursor_firstvalue=0; qbg_cursor_lastvalue=0;//these values need revision
//graphics modes ONLY
qbg_width=320; qbg_height=200;
qbg_x=160; qbg_y=100;
qbg_bits_per_pixel=8; qbg_pixel_mask=0xFF; //for monochrome modes 1b, for 16 color 1111b, for 256 color 11111111b
qbg_bytes_per_pixel=1;
qbg_clipping_or_scaling=0;//1=clipping, 2=clipping and scaling
qbg_view_x1=0; qbg_view_y1=0; qbg_view_x2=319; qbg_view_y2=199;
qbg_view_offset_x=0; qbg_view_offset_y=0;
qbg_scaling_x=1; qbg_scaling_y=1;
qbg_scaling_offset_x=0; qbg_scaling_offset_y=0;
qbg_window_x1=0; qbg_window_y1=0; qbg_window_x2=319; qbg_window_y2=199;
qbg_pageoffsets=(unsigned long*)calloc(qbg_pages=1,4);
qbg_cursor_x_previous=(long*)calloc(qbg_pages,4); qbg_cursor_y_previous=(long*)calloc(qbg_pages,4);
qbg_active_page=0;
qbg_active_page_offset=&cmem[655360];
qbg_visual_page=0;
qbg_visual_page_offset=&cmem[655360];
qbg_restorepalette();
qbg_pageoffsets[0]=(unsigned long)&cmem[655360];
memset(qbg_active_page_offset,0,64000);
}//13

/*
Screen 12
  � 640 x 480 graphics
  � 80 x 30 or 80 x 60 text format, character box size of 8 x 16 or 8 x 8
  � Assignment of up to 256K colors to 16 attributes
  � VGA required
*/
if (mode==12){
qbg_mode=12;
qbg_text_only=0;
//text & graphics modes
if ((qbg_width_in_characters==80)&&(qbg_height_in_characters==60)){
qbg_height_in_characters=60; qbg_width_in_characters=80; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=8; qbg_character_width=8;
}else{
qbg_height_in_characters=30; qbg_width_in_characters=80; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=16; qbg_character_width=8;
}
qbg_cursor_x=1; qbg_cursor_y=1;
qbg_color=15; qbg_background_color=0;
//text mode ONLY
qbg_cursor_show=0;
qbg_cursor_firstvalue=0; qbg_cursor_lastvalue=0;//these values need revision
//graphics modes ONLY
qbg_width=640; qbg_height=480;
qbg_x=320; qbg_y=240;
qbg_bits_per_pixel=4; qbg_pixel_mask=0xF; //for monochrome modes 1b, for 16 color 1111b, for 256 color 11111111b
qbg_bytes_per_pixel=1;
qbg_clipping_or_scaling=0;//1=clipping, 2=clipping and scaling
qbg_view_x1=0; qbg_view_y1=0; qbg_view_x2=qbg_width-1; qbg_view_y2=qbg_height-1;
qbg_view_offset_x=0; qbg_view_offset_y=0;
qbg_scaling_x=1; qbg_scaling_y=1;
qbg_scaling_offset_x=0; qbg_scaling_offset_y=0;
qbg_window_x1=0; qbg_window_y1=0; qbg_window_x2=qbg_width-1; qbg_window_y2=qbg_height-1;
qbg_pageoffsets=(unsigned long*)calloc(qbg_pages=1,4);
qbg_cursor_x_previous=(long*)calloc(qbg_pages,4); qbg_cursor_y_previous=(long*)calloc(qbg_pages,4);
qbg_pageoffsets[0]=(unsigned long)calloc(307200,1);
qbg_active_page=0;
qbg_active_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_visual_page=0;
qbg_visual_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_restorepalette();
}//12

/*
Screen 11
  � 640 x 480 graphics
  � 80 x 30 or 80 x 60 text format, character box size of 8 x 16 or 8 x 8
  � Assignment of up to 256K colors to 2 attributes
*/
if (mode==11){
qbg_mode=11;
qbg_text_only=0;
//text & graphics modes
if ((qbg_width_in_characters==80)&&(qbg_height_in_characters==60)){
qbg_height_in_characters=60; qbg_width_in_characters=80; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=8; qbg_character_width=8;
}else{
qbg_height_in_characters=30; qbg_width_in_characters=80; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=16; qbg_character_width=8;
}
qbg_cursor_x=1; qbg_cursor_y=1;
qbg_color=1; qbg_background_color=0;
//text mode ONLY
qbg_cursor_show=0;
qbg_cursor_firstvalue=0; qbg_cursor_lastvalue=0;//these values need revision
//graphics modes ONLY
qbg_width=640; qbg_height=480;
qbg_x=320; qbg_y=240;
qbg_bits_per_pixel=4; qbg_pixel_mask=1; //for monochrome modes 1b, for 16 color 1111b, for 256 color 11111111b
qbg_bytes_per_pixel=1;
qbg_clipping_or_scaling=0;//1=clipping, 2=clipping and scaling
qbg_view_x1=0; qbg_view_y1=0; qbg_view_x2=qbg_width-1; qbg_view_y2=qbg_height-1;
qbg_view_offset_x=0; qbg_view_offset_y=0;
qbg_scaling_x=1; qbg_scaling_y=1;
qbg_scaling_offset_x=0; qbg_scaling_offset_y=0;
qbg_window_x1=0; qbg_window_y1=0; qbg_window_x2=qbg_width-1; qbg_window_y2=qbg_height-1;
qbg_pageoffsets=(unsigned long*)calloc(qbg_pages=1,4);
qbg_cursor_x_previous=(long*)calloc(qbg_pages,4); qbg_cursor_y_previous=(long*)calloc(qbg_pages,4);
qbg_pageoffsets[0]=(unsigned long)calloc(307200,1);
qbg_active_page=0;
qbg_active_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_visual_page=0;
qbg_visual_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_restorepalette();
}//11

//SCREEN 10: 640 x 350 graphics, monochrome monitor only
//  � 80 x 25 or 80 x 43 text format, 8 x 14 or 8 x 8 character box size
//  � 128K page size, page range is 0 (128K) or 0-1 (256K)
//  � Up to 9 pseudocolors assigned to 4 attributes
/*
'colors swap every half second!
'using PALETTE does NOT swap color indexes
'0 black-black
'1 black-grey
'2 black-white
'3 grey-black
'4 grey-grey
'5 grey-white
'6 white-black
'7 white-grey
'8 white-white
'*IMPORTANT* QB sets initial values up different to default palette!
'0 block-black(0)
'1 grey-grey(4)
'2 white-black(6)
'3 white-white(8)
*/
if (mode==10){
qbg_mode=10;
qbg_text_only=0;
//text & graphics modes
if ((qbg_width_in_characters==80)&&(qbg_height_in_characters==43)){
qbg_height_in_characters=43; qbg_width_in_characters=80; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=8; qbg_character_width=8;
}else{
qbg_height_in_characters=25; qbg_width_in_characters=80; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=14; qbg_character_width=8;
}
qbg_cursor_x=1; qbg_cursor_y=1;
qbg_color=3; qbg_background_color=0;
//text mode ONLY
qbg_cursor_show=0;
qbg_cursor_firstvalue=0; qbg_cursor_lastvalue=0;//these values need revision
//graphics modes ONLY
qbg_width=640; qbg_height=350;
qbg_x=320; qbg_y=175;
qbg_bits_per_pixel=2; qbg_pixel_mask=3; //for monochrome modes 1b, for 16 color 1111b, for 256 color 11111111b
qbg_bytes_per_pixel=1;
qbg_clipping_or_scaling=0;//1=clipping, 2=clipping and scaling
qbg_view_x1=0; qbg_view_y1=0; qbg_view_x2=qbg_width-1; qbg_view_y2=qbg_height-1;
qbg_view_offset_x=0; qbg_view_offset_y=0;
qbg_scaling_x=1; qbg_scaling_y=1;
qbg_scaling_offset_x=0; qbg_scaling_offset_y=0;
qbg_window_x1=0; qbg_window_y1=0; qbg_window_x2=qbg_width-1; qbg_window_y2=qbg_height-1;
qbg_pageoffsets=(unsigned long*)calloc(qbg_pages=2,4);
qbg_cursor_x_previous=(long*)calloc(qbg_pages,4); qbg_cursor_y_previous=(long*)calloc(qbg_pages,4);
qbg_pageoffsets[0]=(unsigned long)calloc(224000,1);
qbg_pageoffsets[1]=(unsigned long)calloc(224000,1);
qbg_active_page=0;
qbg_active_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_visual_page=0;
qbg_visual_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_restorepalette();
}//10

/*
SCREEN 9: 640 x 350 graphics
  � 80 x 25 or 80 x 43 text format, 8 x 14 or 8 x 8 character box size
  � 64K page size, page range is 0 (64K);
    128K page size, page range is 0 (128K) or 0-1 (256K)
  � 16 colors assigned to 4 attributes (64K adapter memory), or
    64 colors assigned to 16 attributes (more than 64K adapter memory)
*/
if (mode==9){
qbg_mode=9;
qbg_text_only=0;
//text & graphics modes
if ((qbg_width_in_characters==80)&&(qbg_height_in_characters==43)){
qbg_height_in_characters=43; qbg_width_in_characters=80; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=8; qbg_character_width=8;
}else{
qbg_height_in_characters=25; qbg_width_in_characters=80; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=14; qbg_character_width=8;
}
qbg_cursor_x=1; qbg_cursor_y=1;
qbg_color=15; qbg_background_color=0;
//text mode ONLY
qbg_cursor_show=0;
qbg_cursor_firstvalue=0; qbg_cursor_lastvalue=0;//these values need revision
//graphics modes ONLY
qbg_width=640; qbg_height=350;
qbg_x=320; qbg_y=175;
qbg_bits_per_pixel=4; qbg_pixel_mask=0xF; //for monochrome modes 1b, for 16 color 1111b, for 256 color 11111111b
qbg_bytes_per_pixel=1;
qbg_clipping_or_scaling=0;//1=clipping, 2=clipping and scaling
qbg_view_x1=0; qbg_view_y1=0; qbg_view_x2=qbg_width-1; qbg_view_y2=qbg_height-1;
qbg_view_offset_x=0; qbg_view_offset_y=0;
qbg_scaling_x=1; qbg_scaling_y=1;
qbg_scaling_offset_x=0; qbg_scaling_offset_y=0;
qbg_window_x1=0; qbg_window_y1=0; qbg_window_x2=qbg_width-1; qbg_window_y2=qbg_height-1;
qbg_pageoffsets=(unsigned long*)calloc(qbg_pages=1,4);
qbg_cursor_x_previous=(long*)calloc(qbg_pages,4); qbg_cursor_y_previous=(long*)calloc(qbg_pages,4);
qbg_pageoffsets[0]=(unsigned long)calloc(224000,1);
qbg_active_page=0;
qbg_active_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_visual_page=0;
qbg_visual_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_restorepalette();
}//9





/*
SCREEN 8: 640 x 200 graphics
  � 80 x 25 text format, 8 x 8 character box
  � 64K page size, page ranges are 0 (64K), 0-1 (128K), or 0-3 (246K)
  � Assignment of 16 colors to any of 16 attributes
*/
if (mode==8){
qbg_mode=8;
qbg_text_only=0;
//text & graphics modes
qbg_height_in_characters=25; qbg_width_in_characters=80; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=8; qbg_character_width=8;
qbg_cursor_x=1; qbg_cursor_y=1;
qbg_color=15; qbg_background_color=0;
//text mode ONLY
qbg_cursor_show=0;
qbg_cursor_firstvalue=0; qbg_cursor_lastvalue=0;//these values need revision
//graphics modes ONLY
qbg_width=640; qbg_height=200;
qbg_x=320; qbg_y=100;
qbg_bits_per_pixel=4; qbg_pixel_mask=0xF; //for monochrome modes 1b, for 16 color 1111b, for 256 color 11111111b
qbg_bytes_per_pixel=1;
qbg_clipping_or_scaling=0;//1=clipping, 2=clipping and scaling
qbg_view_x1=0; qbg_view_y1=0; qbg_view_x2=qbg_width-1; qbg_view_y2=qbg_height-1;
qbg_view_offset_x=0; qbg_view_offset_y=0;
qbg_scaling_x=1; qbg_scaling_y=1;
qbg_scaling_offset_x=0; qbg_scaling_offset_y=0;
qbg_window_x1=0; qbg_window_y1=0; qbg_window_x2=qbg_width-1; qbg_window_y2=qbg_height-1;
qbg_pageoffsets=(unsigned long*)calloc(qbg_pages=1,4);
qbg_cursor_x_previous=(long*)calloc(qbg_pages,4); qbg_cursor_y_previous=(long*)calloc(qbg_pages,4);
qbg_pageoffsets[0]=(unsigned long)calloc(128000,1);
qbg_active_page=0;
qbg_active_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_visual_page=0;
qbg_visual_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_restorepalette();
}//8



/*
SCREEN 7: 320 x 200 graphics
  � 40 x 25 text format, character box size 8 x 8
  � 32K page size, page ranges are 0-1 (64K), 0-3 (128K), or 0-7 (256K)
  � Assignment of 16 colors to any of 16 attributes
*/
if (mode==7){
qbg_mode=7;
qbg_text_only=0;
//text & graphics modes
qbg_height_in_characters=25; qbg_width_in_characters=40; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=8; qbg_character_width=8;
qbg_cursor_x=1; qbg_cursor_y=1;
qbg_color=15; qbg_background_color=0;
//text mode ONLY
qbg_cursor_show=0;
qbg_cursor_firstvalue=0; qbg_cursor_lastvalue=0;//these values need revision
//graphics modes ONLY
qbg_width=320; qbg_height=200;
qbg_x=160; qbg_y=100;
qbg_bits_per_pixel=4; qbg_pixel_mask=0xF; //for monochrome modes 1b, for 16 color 1111b, for 256 color 11111111b
qbg_bytes_per_pixel=1;
qbg_clipping_or_scaling=0;//1=clipping, 2=clipping and scaling
qbg_view_x1=0; qbg_view_y1=0; qbg_view_x2=qbg_width-1; qbg_view_y2=qbg_height-1;
qbg_view_offset_x=0; qbg_view_offset_y=0;
qbg_scaling_x=1; qbg_scaling_y=1;
qbg_scaling_offset_x=0; qbg_scaling_offset_y=0;
qbg_window_x1=0; qbg_window_y1=0; qbg_window_x2=qbg_width-1; qbg_window_y2=qbg_height-1;
qbg_pageoffsets=(unsigned long*)calloc(qbg_pages=1,4);
qbg_cursor_x_previous=(long*)calloc(qbg_pages,4); qbg_cursor_y_previous=(long*)calloc(qbg_pages,4);
qbg_pageoffsets[0]=(unsigned long)calloc(64000,1);
qbg_active_page=0;
qbg_active_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_visual_page=0;
qbg_visual_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_restorepalette();
}//7

/*
SCREEN 4:
  � Supports Olivetti (R) Personal Computers models M24, M240, M28,
    M280, M380, M380/C, M380/T and AT&T (R) Personal Computers 6300
    series
  � 640 x 400 graphics
  � 80 x 25 text format, 8 x 16 character box
  � 1 of 16 colors assigned as the foreground color (selected by the
    COLOR statement); background is fixed at black.
*/
//Note: QB64 will not support SCREEN 4

/*
SCREEN 3: Hercules adapter required, monochrome monitor only
  � 720 x 348 graphics
  � 80 x 25 text format, 9 x 14 character box
  � 2 screen pages (1 only if a second display adapter is installed)
  � PALETTE statement not supported
*/
//Note: QB64 will not support SCREEN 3

/*
SCREEN 2: 640 x 200 graphics
  � 80 x 25 text format with character box size of 8 x 8
  � 16 colors assigned to 2 attributes with EGA or VGA
*/
if (mode==2){
qbg_mode=2;
qbg_text_only=0;
//text & graphics modes
qbg_height_in_characters=25; qbg_width_in_characters=80; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=8; qbg_character_width=8;
qbg_cursor_x=1; qbg_cursor_y=1;
qbg_color=1; qbg_background_color=0;
//text mode ONLY
qbg_cursor_show=0;
qbg_cursor_firstvalue=0; qbg_cursor_lastvalue=0;//these values need revision
//graphics modes ONLY
qbg_width=640; qbg_height=200;
qbg_x=320; qbg_y=100;
qbg_bits_per_pixel=1; qbg_pixel_mask=0x1; //for monochrome modes 1b, for 16 color 1111b, for 256 color 11111111b
qbg_bytes_per_pixel=1;
qbg_clipping_or_scaling=0;//1=clipping, 2=clipping and scaling
qbg_view_x1=0; qbg_view_y1=0; qbg_view_x2=qbg_width-1; qbg_view_y2=qbg_height-1;
qbg_view_offset_x=0; qbg_view_offset_y=0;
qbg_scaling_x=1; qbg_scaling_y=1;
qbg_scaling_offset_x=0; qbg_scaling_offset_y=0;
qbg_window_x1=0; qbg_window_y1=0; qbg_window_x2=qbg_width-1; qbg_window_y2=qbg_height-1;
qbg_pageoffsets=(unsigned long*)calloc(qbg_pages=1,4);
qbg_cursor_x_previous=(long*)calloc(qbg_pages,4); qbg_cursor_y_previous=(long*)calloc(qbg_pages,4);
qbg_pageoffsets[0]=(unsigned long)calloc(128000,1);
qbg_active_page=0;
qbg_active_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_visual_page=0;
qbg_visual_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_restorepalette();
}//2

/*
SCREEN 1: 320 x 200 graphics
  � 40 x 25 text format, 8 x 8 character box
  � 16 background colors and one of two sets of 3 foreground colors assigned
    using COLOR statement with CGA
  � 16 colors assigned to 4 attributes with EGA or VGA
*/
if (mode==1){
qbg_mode=1;
qbg_text_only=0;
//text & graphics modes
qbg_height_in_characters=25; qbg_width_in_characters=40; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=8; qbg_character_width=8;
qbg_cursor_x=1; qbg_cursor_y=1;
qbg_color=3; qbg_background_color=0;
//text mode ONLY
qbg_cursor_show=0;
qbg_cursor_firstvalue=0; qbg_cursor_lastvalue=0;//these values need revision
//graphics modes ONLY
qbg_width=320; qbg_height=200;
qbg_x=160; qbg_y=100;
qbg_bits_per_pixel=2; qbg_pixel_mask=3; //for monochrome modes 1b, for 16 color 1111b, for 256 color 11111111b
qbg_bytes_per_pixel=1;
qbg_clipping_or_scaling=0;//1=clipping, 2=clipping and scaling
qbg_view_x1=0; qbg_view_y1=0; qbg_view_x2=qbg_width-1; qbg_view_y2=qbg_height-1;
qbg_view_offset_x=0; qbg_view_offset_y=0;
qbg_scaling_x=1; qbg_scaling_y=1;
qbg_scaling_offset_x=0; qbg_scaling_offset_y=0;
qbg_window_x1=0; qbg_window_y1=0; qbg_window_x2=qbg_width-1; qbg_window_y2=qbg_height-1;
qbg_pageoffsets=(unsigned long*)calloc(qbg_pages=1,4);
qbg_cursor_x_previous=(long*)calloc(qbg_pages,4); qbg_cursor_y_previous=(long*)calloc(qbg_pages,4);
qbg_pageoffsets[0]=(unsigned long)calloc(64000,1);
qbg_active_page=0;
qbg_active_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_visual_page=0;
qbg_visual_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_restorepalette();
}//1

/*
                MDPA, CGA, EGA, or VGA Adapter Boards
SCREEN 0: Text mode only
  � Either 40 x 25, 40 x 43, 40 x 50, 80 x 25, 80 x 43, or 80 x 50 text format
    with 8 x 8 character box size (8 x 14, 9 x 14, or 9 x 16 with EGA or VGA)
  � 16 colors assigned to 2 attributes
  � 16 colors assigned to any of 16 attributes (with CGA or EGA)
  � 64 colors assigned to any of 16 attributes (with EGA or VGA)
*/
if (mode==0){
qbg_mode=0;
qbg_text_only=1;
//text & graphics modes

if ((qbg_width_in_characters==80)&&(qbg_height_in_characters==50)){
qbg_width_in_characters=80; qbg_height_in_characters=50; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=8; qbg_character_width=8;
i=8000;
goto qbg_mode0_width_acquired;
}
if ((qbg_width_in_characters==40)&&(qbg_height_in_characters==50)){
qbg_width_in_characters=40; qbg_height_in_characters=50; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=8; qbg_character_width=16;
i=4000;
goto qbg_mode0_width_acquired;
}
if ((qbg_width_in_characters==80)&&(qbg_height_in_characters==43)){
qbg_width_in_characters=80; qbg_height_in_characters=43; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=8; qbg_character_width=8;
i=6880;
goto qbg_mode0_width_acquired;
}
if ((qbg_width_in_characters==40)&&(qbg_height_in_characters==43)){
qbg_width_in_characters=40; qbg_height_in_characters=43; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=8; qbg_character_width=16;
i=3440;
goto qbg_mode0_width_acquired;
}
if ((qbg_width_in_characters==40)&&(qbg_height_in_characters==25)){
qbg_width_in_characters=40; qbg_height_in_characters=25; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=16; qbg_character_width=16;
i=2048;
goto qbg_mode0_width_acquired;
}
qbg_width_in_characters=80; qbg_height_in_characters=25; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=16; qbg_character_width=8;
i=4096;
qbg_mode0_width_acquired:
qbg_cursor_x=1; qbg_cursor_y=1;
qbg_color=7; qbg_background_color=0;
//text mode ONLY
qbg_cursor_show=0; qbg_cursor_firstvalue=4; qbg_cursor_lastvalue=4;


//graphics modes ONLY
//N/A
/*
granularity from &HB800
4096 in 80x25
2048 in 40x25
6880 in 80x43 (80x43x2=6880)
3440 in 40x43 (40x43x2=3440)
8000 in 80x50 (80x50x2=8000)
4000 in 40x50 (40x50x2=4000)
*/
qbg_pageoffsets=(unsigned long*)calloc(qbg_pages=8,4);
qbg_cursor_x_previous=(long*)calloc(qbg_pages,4); qbg_cursor_y_previous=(long*)calloc(qbg_pages,4);
qbg_pageoffsets[0]=(unsigned long)&cmem[753664+i*0];
qbg_pageoffsets[1]=(unsigned long)&cmem[753664+i*1];
qbg_pageoffsets[2]=(unsigned long)&cmem[753664+i*2];
qbg_pageoffsets[3]=(unsigned long)&cmem[753664+i*3];
qbg_pageoffsets[4]=(unsigned long)&cmem[753664+i*4];
qbg_pageoffsets[5]=(unsigned long)&cmem[753664+i*5];
qbg_pageoffsets[6]=(unsigned long)&cmem[753664+i*6];
qbg_pageoffsets[7]=(unsigned long)&cmem[753664+i*7];
qbg_active_page=0;
qbg_active_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_visual_page=0;
qbg_visual_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_restorepalette();
//clear video page memory using [32,7] words
for (i=0;i<65536;i+=2){cmem[753664+i]=32; cmem[753664+i+1]=7;}

}//0

}//setmode
}//passed MODE

if ((passed&4)&&(active_page!=qbg_active_page)){
	validate_video_page(active_page);
	qbg_cursor_x_previous[qbg_active_page]=qbg_cursor_x; qbg_cursor_y_previous[qbg_active_page]=qbg_cursor_y;
	if (qbg_cursor_x_previous[active_page]){
		qbg_cursor_x=qbg_cursor_x_previous[active_page]; qbg_cursor_y=qbg_cursor_y_previous[active_page];
	}else{
		qbg_cursor_x=1; qbg_cursor_y=1;
	}
	qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
	select_default_colors();
	qbg_active_page_offset=(unsigned char*)qbg_pageoffsets[active_page];
	qbg_active_page=active_page;
}

if ((passed&8)&&(visual_page!=qbg_visual_page)){
	validate_video_page(visual_page);
	qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
	select_default_colors();
	qbg_visual_page_offset=(unsigned char*)qbg_pageoffsets[visual_page];
	qbg_visual_page=visual_page;
}



return;
error:
error(5);
return;
}//qbg_screen (end)


void sub_pcopy(long sourcepage,long destpage){
if (sourcepage<0) goto error;
if (destpage<0) goto error;
validate_video_page(sourcepage);
validate_video_page(destpage);
if (qbg_mode==0){
memcpy((char*)qbg_pageoffsets[destpage],(char*)qbg_pageoffsets[sourcepage],qbg_height_in_characters*qbg_width_in_characters*2);
}else{
memcpy((char*)qbg_pageoffsets[destpage],(char*)qbg_pageoffsets[sourcepage],qbg_height*qbg_width*qbg_bytes_per_pixel);
}
return;
error:
error(5);
return;
}


void qbsub_width(long option,long value1,long value2,long passed){
long i;
//[{#|LPRINT}][?],[?]
if (option==0){//change screen width (no special override character encountered)
//FIX UP PASSED BEFORE GOING ANY FURTHER WITH THIS FUNCTION!!
if (!(passed&1)) value1=qbg_width_in_characters;
if (!(passed&2)) value2=qbg_height_in_characters;
if ((qbg_width_in_characters==value1)&&(qbg_height_in_characters==value2)) return;
//check validity of input
if ((qbg_mode==13)||(qbg_mode==7)||(qbg_mode==7)){
if ((value1!=40)||(value2!=25)) goto qbsub_width_error;
}
if ((qbg_mode==12)||(qbg_mode==11)){
if (value1!=80) goto qbsub_width_error;
if ((value2!=30)&&(value2!=60)) goto qbsub_width_error;
}
if ((qbg_mode==10)||(qbg_mode==9)){
if (value1!=80) goto qbsub_width_error;
if ((value2!=25)&&(value2!=43)) goto qbsub_width_error;
}
if ((qbg_mode==8)||(qbg_mode==2)){
if (value1!=80) goto qbsub_width_error;
if (value2!=25) goto qbsub_width_error;
}
if (qbg_mode==0){
if ((value1!=80)&&(value1!=40)) goto qbsub_width_error;
if ((value2!=50)&&(value2!=43)&&(value2!=25)) goto qbsub_width_error;
}
//input is valid, force a screenmode changing the value of the current screen mode
qbg_width_in_characters=value1; qbg_height_in_characters=value2;
i=qbg_mode;
qbg_mode=-1;
qbg_screen(i,0,0,0,1);
return;
qbsub_width_error:
//DUE TO AN ERROR IN QBASIC, IT CAN JUMP-BACK TO TEXT MODE
//QB64 WILL HANDLE THIS CONDITION IN THE SAME MANNER
if ((value1!=80)&&(value1!=40)) goto qbsub_width_error2;
if ((value2!=50)&&(value2!=43)&&(value2!=25)) goto qbsub_width_error2;
qbg_width_in_characters=value1; qbg_height_in_characters=value2;
i=qbg_mode;
qbg_mode=-1;
qbg_screen(i,0,0,0,1);
return;
qbsub_width_error2:
error(5);
return;
}

//file/device?
//...
//printer?
//...
}

inline void pset(long x,long y,unsigned long col){//does not clip!
if (qbg_bytes_per_pixel==1){
qbg_active_page_offset[y*qbg_width+x]=col&qbg_pixel_mask;
}else{
//...(requires real color support)
}
return;
}

inline void pset_and_clip(long x,long y,unsigned long col){
if ((x>=qbg_view_x1)&&(x<=qbg_view_x2)&&(y>=qbg_view_y1)&&(y<=qbg_view_y2)){
if (qbg_bytes_per_pixel==1){
qbg_active_page_offset[y*qbg_width+x]=col&qbg_pixel_mask;
}else{
//...(requires real color support)
}
}//within viewport
return;
}

void qb32_boxfill(float x1f,float y1f,float x2f,float y2f,unsigned long col){
static long x1,y1,x2,y2,i,width;
static unsigned char *p;

//resolve coordinates
if (qbg_clipping_or_scaling){
if (qbg_clipping_or_scaling==2){
x1=qbr_float_to_long(x1f*qbg_scaling_x+qbg_scaling_offset_x)+qbg_view_offset_x;
y1=qbr_float_to_long(y1f*qbg_scaling_y+qbg_scaling_offset_y)+qbg_view_offset_y;
x2=qbr_float_to_long(x2f*qbg_scaling_x+qbg_scaling_offset_x)+qbg_view_offset_x;
y2=qbr_float_to_long(y2f*qbg_scaling_y+qbg_scaling_offset_y)+qbg_view_offset_y;
}else{
x1=qbr_float_to_long(x1f)+qbg_view_offset_x; y1=qbr_float_to_long(y1f)+qbg_view_offset_y;
x2=qbr_float_to_long(x2f)+qbg_view_offset_x; y2=qbr_float_to_long(y2f)+qbg_view_offset_y;
}
}else{
x1=qbr_float_to_long(x1f); y1=qbr_float_to_long(y1f);
x2=qbr_float_to_long(x2f); y2=qbr_float_to_long(y2f);
}

//swap coordinates (if necessary)
if (x1>x2){i=x1; x1=x2; x2=i;}
if (y1>y2){i=y1; y1=y2; y2=i;}

//exit without rendering if necessary
if (x2<qbg_view_x1) return;
if (x1>qbg_view_x2) return;
if (y2<qbg_view_y1) return;
if (y1>qbg_view_y2) return;

//crop coordinates
if (x1<qbg_view_x1) x1=qbg_view_x1;
if (y1<qbg_view_y1) y1=qbg_view_y1;
if (x1>qbg_view_x2) x1=qbg_view_x2;
if (y1>qbg_view_y2) y1=qbg_view_y2;
if (x2<qbg_view_x1) x2=qbg_view_x1;
if (y2<qbg_view_y1) y2=qbg_view_y1;
if (x2>qbg_view_x2) x2=qbg_view_x2;
if (y2>qbg_view_y2) y2=qbg_view_y2;

//apply mask to color to avoid incorrect color values
col&=qbg_pixel_mask;

if (qbg_bytes_per_pixel==1){
width=x2-x1+1;
p=qbg_active_page_offset+y1*qbg_width+x1;
i=y2-y1+1;
loop1:
memset(p,col,width);
p+=qbg_width;
if (--i) goto loop1;
return;
}//==1

//?

}










//copied from qb32_line with the following modifications
//i. pre-WINDOW'd & VIEWPORT'd long co-ordinates
//ii. all references to style & lineclip_skippixels commented
//iii. declaration of x1,y1,x2,y2,x1f,y1f changed, some declarations removed
void fast_line(long x1,long y1,long x2,long y2,unsigned long col){
static long l,l2,mi;
static float m,x1f,y1f;

lineclip(x1,y1,x2,y2,qbg_view_x1,qbg_view_y1,qbg_view_x2,qbg_view_y2);

//style=(style&65535)+(style<<16);
//lineclip_skippixels&=15;
//style=_lrotl(style,lineclip_skippixels);

if (lineclip_draw){
l=abs(lineclip_x1-lineclip_x2);
l2=abs(lineclip_y1-lineclip_y2);
if (l>l2){

//x-axis distance is larger
y1f=lineclip_y1;
if (l){//following only applies if drawing more than one pixel
m=((float)lineclip_y2-(float)lineclip_y1)/(float)l;
if (lineclip_x2>=lineclip_x1) mi=1; else mi=-1;//direction of change
}
l++;
while (l--){
if (y1f<0) lineclip_y1=y1f-0.5f; else lineclip_y1=y1f+0.5f;

//if ((style=_lrotl(style,1))&1){
pset(lineclip_x1,lineclip_y1,col);
//}

lineclip_x1+=mi;
y1f+=m;
}

}else{

//y-axis distance is larger
x1f=lineclip_x1;
if (l2){//following only applies if drawing more than one pixel
m=((float)lineclip_x2-(float)lineclip_x1)/(float)l2;
if (lineclip_y2>=lineclip_y1) mi=1; else mi=-1;//direction of change
}
l2++;
while (l2--){
if (x1f<0) lineclip_x1=x1f-0.5f; else lineclip_x1=x1f+0.5f;
//if ((style=_lrotl(style,1))&1){
pset(lineclip_x1,lineclip_y1,col);
//}
lineclip_y1+=mi;
x1f+=m;
}

}

}//lineclip_draw
return;
}























void qb32_line(float x1f,float y1f,float x2f,float y2f,unsigned long col,unsigned long style){
static long x1,y1,x2,y2,l,l2,mi;
static float m;

//resolve coordinates
if (qbg_clipping_or_scaling){
if (qbg_clipping_or_scaling==2){
x1=qbr_float_to_long(x1f*qbg_scaling_x+qbg_scaling_offset_x)+qbg_view_offset_x;
y1=qbr_float_to_long(y1f*qbg_scaling_y+qbg_scaling_offset_y)+qbg_view_offset_y;
x2=qbr_float_to_long(x2f*qbg_scaling_x+qbg_scaling_offset_x)+qbg_view_offset_x;
y2=qbr_float_to_long(y2f*qbg_scaling_y+qbg_scaling_offset_y)+qbg_view_offset_y;
}else{
x1=qbr_float_to_long(x1f)+qbg_view_offset_x; y1=qbr_float_to_long(y1f)+qbg_view_offset_y;
x2=qbr_float_to_long(x2f)+qbg_view_offset_x; y2=qbr_float_to_long(y2f)+qbg_view_offset_y;
}
}else{
x1=qbr_float_to_long(x1f); y1=qbr_float_to_long(y1f);
x2=qbr_float_to_long(x2f); y2=qbr_float_to_long(y2f);
}

lineclip(x1,y1,x2,y2,qbg_view_x1,qbg_view_y1,qbg_view_x2,qbg_view_y2);

style=(style&65535)+(style<<16);
lineclip_skippixels&=15;
style=_lrotl(style,lineclip_skippixels);

if (lineclip_draw){
l=abs(lineclip_x1-lineclip_x2);
l2=abs(lineclip_y1-lineclip_y2);
if (l>l2){

//x-axis distance is larger
y1f=lineclip_y1;
if (l){//following only applies if drawing more than one pixel
m=((float)lineclip_y2-(float)lineclip_y1)/(float)l;
if (lineclip_x2>=lineclip_x1) mi=1; else mi=-1;//direction of change
}
l++;
while (l--){
if (y1f<0) lineclip_y1=y1f-0.5f; else lineclip_y1=y1f+0.5f;

if ((style=_lrotl(style,1))&1){
pset(lineclip_x1,lineclip_y1,col);
}

lineclip_x1+=mi;
y1f+=m;
}

}else{

//y-axis distance is larger
x1f=lineclip_x1;
if (l2){//following only applies if drawing more than one pixel
m=((float)lineclip_x2-(float)lineclip_x1)/(float)l2;
if (lineclip_y2>=lineclip_y1) mi=1; else mi=-1;//direction of change
}
l2++;
while (l2--){
if (x1f<0) lineclip_x1=x1f-0.5f; else lineclip_x1=x1f+0.5f;
if ((style=_lrotl(style,1))&1){
pset(lineclip_x1,lineclip_y1,col);
}
lineclip_y1+=mi;
x1f+=m;
}

}

}//lineclip_draw
return;
}


void sub_line(long step1,float x1,float y1,long step2,float x2,float y2,unsigned long col,long bf,unsigned long style,long passed){
//format: [{STEP}][(?,?)]-[{STEP}](?,?),[?],[{B|BF}],[?]
//                  1 2                  4            8

//[[{STEP}](?,?)]-[{STEP}](?,?)[,[?][,[{B|BF}][,?]]]
//          1                     2             4

//adjust coordinates and qb graphics cursor position based on STEP
if (passed&1){
if (step1){x1=qbg_x+x1; y1=qbg_y+y1;}
qbg_x=x1; qbg_y=y1;
}else{
x1=qbg_x; y1=qbg_y;
}
if (step2){x2=qbg_x+x2; y2=qbg_y+y2;}
qbg_x=x2; qbg_y=y2;

if (bf==0){//line
if ((passed&4)==0) style=0xFFFF;
if ((passed&2)==0) col=qbg_color;
qb32_line(x1,y1,x2,y2,col,style);
return;
}

if (bf==1){//rectangle
if ((passed&4)==0) style=0xFFFF;
if ((passed&2)==0) col=qbg_color;
qb32_line(x1,y1,x2,y1,col,style);
qb32_line(x2,y1,x2,y2,col,style);
qb32_line(x2,y2,x1,y2,col,style);
qb32_line(x1,y2,x1,y1,col,style);
return;
}

if (bf==2){//filled box
if ((passed&2)==0) col=qbg_color;
qb32_boxfill(x1,y1,x2,y2,col);
return;
}

}//sub_line


































void sub_paint(long step,float x,float y,unsigned long fillcol,unsigned long bordercol,qbs *backgroundstr,long passed){
//uses 2 buffers, a and b, and swaps between them for reading and creating
static unsigned long a_n=0;
static unsigned short *a_x=(unsigned short*)malloc(2*65536),*a_y=(unsigned short*)malloc(2*65536);
static unsigned char *a_t=(unsigned char*)malloc(65536);
static unsigned long b_n=0;
static unsigned short *b_x=(unsigned short*)malloc(2*65536),*b_y=(unsigned short*)malloc(2*65536);
static unsigned char *b_t=(unsigned char*)malloc(65536);
static unsigned char *done=(unsigned char*)calloc(640*480,1);
static long ix,iy,i,t,x2,y2;
static unsigned long offset;
static unsigned char *cp;
static unsigned short *sp;



if (qbg_text_only){error(5); return;}
if (passed&4){error(5); return;}
if ((passed&1)==0) fillcol=qbg_color;
if ((passed&2)==0) bordercol=fillcol;
fillcol&=qbg_pixel_mask;
bordercol&=qbg_pixel_mask;

if (step){qbg_x+=x; qbg_y+=y;}else{qbg_x=x; qbg_y=y;}

if (qbg_clipping_or_scaling){
if (qbg_clipping_or_scaling==2){
ix=qbr_float_to_long(qbg_x*qbg_scaling_x+qbg_scaling_offset_x)+qbg_view_offset_x;
iy=qbr_float_to_long(qbg_y*qbg_scaling_y+qbg_scaling_offset_y)+qbg_view_offset_y;
}else{
ix=qbr_float_to_long(qbg_x)+qbg_view_offset_x; iy=qbr_float_to_long(qbg_y)+qbg_view_offset_y;
}
}else{
ix=qbr_float_to_long(qbg_x); iy=qbr_float_to_long(qbg_y);
}

//return if offscreen
if ((ix<qbg_view_x1)||(iy<qbg_view_y1)||(ix>qbg_view_x2)||(iy>qbg_view_y2)){
return;
}

//return if first point is the bordercolor
if (qbg_active_page_offset[iy*qbg_width+ix]==bordercol) return;

//create first node
a_x[0]=ix; a_y[0]=iy;
a_t[0]=15;
//types:
//&1=check left
//&2=check right
//&4=check above
//&8=check below

a_n=1;
qbg_active_page_offset[iy*qbg_width+ix]=fillcol;
done[iy*qbg_width+ix]=1;

nextpass:
b_n=0;
for (i=0;i<a_n;i++){
t=a_t[i]; ix=a_x[i]; iy=a_y[i];

//left
if (t&1){
x2=ix-1; y2=iy;
if (x2>=qbg_view_x1){
offset=y2*qbg_width+x2;
if (!done[offset]){
done[offset]=1;
if (qbg_active_page_offset[offset]!=bordercol){
qbg_active_page_offset[offset]=fillcol;
b_t[b_n]=13; b_x[b_n]=x2; b_y[b_n]=y2; b_n++;//add new node
}}}}

//right
if (t&2){
x2=ix+1; y2=iy;
if (x2<=qbg_view_x2){
offset=y2*qbg_width+x2;
if (!done[offset]){
done[offset]=1;
if (qbg_active_page_offset[offset]!=bordercol){
qbg_active_page_offset[offset]=fillcol;
b_t[b_n]=14; b_x[b_n]=x2; b_y[b_n]=y2; b_n++;//add new node
}}}}

//above
if (t&4){
x2=ix; y2=iy-1;
if (y2>=qbg_view_y1){
offset=y2*qbg_width+x2;
if (!done[offset]){
done[offset]=1;
if (qbg_active_page_offset[offset]!=bordercol){
qbg_active_page_offset[offset]=fillcol;
b_t[b_n]=7; b_x[b_n]=x2; b_y[b_n]=y2; b_n++;//add new node
}}}}

//below
if (t&8){
x2=ix; y2=iy+1;
if (y2<=qbg_view_y2){
offset=y2*qbg_width+x2;
if (!done[offset]){
done[offset]=1;
if (qbg_active_page_offset[offset]!=bordercol){
qbg_active_page_offset[offset]=fillcol;
b_t[b_n]=11; b_x[b_n]=x2; b_y[b_n]=y2; b_n++;//add new node
}}}}

}//i

//no new nodes?
if (b_n==0){
memset(done,0,qbg_width*qbg_height);//cleanup
return;//finished!
}

//swap a & b arrays
sp=a_x; a_x=b_x; b_x=sp;
sp=a_y; a_y=b_y; b_y=sp;
cp=a_t; a_t=b_t; b_t=cp;
a_n=b_n;

goto nextpass;

}





void sub_paint(long step,float x,float y,qbs *fillstr,unsigned long bordercol,qbs *backgroundstr,long passed){

//uses 2 buffers, a and b, and swaps between them for reading and creating
static unsigned long fillcol=0;//stub
static unsigned long a_n=0;
static unsigned short *a_x=(unsigned short*)malloc(2*65536),*a_y=(unsigned short*)malloc(2*65536);
static unsigned char *a_t=(unsigned char*)malloc(65536);
static unsigned long b_n=0;
static unsigned short *b_x=(unsigned short*)malloc(2*65536),*b_y=(unsigned short*)malloc(2*65536);
static unsigned char *b_t=(unsigned char*)malloc(65536);
static unsigned char *done=(unsigned char*)calloc(640*480,1);
static long ix,iy,i,t,x2,y2;
static unsigned long offset;
static unsigned char *cp;
static unsigned short *sp;
static unsigned long backgroundcol;

if (qbg_text_only){error(5); return;}
if ((passed&1)==0){error(5); return;}//must be called with this parameter!

//STEP 1: create the tile in a buffer (tile) using the source string
static unsigned char tilestr[256];
static unsigned char tile[8][64];
static long sx,sy;
static long bytesperrow;
static long row2offset;
static long row3offset;
static long row4offset;
static long byte;
static long bitvalue;
static long c;
if (fillstr->len==0){error(5); return;}
if (qbg_bits_per_pixel==4){
if (fillstr->len>256){error(5); return;}
}else{
if (fillstr->len>64){error(5); return;}
}
memset(&tilestr[0],0,256);
memcpy(&tilestr[0],fillstr->chr,fillstr->len);
sx=8; sy=fillstr->len; //defaults
if (qbg_bits_per_pixel==8) sx=1;
if (qbg_bits_per_pixel==4){
if (fillstr->len&3){
sy=(fillstr->len-(fillstr->len&3)+4)>>2;
}else{
sy=fillstr->len>>2;
}
bytesperrow=sx>>3; if (sx&7) bytesperrow++;
row2offset=bytesperrow;
row3offset=bytesperrow*2;
row4offset=bytesperrow*3;
}
if (qbg_bits_per_pixel==2) sx=4;
//use modified "PUT" routine to create the tile
cp=&tilestr[0];
{//layer
static long x,y;
for (y=0;y<sy;y++){
if (qbg_bits_per_pixel==4){
bitvalue=128;
byte=0;
}
for (x=0;x<sx;x++){
//get colour
if (qbg_bits_per_pixel==8){
 c=*cp;
 cp++;
}
if (qbg_bits_per_pixel==4){
byte=x>>3;
c=0;
if (cp[byte]&bitvalue) c|=1;
if (cp[row2offset+byte]&bitvalue) c|=2;
if (cp[row3offset+byte]&bitvalue) c|=4;
if (cp[row4offset+byte]&bitvalue) c|=8;
bitvalue>>=1; if (bitvalue==0) bitvalue=128;
}
if (qbg_bits_per_pixel==1){
 if (!(x&7)){
  byte=*cp;
  cp++;
 }
 c=(byte&128)>>7; byte<<=1;
}
if (qbg_bits_per_pixel==2){
 if (!(x&3)){
  byte=*cp;
  cp++;
 }
 c=(byte&192)>>6; byte<<=2;
}
//"pset" color
tile[x][y]=c;
}//x
if (qbg_bits_per_pixel==4) cp+=(bytesperrow*4);
if (qbg_bits_per_pixel==1){
 if (sx&7) cp++;
}
if (qbg_bits_per_pixel==2){
 if (sx&3) cp++;
}
}//y
}//unlayer
//tile created!

//STEP 2: establish border and background colors
if ((passed&2)==0) bordercol=qbg_color;
bordercol&=qbg_pixel_mask;

backgroundcol=0;//default
if (passed&4){
if (backgroundstr->len==0){error(5); return;}
if (backgroundstr->len>255){error(5); return;}
if (qbg_bits_per_pixel==1){
c=backgroundstr->chr[0];
if ((c>0)&&(c<255)) backgroundcol=-1;//unclear definition
if (c==255) backgroundcol=1;
}
if (qbg_bits_per_pixel==2){
backgroundcol=-1;//unclear definition
x2=backgroundstr->chr[0];
y2=x2&3;
x2>>=2; if ((x2&3)!=y2) goto uncleardef;
x2>>=2; if ((x2&3)!=y2) goto uncleardef;
x2>>=2; if ((x2&3)!=y2) goto uncleardef;
backgroundcol=y2;
}
if (qbg_bits_per_pixel==4){
backgroundcol=-1;//unclear definition
y2=0;
x2=4; if (backgroundstr->len<4) x2=backgroundstr->len;
c=0; memcpy(&c,backgroundstr->chr,x2);
x2=c&255; c>>=8; if ((x2!=0)&&(x2!=255)) goto uncleardef;
y2|=(x2&1);
x2=c&255; c>>=8; if ((x2!=0)&&(x2!=255)) goto uncleardef;
y2|=((x2&1)<<1);
x2=c&255; c>>=8; if ((x2!=0)&&(x2!=255)) goto uncleardef;
y2|=((x2&1)<<2);
x2=c&255; c>>=8; if ((x2!=0)&&(x2!=255)) goto uncleardef;
y2|=((x2&1)<<3);
backgroundcol=y2;
}
if (qbg_bits_per_pixel==8){
backgroundcol=backgroundstr->chr[0];
}
}
uncleardef:

//STEP 3: perform tile'd fill
if (step){qbg_x+=x; qbg_y+=y;}else{qbg_x=x; qbg_y=y;}
if (qbg_clipping_or_scaling){
if (qbg_clipping_or_scaling==2){
ix=qbr_float_to_long(qbg_x*qbg_scaling_x+qbg_scaling_offset_x)+qbg_view_offset_x;
iy=qbr_float_to_long(qbg_y*qbg_scaling_y+qbg_scaling_offset_y)+qbg_view_offset_y;
}else{
ix=qbr_float_to_long(qbg_x)+qbg_view_offset_x; iy=qbr_float_to_long(qbg_y)+qbg_view_offset_y;
}
}else{
ix=qbr_float_to_long(qbg_x); iy=qbr_float_to_long(qbg_y);
}

//return if offscreen
if ((ix<qbg_view_x1)||(iy<qbg_view_y1)||(ix>qbg_view_x2)||(iy>qbg_view_y2)){
return;
}

offset=iy*qbg_width+ix;

//return if first point is the bordercolor
if (qbg_active_page_offset[offset]==bordercol) return;

//return if first point is the same as the tile color used and is not the background color
fillcol=tile[ix%sx][iy%sy];
if ((fillcol==qbg_active_page_offset[offset])&&(fillcol!=backgroundcol)) return;
qbg_active_page_offset[offset]=fillcol;




//create first node
a_x[0]=ix; a_y[0]=iy;
a_t[0]=15;
//types:
//&1=check left
//&2=check right
//&4=check above
//&8=check below

a_n=1;
qbg_active_page_offset[iy*qbg_width+ix]=fillcol;
done[iy*qbg_width+ix]=1;

nextpass:
b_n=0;
for (i=0;i<a_n;i++){
t=a_t[i]; ix=a_x[i]; iy=a_y[i];

//left
if (t&1){
x2=ix-1; y2=iy;
if (x2>=qbg_view_x1){
offset=y2*qbg_width+x2;
if (!done[offset]){
done[offset]=1;
if (qbg_active_page_offset[offset]!=bordercol){
fillcol=tile[x2%sx][y2%sy];
//no tile check required when moving horizontally!
qbg_active_page_offset[offset]=fillcol;
b_t[b_n]=13; b_x[b_n]=x2; b_y[b_n]=y2; b_n++;//add new node
}}}}

//right
if (t&2){
x2=ix+1; y2=iy;
if (x2<=qbg_view_x2){
offset=y2*qbg_width+x2;
if (!done[offset]){
done[offset]=1;
if (qbg_active_page_offset[offset]!=bordercol){
fillcol=tile[x2%sx][y2%sy];
//no tile check required when moving horizontally!
qbg_active_page_offset[offset]=fillcol;
b_t[b_n]=14; b_x[b_n]=x2; b_y[b_n]=y2; b_n++;//add new node
}}}}

//above
if (t&4){
x2=ix; y2=iy-1;
if (y2>=qbg_view_y1){
offset=y2*qbg_width+x2;
if (!done[offset]){
done[offset]=1;
if (qbg_active_page_offset[offset]!=bordercol){
fillcol=tile[x2%sx][y2%sy];
if ((fillcol!=qbg_active_page_offset[offset])||(fillcol==backgroundcol)){
qbg_active_page_offset[offset]=fillcol;
b_t[b_n]=7; b_x[b_n]=x2; b_y[b_n]=y2; b_n++;//add new node
}
}}}}

//below
if (t&8){
x2=ix; y2=iy+1;
if (y2<=qbg_view_y2){
offset=y2*qbg_width+x2;
if (!done[offset]){
done[offset]=1;
if (qbg_active_page_offset[offset]!=bordercol){
fillcol=tile[x2%sx][y2%sy];
if ((fillcol!=qbg_active_page_offset[offset])||(fillcol==backgroundcol)){
qbg_active_page_offset[offset]=fillcol;
b_t[b_n]=11; b_x[b_n]=x2; b_y[b_n]=y2; b_n++;//add new node
}
}}}}

}//i

//no new nodes?
if (b_n==0){
memset(done,0,qbg_width*qbg_height);//cleanup
return;//finished!
}

//swap a & b arrays
sp=a_x; a_x=b_x; b_x=sp;
sp=a_y; a_y=b_y; b_y=sp;
cp=a_t; a_t=b_t; b_t=cp;
a_n=b_n;

goto nextpass;

}












void sub_circle(long step,double x,double y,double r,unsigned long col,double start,double end,double aspect,long passed){
//                                                                 &1         &2           &4         &8
//[{STEP}](?,?),?[,[?][,[?][,[?][,?]]]]

//data
static double pi= 3.1415926535897932,pi2=6.2831853071795865;
static long line_to_start,line_from_end;
static long ix,iy;//integer screen co-ordinates of circle's centre
static double xspan,yspan;
static double c;//circumference
static double px,py;
static double sinb,cosb;//second angle used in double-angle-formula
static long pixels;
static double tmp;
static long tmpi;
static long i;
static long exclusive;
static double arc1,arc2,arc3,arc4,arcinc;
static double px2,py2;
static long x2,y2;
static long x3,y3;
static long lastplotted_x2,lastplotted_y2;
static long lastchecked_x2,lastchecked_y2;

if (qbg_text_only){error(5); return;}

//lines to & from centre
if (!(passed&2)) start=0;
if (!(passed&4)) end=pi2;
line_to_start=0; if (start<0) {line_to_start=1; start=-start;}
line_from_end=0; if (end<0) {line_from_end=1; end=-end;}

//error checking
if (start>pi2){error(5); return;}
if (end>pi2){error(5); return;}

//when end<start, the arc of the circle that wouldn't have been drawn if start & end
//were swapped is drawn
exclusive=0;
if (end<start){
tmp=start; start=end; end=tmp;
tmpi=line_to_start; line_to_start=line_from_end; line_from_end=tmpi;
exclusive=1;
}

//calc. centre
if (step){x=qbg_x+x; y=qbg_y+y;}
qbg_x=x; qbg_y=y;//set graphics cursor position to circle's centre

r=x+r;//the differece between x & x+r in pixels will be the radius in pixels
//resolve coordinates (but keep as floats)
if (qbg_clipping_or_scaling){
if (qbg_clipping_or_scaling==2){
x=x*qbg_scaling_x+qbg_scaling_offset_x+qbg_view_offset_x;
y=y*qbg_scaling_y+qbg_scaling_offset_y+qbg_view_offset_y;
r=r*qbg_scaling_x+qbg_scaling_offset_x+qbg_view_offset_x;
}else{
x=x+qbg_view_offset_x;
y=y+qbg_view_offset_y;
r=r+qbg_view_offset_x;
}
}
if (x<0) ix=x-0.5; else ix=x+0.5;
if (y<0) iy=y-0.5; else iy=y+0.5;
r=fabs(r-x);//r is now a radius in pixels

//adjust vertical and horizontal span of the circle based on aspect ratio
xspan=r; yspan=r;
if (!(passed&8)) aspect=4.0*((double)qbg_height/(double)qbg_width)/3.0;
if (aspect>=0){
 if (aspect<1){
  //aspect: 0 to 1
  yspan*=aspect;
 }
 if (aspect>1){
  //aspect: 1 to infinity
  xspan/=aspect;
 }
}else{
 if (aspect>-1){
  //aspect: -1 to 0
  yspan*=(1+aspect);
 }
 //if aspect<-1 no change is required
}

//skip everything if none of the circle is inside current viwport
if ((x+xspan+0.5)<qbg_view_x1) return;
if ((y+yspan+0.5)<qbg_view_y1) return;
if ((x-xspan-0.5)>qbg_view_x2) return;
if ((y-yspan-0.5)>qbg_view_y2) return;

if (!(passed&1)) col=qbg_color;

//pre-set/pre-calculate values
c=pi2*r;
pixels=c/4.0+0.5;
arc1=0;
arc2=pi;
arc3=pi;
arc4=pi2;
arcinc=(pi/2)/(double)pixels;
sinb=sin(arcinc);
cosb=cos(arcinc);
lastplotted_x2=-1;
lastchecked_x2=-1;
i=0;

if (line_to_start){
px=cos(start); py=sin(start);
x2=px*xspan+0.5; y2=py*yspan-0.5;
fast_line(ix,iy,ix+x2,iy-y2,col);
}

px=1;
py=0;

drawcircle:
x2=px*xspan+0.5;
y2=py*yspan-0.5;

if (i==0) {lastchecked_x2=x2; lastchecked_y2=y2; goto plot;}

if ( (abs(x2-lastplotted_x2)>=2)||(abs(y2-lastplotted_y2)>=2) ){
plot:
if (exclusive){
if ((arc1<=start)||(arc1>=end)){pset_and_clip(ix+lastchecked_x2,iy+lastchecked_y2,col);}
if ((arc2<=start)||(arc2>=end)){pset_and_clip(ix-lastchecked_x2,iy+lastchecked_y2,col);}
if ((arc3<=start)||(arc3>=end)){pset_and_clip(ix-lastchecked_x2,iy-lastchecked_y2,col);}
if ((arc4<=start)||(arc4>=end)){pset_and_clip(ix+lastchecked_x2,iy-lastchecked_y2,col);}
}else{//inclusive
if ((arc1>=start)&&(arc1<=end)){pset_and_clip(ix+lastchecked_x2,iy+lastchecked_y2,col);}
if ((arc2>=start)&&(arc2<=end)){pset_and_clip(ix-lastchecked_x2,iy+lastchecked_y2,col);}
if ((arc3>=start)&&(arc3<=end)){pset_and_clip(ix-lastchecked_x2,iy-lastchecked_y2,col);}
if ((arc4>=start)&&(arc4<=end)){pset_and_clip(ix+lastchecked_x2,iy-lastchecked_y2,col);}
}
if (i>pixels) goto allplotted;
lastplotted_x2=lastchecked_x2; lastplotted_y2=lastchecked_y2;
}
lastchecked_x2=x2; lastchecked_y2=y2;

if (i<=pixels){
i++;
if (i>pixels) goto plot;
px2=px*cosb+py*sinb;
py=py*cosb-px*sinb;
px=px2;
if (i) {arc1+=arcinc; arc2-=arcinc; arc3+=arcinc; arc4-=arcinc;}
goto drawcircle;
}
allplotted:

if (line_from_end){
px=cos(end); py=sin(end);
x2=px*xspan+0.5; y2=py*yspan-0.5;
fast_line(ix,iy,ix+x2,iy-y2,col);
}

}//sub_circle

unsigned long point(long x,long y){//does not clip!
if (qbg_bytes_per_pixel==1){
return qbg_active_page_offset[y*qbg_width+x]&qbg_pixel_mask;
}else{
//...(requires real color support)
}
return NULL;
}




double func_point(float x,float y,long passed){
static long x2,y2,i;
if (qbg_text_only){error(5); return 0;}

if (!passed){
i=qbr_float_to_long(x);
if ((i<0)||(i>3)){error(5); return 0;}
if (i==2) return qbg_x;
if (i==3) return qbg_y;
if (qbg_clipping_or_scaling==2){
x2=qbr_float_to_long(qbg_x*qbg_scaling_x+qbg_scaling_offset_x);
y2=qbr_float_to_long(qbg_y*qbg_scaling_y+qbg_scaling_offset_y);
}else{
x2=qbr_float_to_long(qbg_x); y2=qbr_float_to_long(qbg_y);
}
if (i==0) return x2;
return y2;
}

if (qbg_clipping_or_scaling){
 if (qbg_clipping_or_scaling==2){
 x2=qbr_float_to_long(x*qbg_scaling_x+qbg_scaling_offset_x)+qbg_view_offset_x;
 y2=qbr_float_to_long(y*qbg_scaling_y+qbg_scaling_offset_y)+qbg_view_offset_y;
 }else{
 x2=qbr_float_to_long(x)+qbg_view_offset_x; y2=qbr_float_to_long(y)+qbg_view_offset_y;
 }
}else{
x2=qbr_float_to_long(x); y2=qbr_float_to_long(y);
}

if (x2>=qbg_view_x1){ if (x2<=qbg_view_x2){
if (y2>=qbg_view_y1){ if (y2<=qbg_view_y2){
return point(x2,y2);
}}}}

return -1;
}








void qbg_pset(long step,float x,float y,unsigned long col,long passed){
static long x2,y2;
if (qbg_text_only){error(5); return;}
//Special Format: [{STEP}](?,?),[?]
if (step){qbg_x+=x; qbg_y+=y;}else{qbg_x=x; qbg_y=y;}
if (!(passed&1)) col=qbg_color;
if (qbg_clipping_or_scaling){
if (qbg_clipping_or_scaling==2){
x2=qbr(qbg_x*qbg_scaling_x+qbg_scaling_offset_x)+qbg_view_offset_x;
y2=qbr(qbg_y*qbg_scaling_y+qbg_scaling_offset_y)+qbg_view_offset_y;
}else{
x2=qbr(qbg_x)+qbg_view_offset_x; y2=qbr(qbg_y)+qbg_view_offset_y;
}
if (x2>=qbg_view_x1){ if (x2<=qbg_view_x2){
if (y2>=qbg_view_y1){ if (y2<=qbg_view_y2){
 pset(x2,y2,col);
}}}}
return;
}else{
 x2=qbr(qbg_x); if (x2>=0){ if (x2<qbg_width){
 y2=qbr(qbg_y); if (y2>=0){ if (y2<qbg_height){
  pset(x2,y2,col);
 }}}}
}
return;
}

void sub_preset(long step,float x,float y,unsigned long col,long passed){
if (!passed){
col=qbg_background_color;
passed=1;
}
qbg_pset(step,x,y,col,passed);
return;
}



void printchr(unsigned char character){
unsigned short x,x2;
unsigned short y,y2;
unsigned char *cp;

if (!qbg_text_only){
if (qbg_character_width==8){

if (qbg_character_height==8){ 
cp=&charset8x8[character][0][0];
for (y=0;y<8;y++){
y2=(qbg_cursor_y-1)*8+y;
x2=(qbg_cursor_x-1)*8;
for (x=0;x<8;x++){
if (*cp){
pset (x2,y2,qbg_color);
}else{
pset (x2,y2,qbg_background_color);
}
cp++;
x2++;
}}
return;
}//height 8

if (qbg_character_height==16){ 
cp=&charset8x16[character][0][0];
for (y=0;y<16;y++){
y2=(qbg_cursor_y-1)*16+y;
x2=(qbg_cursor_x-1)*8;
for (x=0;x<8;x++){
if (*cp){
pset (x2,y2,qbg_color);
}else{
pset (x2,y2,qbg_background_color);
}
cp++;
x2++;
}}
return;
}//height 16

if (qbg_character_height==14){ 
cp=&charset8x16[character][1][0];
for (y=0;y<14;y++){
y2=(qbg_cursor_y-1)*14+y;
x2=(qbg_cursor_x-1)*8;
for (x=0;x<8;x++){
if (*cp){
pset (x2,y2,qbg_color);
}else{
pset (x2,y2,qbg_background_color);
}
cp++;
x2++;
}}
return;
}//height 14

}//width 8

}else{//text only

qbg_active_page_offset[((qbg_cursor_y-1)*qbg_width_in_characters+qbg_cursor_x-1)*2]=character;
qbg_active_page_offset[((qbg_cursor_y-1)*qbg_width_in_characters+qbg_cursor_x-1)*2+1]=(qbg_color&0xF)+qbg_background_color*16+(qbg_color&16)*8;



}//text only


}//printchr


//required to maintain compatibility with QB's print when ; is used and last
//character is last column on the line
static long print_holding_cursor=0;

void qbs_print(qbs* str,unsigned char newline){
unsigned long i,i2,newlineadded;
newlineadded=0;

if (!str->len){
if (!newline) return;//no action required
if (print_holding_cursor){//extra CR required before return
print_holding_cursor=0;
i=-1;
qbg_cursor_x++;
goto print_unhold_cursor;
}
}

if (!str->len) goto null_length;

if (print_holding_cursor){
print_holding_cursor=0;
i=-1;
qbg_cursor_x++;
goto print_unhold_cursor;
}


for (i=0;i<str->len;i++){
newlineadded=0;

if (str->chr[i]==7){
qb64_generatesound(783.99,0.2,0);
Sleep(250);
goto qbs_print_skipchar;
}

if ((str->chr[i]==10)||(str->chr[i]==13)){
qbg_cursor_x=32767;//force new line
goto qbs_print_skipchar;
}

printchr(str->chr[i]);
qbg_cursor_x++;


//hold cursor?
if (qbg_cursor_x>qbg_width_in_characters){//past last x position
if (!newline){//don't need a new line
if (i==(str->len-1)){//last character
qbg_cursor_x--;
print_holding_cursor=1;
goto hold_cursor;
}
}
}




qbs_print_skipchar:;

print_unhold_cursor:

if (qbg_cursor_x>qbg_width_in_characters){
qbs_print_newline:
newlineadded=1;

if (qbg_cursor_y==qbg_height_in_characters) qbg_cursor_y=qbg_bottom_row;

qbg_cursor_y++;
qbg_cursor_x=1;



if (qbg_cursor_y>qbg_bottom_row){
//move screen space within view print up 1 row
//if (qbg_mode==13){

///memmove(&cmem[655360+(qbg_top_row-1)*2560],&cmem[655360+qbg_top_row*2560],(qbg_bottom_row-qbg_top_row)*2560);
///memset(&cmem[655360+(qbg_bottom_row-1)*2560],0,2560);
if (qbg_text_only){

memmove(qbg_active_page_offset+(qbg_top_row-1)*qbg_width_in_characters*2,
        qbg_active_page_offset+(qbg_top_row)*qbg_width_in_characters*2,
        (qbg_bottom_row-qbg_top_row)*qbg_width_in_characters*2);
for (i2=0;i2<qbg_width_in_characters;i2++){
qbg_active_page_offset[(qbg_bottom_row-1)*qbg_width_in_characters*2+i2*2]=32;
qbg_active_page_offset[(qbg_bottom_row-1)*qbg_width_in_characters*2+i2*2+1]=7;

}

}else{
memmove(qbg_active_page_offset+(qbg_top_row-1)*qbg_bytes_per_pixel*qbg_width*qbg_character_height,
        qbg_active_page_offset+qbg_top_row*qbg_bytes_per_pixel*qbg_width*qbg_character_height,
        (qbg_bottom_row-qbg_top_row)*qbg_bytes_per_pixel*qbg_width*qbg_character_height);
memset(qbg_active_page_offset+(qbg_bottom_row-1)*qbg_bytes_per_pixel*qbg_width*qbg_character_height,0,qbg_bytes_per_pixel*qbg_width*qbg_character_height);
}


//}

qbg_cursor_y=qbg_bottom_row;
}



}


}

null_length:

//begin new line?
if (newline&&(!newlineadded)) {newline=0; goto qbs_print_newline;}

//hold cursor
hold_cursor:

return;

}


long qbs_cleanup(unsigned long base,long passvalue){
while (qbs_tmp_list_nexti>base) { qbs_tmp_list_nexti--; if(qbs_tmp_list[qbs_tmp_list_nexti]!=0xFFFFFFFF)qbs_free((qbs*)qbs_tmp_list[qbs_tmp_list_nexti]); }//clear any temp. strings created
return passvalue;
}



void qbg_sub_window(long screen,float x1,float y1,float x2,float y2,long passed){
static float i;
static float old_x,old_y;

if (qbg_text_only) goto qbg_sub_window_error;
if ((!passed)&&screen) goto qbg_sub_window_error;//SCREEEN passed without any other arguements!


//backup current qbg_x & qbg_y coordinates relative to viewport, not window
if (qbg_clipping_or_scaling==2){
old_x=qbg_x*qbg_scaling_x+qbg_scaling_offset_x;
old_y=qbg_y*qbg_scaling_y+qbg_scaling_offset_y;
}else{
old_x=qbg_x;
old_y=qbg_y;
}

if (passed){
if (x1==x2) goto qbg_sub_window_error;
if (y1==y2) goto qbg_sub_window_error;
//sort so x1 & y1 contain the lower values
if (x1>x2){i=x1; x1=x2; x2=i;}
if (y1>y2){i=y1; y1=y2; y2=i;}
if (!screen){
i=y1; y1=y2; y2=i;
}
//Note: Window's coordinates are not based on prev. WINDOW values
qbg_clipping_or_scaling=2;
qbg_scaling_x=((float)(qbg_view_x2-qbg_view_x1))/(x2-x1);
qbg_scaling_y=((float)(qbg_view_y2-qbg_view_y1))/(y2-y1);
qbg_scaling_offset_x=-x1*qbg_scaling_x; //scaling offset should be applied before scaling
qbg_scaling_offset_y=-y1*qbg_scaling_y;
if (!screen){
qbg_scaling_offset_y=-y2*qbg_scaling_y+(qbg_view_y2-qbg_view_y1);
}
qbg_window_x1=x1; qbg_window_x2=x2; qbg_window_y1=y1; qbg_window_y2=y2;
if (x1==0){ if (y1==0){ if (x2==(qbg_width-1)){ if (y2==(qbg_height-1)){
if ((qbg_scaling_x==1)&&(qbg_scaling_y==1)){
if ((qbg_scaling_offset_x==0)&&(qbg_scaling_offset_y==0)){
goto qbg_sub_window_restore_default;
}
}
}}}}

//adjust qbg_x & qbg_y according to new window
qbg_x=(old_x-qbg_scaling_offset_x)/qbg_scaling_x;
qbg_y=(old_y-qbg_scaling_offset_y)/qbg_scaling_y;

return;
}else{
//restore default WINDOW coordinates
qbg_sub_window_restore_default:
qbg_clipping_or_scaling=1;
qbg_scaling_x=1;
qbg_scaling_y=1;
qbg_scaling_offset_x=0;
qbg_scaling_offset_y=0;
qbg_window_x1=0; qbg_window_x2=qbg_width-1; qbg_window_y1=0; qbg_window_y2=qbg_height-1;
if (qbg_view_x1==0){ if (qbg_view_y1==0){ if (qbg_view_x2==(qbg_width-1)){ if (qbg_view_y2==(qbg_height-1)){
if (qbg_view_offset_x==0){ if (qbg_view_offset_y==0){
qbg_clipping_or_scaling=0;
}}
}}}}

//adjust qbg_x & qbg_y according to new window
qbg_x=old_x;
qbg_y=old_y;

return;
}
qbg_sub_window_error:
error(5);
return;
}



void qbg_sub_view_print(long topline,long bottomline,long passed){
//PRE-ERROR CHECKING
if (!passed){//topline and bottomline not passed
qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters;
qbg_cursor_y=1; qbg_cursor_x=1;
return;
}
if (topline<=0) goto qbg_sub_view_print_error;
if (topline>qbg_height_in_characters) goto qbg_sub_view_print_error;
if (bottomline<topline) goto qbg_sub_view_print_error;
if (bottomline>qbg_height_in_characters) goto qbg_sub_view_print_error;
qbg_top_row=topline;
qbg_bottom_row=bottomline;
qbg_cursor_y=qbg_top_row;
qbg_cursor_x=1;
return;
qbg_sub_view_print_error:
error(5);
return;
}

void qbg_sub_view(long coords_relative_to_screen,long x1,long y1,long x2,long y2,long fillcolor,long bordercolor,long passed){
//format: [{SCREEN}][(?,?)-(?,?)],[?],[?]
//bordercolor draws a line AROUND THE OUTSIDE of the specified viewport
//the current WINDOW settings do not affect inputted x,y values
//the current VIEW settings do not affect inputted x,y values
//REMEMBER! Recalculate WINDOW values based on new viewport dimensions
long i;

//PRE-ERROR CHECKING
if (passed&1){
if (x1<0) goto qbg_sub_view_error;
if (x1>=qbg_width) goto qbg_sub_view_error;
if (y1<0) goto qbg_sub_view_error;
if (y1>=qbg_height) goto qbg_sub_view_error;
if (x2<0) goto qbg_sub_view_error;
if (x2>=qbg_width) goto qbg_sub_view_error;
if (y2<0) goto qbg_sub_view_error;
if (y2>=qbg_height) goto qbg_sub_view_error;
}else{
if (coords_relative_to_screen) goto qbg_sub_view_error;
if (passed&2) goto qbg_sub_view_error;
if (passed&4) goto qbg_sub_view_error;
}

if (passed&1){
//force x1,y1 to be the top left corner
if (x2<x1){i=x1;x1=x2;x2=i;}
if (y2<y1){i=y1;y1=y2;y2=i;}
qbg_view_x1=x1; qbg_view_y1=y1; qbg_view_x2=x2; qbg_view_y2=y2;
if (coords_relative_to_screen==0){
qbg_view_offset_x=x1; qbg_view_offset_y=y1;
}else{
qbg_view_offset_x=0; qbg_view_offset_y=0;
}
if (!qbg_clipping_or_scaling) qbg_clipping_or_scaling=1;
}else{
//no argurments passed
qbg_view_x1=0; qbg_view_y1=0; qbg_view_x2=qbg_width-1; qbg_view_y2=qbg_height-1;
qbg_view_offset_x=0; qbg_view_offset_y=0;
if (qbg_clipping_or_scaling==1) qbg_clipping_or_scaling=0;
}

//recalculate window values based on new viewport (if necessary)
if (qbg_clipping_or_scaling==2){//WINDOW'ing in use
qbg_scaling_x=((float)(qbg_view_x2-qbg_view_x1))/(qbg_window_x2-qbg_window_x1);
qbg_scaling_y=((float)(qbg_view_y2-qbg_view_y1))/(qbg_window_y2-qbg_window_y1);
qbg_scaling_offset_x=-qbg_window_x1*qbg_scaling_x;
qbg_scaling_offset_y=-qbg_window_y1*qbg_scaling_y;
if (qbg_window_y2<qbg_window_y1) qbg_scaling_offset_y=-qbg_window_y2*qbg_scaling_y+qbg_view_y2;
}

if (passed&2){//fillcolor
qb32_boxfill(qbg_window_x1,qbg_window_y1,qbg_window_x2,qbg_window_y2,fillcolor);
}

if (passed&4){//bordercolor
static long bx,by;
by=qbg_view_y1-1;
if ((by>=0)&&(by<qbg_height)){
for (bx=qbg_view_x1-1;bx<=qbg_view_x2;bx++){
if ((bx>=0)&&(bx<qbg_width)){
pset(bx,by,bordercolor);
}}}
by=qbg_view_y2+1;
if ((by>=0)&&(by<qbg_height)){
for (bx=qbg_view_x1-1;bx<=qbg_view_x2;bx++){
if ((bx>=0)&&(bx<qbg_width)){
pset(bx,by,bordercolor);
}}}
bx=qbg_view_x1-1;
if ((bx>=0)&&(bx<qbg_width)){
for (by=qbg_view_y1-1;by<=qbg_view_y2;by++){
if ((by>=0)&&(by<qbg_height)){
pset(bx,by,bordercolor);
}}}
bx=qbg_view_x2+1;
if ((bx>=0)&&(bx<qbg_width)){
for (by=qbg_view_y1-1;by<=(qbg_view_y2+1);by++){
if ((by>=0)&&(by<qbg_height)){
pset(bx,by,bordercolor);
}}}
}

return;
qbg_sub_view_error:
error(5);
return;
}


void sub_cls(long method,long passed){
static long characters,i;
static unsigned short *sp;
static unsigned short clearvalue;
if (passed){
if ((method>2)||(method<0)) goto error;
}

//all CLS methods reset the cursor position!
qbg_cursor_y=qbg_top_row;
qbg_cursor_x=1;

if (qbg_text_only){
clearvalue=(qbg_color&0xF)+qbg_background_color*16+(qbg_color&16)*8;
clearvalue<<=8;
clearvalue+=32;
}

if (!passed){
//video mode: clear only graphics viewport
//text mode: clear text view port AND the bottom line
if (qbg_text_only){
characters=qbg_width_in_characters*(qbg_bottom_row-qbg_top_row+1);
sp=(unsigned short*)&qbg_active_page_offset[(qbg_top_row-1)*qbg_width_in_characters*2];
for (i=0;i<characters;i++){sp[i]=clearvalue;}
//clear bottom line
characters=qbg_width_in_characters;
sp=(unsigned short*)&qbg_active_page_offset[(qbg_height_in_characters-1)*qbg_width_in_characters*2];
for (i=0;i<characters;i++){sp[i]=clearvalue;}
}else{
if (qbg_clipping_or_scaling){
 qb32_boxfill(qbg_window_x1,qbg_window_y1,qbg_window_x2,qbg_window_y2,0);
}else{
 //no clipping/scaling (optomised method)
 if (qbg_bytes_per_pixel==1){
 memset(qbg_active_page_offset,0,qbg_width*qbg_height);
 }else{
 //requires real color support!
 }
}
}
qbg_x=((float)(qbg_view_x2-qbg_view_x1+1))/qbg_scaling_x/2.0f+qbg_scaling_offset_x;
qbg_y=((float)(qbg_view_y2-qbg_view_y1+1))/qbg_scaling_y/2.0f+qbg_scaling_offset_y;
return;
}

if (method==0){//clear everything
if (qbg_text_only){
characters=qbg_height_in_characters*qbg_width_in_characters;
sp=(unsigned short*)qbg_active_page_offset;
for (i=0;i<characters;i++){sp[i]=clearvalue;}
}else{
 if (qbg_bytes_per_pixel==1){
 memset(qbg_active_page_offset,0,qbg_width*qbg_height);
 }else{
 //requires real color support!
 }
}
qbg_x=((float)(qbg_view_x2-qbg_view_x1+1))/qbg_scaling_x/2.0f+qbg_scaling_offset_x;
qbg_y=((float)(qbg_view_y2-qbg_view_y1+1))/qbg_scaling_y/2.0f+qbg_scaling_offset_y;
}

if (method==1){//ONLY clear the graphics viewport
if (!qbg_text_only){
if (qbg_clipping_or_scaling){
 qb32_boxfill(qbg_window_x1,qbg_window_y1,qbg_window_x2,qbg_window_y2,0);
}else{
 //no clipping/scaling (optomised method)
 if (qbg_bytes_per_pixel==1){
 memset(qbg_active_page_offset,0,qbg_width*qbg_height);
 }else{
 //requires real color support!
 }
}
}
qbg_x=((float)(qbg_view_x2-qbg_view_x1+1))/qbg_scaling_x/2.0f+qbg_scaling_offset_x;
qbg_y=((float)(qbg_view_y2-qbg_view_y1+1))/qbg_scaling_y/2.0f+qbg_scaling_offset_y;
}

if (method==2){//ONLY clear the VIEW PRINT range text viewport
if (qbg_text_only){
characters=qbg_width_in_characters*(qbg_bottom_row-qbg_top_row+1);
sp=(unsigned short*)&qbg_active_page_offset[(qbg_top_row-1)*qbg_width_in_characters*2];
for (i=0;i<characters;i++){sp[i]=clearvalue;}
}else{
memset(&qbg_active_page_offset[qbg_width*qbg_character_height*(qbg_top_row-1)],0,qbg_width*qbg_character_height*(qbg_bottom_row-qbg_top_row+1));
}
}

return;
error:
error(5);
return;
}



void qbg_sub_locate(long row,long column,long cursor,long start,long stop,long passed){
//PRE-ERROR CHECKING
if (passed&1){
if (row<qbg_top_row) goto qbg_sub_locate_error;
if ((row!=qbg_height_in_characters)&&(row>qbg_bottom_row)) goto qbg_sub_locate_error;
}
if (passed&2){
if (column<1) goto qbg_sub_locate_error;
if (column>qbg_width_in_characters) goto qbg_sub_locate_error;
}
if (passed&4){
if (cursor<0) goto qbg_sub_locate_error;
if (cursor>1) goto qbg_sub_locate_error;
}
if (passed&8){
if (start<0) goto qbg_sub_locate_error;
if (start>31) goto qbg_sub_locate_error;
if (stop<0) goto qbg_sub_locate_error;
if (stop>31) goto qbg_sub_locate_error;
}
if (passed&1) {qbg_cursor_y=row; print_holding_cursor=0;}
if (passed&2) {qbg_cursor_x=column; print_holding_cursor=0;}
if (passed&4){
if (cursor) qbg_cursor_show=1; else qbg_cursor_show=0;
}
if (passed&8){
qbg_cursor_firstvalue=start;
qbg_cursor_lastvalue=stop;
}
return;
qbg_sub_locate_error:
error(5);
return;
}








long ISSTRING = 1073741824;
long ISFLOAT = 536870912;
long ISUNSIGNED = 268435456;
long ISPOINTER = 134217728;
long ISFIXEDLENGTH = 67108864; //only set for strings with pointer flag
long ISINCONVENTIONALMEMORY = 33554432;
long ISOFFSETINBITS = 16777216;

//input helper functions:
long hex2uint64_failed;
unsigned __int64 hex2uint64(qbs* h){
static unsigned __int64 result;
static long i,i2;
hex2uint64_failed=0;
result=0;
if (!h->len) return 0;//shouldn't be called with no arguements
if (h->chr[0]!=38){hex2uint64_failed=1; return 0;}//not "&"
if (h->len==1) return 0;//& received, but awaiting further input
if ((h->chr[1]!=72)&&(h->chr[1]!=104)){hex2uint64_failed=1; return 0;}//not "H" or "h"
if (h->len==2) return 0;//&H received, but awaiting further input
if (h->len>18){hex2uint64_failed=1; return 0;}//larger than __int64 can hold!!!
for (i=2;i<h->len;i++){
result<<=4;
i2=h->chr[i];
//          0  -      9             A  -      F             a  -      f
if ( ((i2>=48)&&(i2<=57)) || ((i2>=65)&&(i2<=70)) || ((i2>=97)&&(i2<=102)) ){
if (i2>=97) i2-=32;
if (i2>=65) i2-=7;
i2-=48;
//i2 is now a values between 0 and 15
result+=i2;
}else{hex2uint64_failed=1; return 0;}//invalid character
}//i
return result;
}

//input method (complex, calls other qbs functions)
const char *uint64_max[] =    {"18446744073709551615"};
const char *int64_max[] =     {"9223372036854775807"};
const char *int64_max_neg[] = {"9223372036854775808"};
const char *single_max[] = {"3402823"};
const char *single_max_neg[] = {"1401298"};
const char *double_max[] = {"17976931"};
const char *double_max_neg[] = {"4940656"};
unsigned char significant_digits[1024];
long num_significant_digits;
void *qbs_input_variableoffsets[257];
long qbs_input_variabletypes[257];
qbs *qbs_input_arguements[257];
long qbg_cursor_show_old;
void qbs_input(long numvariables,unsigned char newline){
unsigned long qbs_tmp_base=qbs_tmp_list_nexti;

static long lineinput;
lineinput=0;
if (qbs_input_variabletypes[1]&ISSTRING){
if (qbs_input_variabletypes[1]&512){
qbs_input_variabletypes[1]=-512;
lineinput=1;
}}

qbg_cursor_show_old=qbg_cursor_show;
qbg_cursor_show=1;


long i,i2,i3,i4,i5,i6;
long addspaces;
addspaces=0;
qbs* inpstr=qbs_new(0,0);//not temp so must be freed
qbs* inpstr2=qbs_new(0,0);//not temp so must be freed
qbs* key=qbs_new(0,0);//not temp so must be freed
qbs* c=qbs_new(1,0);//not temp so must be freed

for (i=1;i<=numvariables;i++) qbs_input_arguements[i]=qbs_new(0,0);

//init all passed variables to 0 or ""
for (i=1;i<=numvariables;i++){

if (qbs_input_variabletypes[i]&ISSTRING){//STRING
if (((qbs*)qbs_input_variableoffsets[i])->fixed){
memset(((qbs*)qbs_input_variableoffsets[i])->chr,32,((qbs*)qbs_input_variableoffsets[i])->len);
}else{
((qbs*)qbs_input_variableoffsets[i])->len=0;
}
}

if ((qbs_input_variabletypes[i]&ISOFFSETINBITS)==0){//reg. numeric variable
memset(qbs_input_variableoffsets[i],0,(qbs_input_variabletypes[i]&511)>>3);
}

//bit referenced?

}//i




qbs_input_next:

long argn,firstchr,toomany;
toomany=0;
argn=1;
i=0;
i2=0;
qbs_input_arguements[1]->len=0;
firstchr=1;
qbs_input_sep_arg:

if (i<inpstr->len){

if (inpstr->chr[i]==44){//","
if (i2!=1){//not in the middle of a string
if (!lineinput){
i2=0;
argn=argn+1;
if (argn>numvariables){toomany=1; goto qbs_input_sep_arg_done;}
qbs_input_arguements[argn]->len=0;
firstchr=1;
goto qbs_input_next_arg;
}
}
}

if (inpstr->chr[i]==34){//"
if (firstchr){
if (!lineinput){
i2=1;//requires closure
firstchr=0;
goto qbs_input_next_arg;
}
}
if (i2==1){
i2=2;
goto qbs_input_next_arg;
}
}

if (i2==2){
goto backspace;//INVALID! Cannot have any characters after a closed "..."
}

c->chr[0]=inpstr->chr[i];
qbs_set(qbs_input_arguements[argn],qbs_add(qbs_input_arguements[argn],c));

firstchr=0;
qbs_input_next_arg:;
i++;
goto qbs_input_sep_arg;
}
qbs_input_sep_arg_done:
if (toomany) goto backspace;

//validate current arguements
//ASSUME LEADING & TRALING SPACES REMOVED!
unsigned char valid;
unsigned char neg;
long completewith;
long l;
unsigned char *cp,*cp2;
unsigned __int64 max,max_neg,multiple,value;
unsigned __int64 hexvalue;

completewith=-1;
valid=1;
l=qbs_input_arguements[argn]->len;
cp=qbs_input_arguements[argn]->chr;
neg=0;

if ((qbs_input_variabletypes[argn]&ISSTRING)==0){
if ((qbs_input_variabletypes[argn]&ISFLOAT)==0){
if ((qbs_input_variabletypes[argn]&511)<=32){//cannot handle INTEGER64 variables using this method!
__int64 finalvalue;
//it's an integer variable!
finalvalue=0;
if (l==0){completewith=48; goto typechecked_integer;}
//calculate max & max_neg (i4 used to store number of bits)
i4=qbs_input_variabletypes[argn]&511;
max=1;
max<<=i4;
max--;
//check for hex
hexvalue=hex2uint64(qbs_input_arguements[argn]);
if (hex2uint64_failed==0){//it's a hex number, so handle differently
//IMPORTANT: A hexidecimal value can be considered signed/unsigned
if (hexvalue>max){valid=0; goto typechecked;}
//are there too many hex digits? (calc num of hex digits in i)
value=max;
i=0;
for (i2=1;i2<=16;i2++){
if (value&0xF) i=i2;
value>>=4;
}
if (l>(2+i)){valid=0; goto typechecked;}
if (l==1) completewith=72;//"H"
if (l==2) completewith=48;//"0"
finalvalue=hexvalue;
goto typechecked_integer;
}
//max currently contains the largest UNSIGNED value possible, adjust as necessary
if (qbs_input_variabletypes[argn]&ISUNSIGNED){ 
max_neg=0;
}else{
max>>=1;
max_neg=max+1;
}
//check for - sign
i2=0;
 if ((qbs_input_variabletypes[argn]&ISUNSIGNED)==0){ 
 if (cp[i2]==45){//"-"
 if (l==1) {completewith=48; goto typechecked_integer;}
 i2++; neg=1;
 }
 }
//after a leading 0 no other digits are possible, return an error if this is the case
if (cp[i2]==48){
if (l>(i2+1)){valid=0; goto typechecked;}
}
//scan the "number"...
multiple=1;
value=0;
for (i=l-1;i>=i2;i--){
i3=cp[i]-48;
if ((i3>=0)&&(i3<=9)){
value+=multiple*i3;
 if (qbs_input_variabletypes[argn]&ISUNSIGNED){ 
 if (value>max){valid=0; goto typechecked;}
 }else{
 if (neg){
 if (value>max_neg){valid=0; goto typechecked;}
 }else{
 if (value>max){valid=0; goto typechecked;}
 }
 }
}else{valid=0; goto typechecked;}
multiple*=10;
}//next i
if (neg) finalvalue=-value; else finalvalue=value;
typechecked_integer:
//set variable to finalvalue
if ((qbs_input_variabletypes[argn]&ISOFFSETINBITS)==0){//reg. numeric variable
memcpy(qbs_input_variableoffsets[argn],&finalvalue,(qbs_input_variabletypes[argn]&511)>>3);
}
goto typechecked;
}
}
}

if (qbs_input_variabletypes[argn]&ISSTRING){
if (((qbs*)qbs_input_variableoffsets[argn])->fixed){
if (l>((qbs*)qbs_input_variableoffsets[argn])->len) {valid=0; goto typechecked;}
}
qbs_set((qbs*)qbs_input_variableoffsets[argn],qbs_input_arguements[argn]);
goto typechecked;
}

//INTEGER64 type
//__int64 range:          �9223372036854775808 to  9223372036854775807
//unsigned __int64 range: 0                    to 18446744073709551615
if ((qbs_input_variabletypes[argn]&ISSTRING)==0){
if ((qbs_input_variabletypes[argn]&ISFLOAT)==0){
if ((qbs_input_variabletypes[argn]&511)==64){
if (l==0){completewith=48; *(__int64*)qbs_input_variableoffsets[argn]=0; goto typechecked;}
//check for hex
hexvalue=hex2uint64(qbs_input_arguements[argn]);
if (hex2uint64_failed==0){//it's a hex number, so handle differently
if (l==1) completewith=72;//"H"
if (l==2) completewith=48;//"0"
*(unsigned __int64*)qbs_input_variableoffsets[argn]=hexvalue;
goto typechecked;
}
//check for - sign
i2=0;
 if ((qbs_input_variabletypes[argn]&ISUNSIGNED)==0){ 
 if (cp[i2]==45){//"-"
 if (l==1) {completewith=48; *(__int64*)qbs_input_variableoffsets[argn]=0; goto typechecked;}
 i2++; neg=1;
 }
 }
//after a leading 0 no other digits are possible, return an error if this is the case
if (cp[i2]==48){
if (l>(i2+1)){valid=0; goto typechecked;}
}
//count how many digits are in the number
i4=0;
for (i=l-1;i>=i2;i--){
i3=cp[i]-48;
if ((i3<0)||(i3>9)) {valid=0; goto typechecked;}
i4++;
}//i
if (qbs_input_variabletypes[argn]&ISUNSIGNED){
if (i4<20) goto typechecked_int64;
if (i4>20) {valid=0; goto typechecked;}
cp2=(unsigned char*)uint64_max[0];
}else{
if (i4<19) goto typechecked_int64;
if (i4>19) {valid=0; goto typechecked;}
if (neg) cp2=(unsigned char*)int64_max_neg[0]; else cp2=(unsigned char*)int64_max[0];
}
//number of digits valid, but exact value requires checking
cp=qbs_input_arguements[argn]->chr;
for (i=0;i<i4;i++){
if (cp[i+i2]<cp2[i]) goto typechecked_int64;
if (cp[i+i2]>cp2[i]) {valid=0; goto typechecked;}
}
typechecked_int64:
//add character 0 to end to make it a null terminated string
c->chr[0]=0; qbs_set(qbs_input_arguements[argn],qbs_add(qbs_input_arguements[argn],c));
if (qbs_input_variabletypes[argn]&ISUNSIGNED){
sscanf((char*)qbs_input_arguements[argn]->chr,"%I64u",(unsigned __int64*)qbs_input_variableoffsets[argn]);
}else{
sscanf((char*)qbs_input_arguements[argn]->chr,"%I64i",(__int64*)qbs_input_variableoffsets[argn]);
}
goto typechecked;
}
}
}

//check ISFLOAT type?
//[-]9999[.]9999[E/D][+/-]99999
if (qbs_input_variabletypes[argn]&ISFLOAT){
static long digits_before_point;
static long digits_after_point;
static long zeros_after_point;
static long neg_power;
digits_before_point=0;
digits_after_point=0;
neg_power=0;
value=0;
zeros_after_point=0;
num_significant_digits=0;

//set variable to 0
if ((qbs_input_variabletypes[argn]&511)==32) *(float*)qbs_input_variableoffsets[argn]=0;
if ((qbs_input_variabletypes[argn]&511)==64) *(double*)qbs_input_variableoffsets[argn]=0;
if ((qbs_input_variabletypes[argn]&511)==256) *(long double*)qbs_input_variableoffsets[argn]=0;

//begin with a generic assessment, regardless of whether it is single, double or float
if (l==0){completewith=48; goto typechecked;}
//check for hex
hexvalue=hex2uint64(qbs_input_arguements[argn]);
if (hex2uint64_failed==0){//it's a hex number, so handle differently
if (l==1) completewith=72;//"H"
if (l==2) completewith=48;//"0"
//nb. because VC6 didn't support...
//error C2520: conversion from unsigned __int64 to double not implemented, use signed __int64
//I've implemented a work-around so correct values will be returned
static __int64 transfer;
transfer=0x7FFFFFFF;
transfer<<=32;
transfer|=0xFFFFFFFF;
while(hexvalue>transfer){
hexvalue-=transfer;
if ((qbs_input_variabletypes[argn]&511)==32) *(float*)qbs_input_variableoffsets[argn]+=transfer;
if ((qbs_input_variabletypes[argn]&511)==64) *(double*)qbs_input_variableoffsets[argn]+=transfer;
if ((qbs_input_variabletypes[argn]&511)==256) *(long double*)qbs_input_variableoffsets[argn]+=transfer;
}
transfer=hexvalue;
if ((qbs_input_variabletypes[argn]&511)==32) *(float*)qbs_input_variableoffsets[argn]+=transfer;
if ((qbs_input_variabletypes[argn]&511)==64) *(double*)qbs_input_variableoffsets[argn]+=transfer;
if ((qbs_input_variabletypes[argn]&511)==256) *(long double*)qbs_input_variableoffsets[argn]+=transfer;
goto typechecked;
}
//check for - sign
i2=0;
 if (cp[i2]==45){//"-"
 if (l==1) {completewith=48; goto typechecked;}
 i2++; neg=1;
 }
//if it starts with 0, it may only have one leading 0
if (cp[i2]==48){
if (l>(i2+1)){
i2++;
if (cp[i2]==46) goto decimal_point;
valid=0; goto typechecked;//expected a decimal point
//nb. of course, user could have typed D or E BUT there is no point
//    calculating 0 to the power of anything!
}else goto typechecked;//validate, as no other data is required
}
//scan digits before decimal place
for (i=i2;i<l;i++){
i3=cp[i];
if ((i3==68)||(i3==(68+32))||(i3==69)||(i3==(69+32))){//d,D,e,E?
if (i==i2){valid=0; goto typechecked;}//cannot begin with d,D,e,E!
i2=i;
goto exponent;
}
if (i3==46){i2=i; goto decimal_point;}//nb. it can begin with a decimal point!
i3-=48;
if ((i3<0)||(i3>9)){valid=0; goto typechecked;}
digits_before_point++;
//nb. because leading 0 is handled differently, all digits are significant
significant_digits[num_significant_digits]=i3+48; num_significant_digits++;
}
goto assess_float;
////////////////////////////////
decimal_point:;
i4=1;
if (i2==(l-1)) {completewith=48; goto assess_float;}
i2++;
for (i=i2;i<l;i++){
i3=cp[i];
if ((i3==68)||(i3==(68+32))||(i3==69)||(i3==(69+32))){//d,D,e,E?
if (num_significant_digits){
if (i==i2){valid=0; goto typechecked;}//cannot begin with d,D,e,E just after a decimal point!
i2=i;
goto exponent;
}
}
i3-=48;
if ((i3<0)||(i3>9)){valid=0; goto typechecked;}
if (i3) i4=0;
if (i4) zeros_after_point++;
digits_after_point++;
if ((num_significant_digits)||i3){
significant_digits[num_significant_digits]=i3+48; num_significant_digits++;
}
}//i
goto assess_float;
////////////////////////////////
exponent:;
//ban d/D for SINGLE precision input
if ((qbs_input_variabletypes[argn]&511)==32){//SINGLE
i3=cp[i2];
if ((i3==68)||(i3==(68+32))){//d/D
valid=0; goto typechecked;
}
}
//correct "D" notation for c++ scanf
i3=cp[i2];
if ((i3==68)||(i3==(68+32))){//d/D
cp[i2]=69;//"E"
}
if (i2==(l-1)) {completewith=48; goto assess_float;}
i2++;
//check for optional + or -
i3=cp[i2];
if (i3==45){//"-"
if (i2==(l-1)) {completewith=48; goto assess_float;}
neg_power=1;
i2++;
}
if (i3==43){//"+"
if (i2==(l-1)) {completewith=48; goto assess_float;}
i2++;
}
//nothing valid after a leading 0
if (cp[i2]==48){//0
if (l>(i2+1)) {valid=0; goto typechecked;}
}
multiple=1;
value=0;
for (i=l-1;i>=i2;i--){
i3=cp[i]-48;
if ((i3>=0)&&(i3<=9)){
value+=multiple*i3;
}else{
valid=0; goto typechecked;
}
multiple*=10;
}//i
//////////////////////////
assess_float:;
//nb. 0.???? means digits_before_point==0

if ((qbs_input_variabletypes[argn]&511)==32){//SINGLE
//QB:           �3.402823    E+38 to �1.401298    E-45
//WIKIPEDIA:    �3.4028234   E+38 to ?
//OTHER SOURCE: �3.402823466 E+38 to �1.175494351 E-38
if (neg_power) value=-value;
//special case->single 0 after point
if ((zeros_after_point==1)&&(digits_after_point==1)){
digits_after_point=0;
zeros_after_point=0;
}
//upper overflow check
//i. check that value doesn't consist solely of 0's
if (zeros_after_point>43){valid=0; goto typechecked;}//cannot go any further without reversal by exponent
if ((digits_before_point==0)&&(digits_after_point==zeros_after_point)) goto nooverflow_float;
//ii. calculate the position of the first WHOLE digit (in i)
i=digits_before_point;
if (!i) i=-zeros_after_point;
/*EXAMPLES:
1.0			i=1
12.0		i=2
0.1			i=0
0.01		i=-1
*/
i=i+value;//apply exponent
if (i>39){valid=0; goto typechecked;}
//nb. the above blocks the ability to type a long-long number and use a neg exponent
//    to validate it
//********IMPORTANT: if i==39 then the first 7 digits MUST be scanned!!!
if (i==39){
cp2=(unsigned char*)single_max[0];
i2=num_significant_digits;
if (i2>7) i2=7;
for (i3=0;i3<i2;i3++){
if (significant_digits[i3]>*cp2){valid=0; goto typechecked;}
if (significant_digits[i3]<*cp2) break;
cp2++;
}
}
//check for pointless levels of precision (eg. 1.21351273512653625116212!)
if (digits_after_point){
if (digits_before_point){
if ((digits_after_point+digits_before_point)>8){valid=0; goto typechecked;}
}else{
if ((digits_after_point-zeros_after_point)>8){valid=0; goto typechecked;}
}
}
//check for "under-flow"
if (i<-44){valid=0; goto typechecked;}
//********IMPORTANT: if i==-44 then the first 7 digits MUST be scanned!!!
if (i==-44){
cp2=(unsigned char*)single_max_neg[0];
i2=num_significant_digits;
if (i2>7) i2=7;
for (i3=0;i3<i2;i3++){
if (significant_digits[i3]<*cp2){valid=0; goto typechecked;}
if (significant_digits[i3]>*cp2) break;
cp2++;
}
}
nooverflow_float:;
c->chr[0]=0; qbs_set(qbs_input_arguements[argn],qbs_add(qbs_input_arguements[argn],c));
sscanf((char*)qbs_input_arguements[argn]->chr,"%f",(float*)qbs_input_variableoffsets[argn]);
goto typechecked;
}

if ((qbs_input_variabletypes[argn]&511)==64){//DOUBLE
//QB: Double (15-digit) precision �1.7976931 D+308 to �4.940656 D-324
//WIKIPEDIA:    �1.7976931348623157 D+308 to ???
//OTHER SOURCE: �1.7976931348623157 D+308 to �2.2250738585072014E-308



if (neg_power) value=-value;
//special case->single 0 after point
if ((zeros_after_point==1)&&(digits_after_point==1)){
digits_after_point=0;
zeros_after_point=0;
}
//upper overflow check
//i. check that value doesn't consist solely of 0's
if (zeros_after_point>322){valid=0; goto typechecked;}//cannot go any further without reversal by exponent
if ((digits_before_point==0)&&(digits_after_point==zeros_after_point)) goto nooverflow_double;
//ii. calculate the position of the first WHOLE digit (in i)
i=digits_before_point;
if (!i) i=-zeros_after_point;
i=i+value;//apply exponent
if (i>309){valid=0; goto typechecked;}
//nb. the above blocks the ability to type a long-long number and use a neg exponent
//    to validate it
//********IMPORTANT: if i==309 then the first 8 digits MUST be scanned!!!
if (i==309){
cp2=(unsigned char*)double_max[0];
i2=num_significant_digits;
if (i2>8) i2=8;
for (i3=0;i3<i2;i3++){
if (significant_digits[i3]>*cp2){valid=0; goto typechecked;}
if (significant_digits[i3]<*cp2) break;
cp2++;
}
}
//check for pointless levels of precision (eg. 1.21351273512653625116212!)
if (digits_after_point){
if (digits_before_point){
if ((digits_after_point+digits_before_point)>16){valid=0; goto typechecked;}
}else{
if ((digits_after_point-zeros_after_point)>16){valid=0; goto typechecked;}
}
}
//check for "under-flow"
if (i<-323){valid=0; goto typechecked;}
//********IMPORTANT: if i==-323 then the first 7 digits MUST be scanned!!!
if (i==-323){
cp2=(unsigned char*)double_max_neg[0];
i2=num_significant_digits;
if (i2>7) i2=7;
for (i3=0;i3<i2;i3++){
if (significant_digits[i3]<*cp2){valid=0; goto typechecked;}
if (significant_digits[i3]>*cp2) break;
cp2++;
}
}
nooverflow_double:;
c->chr[0]=0; qbs_set(qbs_input_arguements[argn],qbs_add(qbs_input_arguements[argn],c));
sscanf((char*)qbs_input_arguements[argn]->chr,"%lf",(double*)qbs_input_variableoffsets[argn]);
goto typechecked;
}

if ((qbs_input_variabletypes[argn]&511)==256){//FLOAT
//at present, there is no defined limit for FLOAT type numbers, so no restrictions
//are applied!
c->chr[0]=0; qbs_set(qbs_input_arguements[argn],qbs_add(qbs_input_arguements[argn],c));

//sscanf((char*)qbs_input_arguements[argn]->chr,"%lf",(long double*)qbs_input_variableoffsets[argn]);
static double sscanf_fix;
sscanf((char*)qbs_input_arguements[argn]->chr,"%lf",&sscanf_fix);
*(long double*)qbs_input_variableoffsets[argn]=sscanf_fix;

}

}//ISFLOAT

//undefined/uncheckable types fall through as valid!
typechecked:;
if (!valid) goto backspace;



qbs_set(inpstr2,inpstr);


//input a key



qbs_input_invalidinput:
if (qbg_mode!=0){
//draw special box cursor
{
long x,y,x2,y2;
y2=(qbg_cursor_y-1)*qbg_character_height;
for (y=0;y<qbg_character_height;y++){
x2=(qbg_cursor_x-1)*qbg_character_width;
for (x=0;x<qbg_character_width;x++){
pset (x2,y2,point(x2,y2)^qbg_color);
x2++;
}
y2++;
}
}
//end special box cursor
}

qbs_input_wait_for_key:
if (addspaces){
addspaces--;
c->chr[0]=32; qbs_set(key,c);
}else{
SDL_Delay(10);
qbs_set(key,qbs_inkey());
qbs_cleanup(qbs_tmp_base,0);
}
if (stop_program) return;
if (key->len!=1) goto qbs_input_wait_for_key;

if (qbg_mode!=0){
//remove special box cursor
{
long x,y,x2,y2;
y2=(qbg_cursor_y-1)*qbg_character_height;
for (y=0;y<qbg_character_height;y++){
x2=(qbg_cursor_x-1)*qbg_character_width;
for (x=0;x<qbg_character_width;x++){
pset (x2,y2,point(x2,y2)^qbg_color);
x2++;
}
y2++;
}
}
//end special box cursor
}



//input should disallow certain characters
if (key->chr[0]==7) {qbs_print(key,0); goto qbs_input_next;}//beep!
if (key->chr[0]==10) goto qbs_input_next;//linefeed
if (key->chr[0]==9){//tab
i=8-(inpstr2->len&7);
addspaces=i;
goto qbs_input_next;
}
//other ASCII chars that cannot be printed
if (key->chr[0]==11) goto qbs_input_next;
if (key->chr[0]==12) goto qbs_input_next;
if (key->chr[0]==28) goto qbs_input_next;
if (key->chr[0]==29) goto qbs_input_next;
if (key->chr[0]==30) goto qbs_input_next;
if (key->chr[0]==31) goto qbs_input_next;

if (key->chr[0]==13){
//assume input is valid

//autofinish (if necessary)

//assume all parts entered

for (i=1;i<=numvariables;i++){
qbs_free(qbs_input_arguements[i]);
}

if (newline){
c->len=0;
qbs_print(c,1);
}
qbs_free(c);
qbs_free(inpstr);
qbs_free(inpstr2);
qbs_free(key);

qbg_cursor_show=qbg_cursor_show_old;
return;
}


if (key->chr[0]==8){//backspace
backspace:
if (!inpstr->len) goto qbs_input_invalidinput;//can't backspace!
//clear previous character from buffer
inpstr->len--;
//move cursor back (this may involve redisplaying prev. line)
qbg_cursor_x--;
if (!qbg_cursor_x){
qbg_cursor_x=qbg_width_in_characters;
if (qbg_cursor_y==qbg_top_row){
//recall up to screen-width-in-characters worth of data and display it right justified
//also clear the line

 
}else{
qbg_cursor_y--;
}
}

/*
long qbg_height_in_characters, qbg_width_in_characters;
long qbg_top_row, qbg_bottom_row;
long qbg_cursor_x, qbg_cursor_y;
*/
//clear character on screen
i=qbg_cursor_x; i2=qbg_cursor_y;
*c->chr=32;
qbs_print(c,0);
qbg_cursor_x=i; qbg_cursor_y=i2;


goto qbs_input_next;
}

if (inpstr2->len>=255) goto qbs_input_next;



//affect inpstr2 with key
qbs_set(inpstr2,qbs_add(inpstr2,key));

//perform actual update
qbs_print(key,0);


qbs_set(inpstr,inpstr2);




goto qbs_input_next;




}




const char *func_val_max[]={"1797693134862315"};
double func_val(qbs *s){
static unsigned char *val_max;
val_max=(unsigned char*)func_val_max[0];
static long i,i2,step,c,num_significant_digits,most_significant_digit_position;
static long num_exponent_digits;
static long negate,negate_exponent;
static unsigned char significant_digits[16];
static __int64 exponent_value;
static unsigned char built_number[32];
static double return_value;
static __int64 value;
static __int64 hex_value;
static long hex_digits;
if (!s->len) return 0;
value=0;
negate_exponent=0;
num_exponent_digits=0;
num_significant_digits=0;
most_significant_digit_position=0;
step=0;
exponent_value=0;
negate=0;

i=0;
for (i=0;i<s->len;i++){
c=s->chr[i];

if ((c==32)||(c==9)) goto whitespace;

if (c==38){//&
if (step==0) goto hex;
goto finish;
}

if (c==45){//-
if (step==0){negate=1; step=1; goto checked;}
if (step==3){negate_exponent=1; step=4; goto checked;}
goto finish;
}

if (c==43){//+
if (step==0){step=1; goto checked;}
if (step==3){step=4; goto checked;}
goto finish;
}

if ((c>=48)&&(c<=57)){//0-9

if (step<=1){//before decimal point
step=1;
if ((num_significant_digits)||(c>48)){
most_significant_digit_position++;
if (num_significant_digits>=16) goto checked;
significant_digits[num_significant_digits]=c;
num_significant_digits++;
value=value*10+c-48;
}
}

if (step==2){//after decimal point
if ((num_significant_digits==0)&&(c==48)) most_significant_digit_position--;
if ((num_significant_digits)||(c>48)){
if (num_significant_digits>=16) goto checked;
significant_digits[num_significant_digits]=c;
num_significant_digits++;
}
}

if (step>=3){//exponent
step=4;
if ((num_exponent_digits)||(c>48)){
if (num_exponent_digits>=18) goto finish;
exponent_value*=10; exponent_value=exponent_value+c-48;//precalculate
num_exponent_digits++;
}
}

goto checked;
}

if (c==46){//.
if (step>1) goto finish;
step=2; goto checked;
}

if ((c==68)||(c==69)||(c==100)||(c==101)){//D,E,d,e
if (step>2) goto finish;
step=3; goto checked;
}

goto finish;//invalid character
checked:
whitespace:;
}
finish:;

if (num_significant_digits==0) return 0;

if (exponent_value==0){
if (num_significant_digits==most_significant_digit_position){
if (negate) value=-value;
return value;
}
}

if (negate_exponent) exponent_value=-exponent_value;
i=0;
if (negate) {built_number[i]=45; i++;}//-
if (num_significant_digits){
 for (i2=0;i2<num_significant_digits;i2++){
 if (i2==1){built_number[i]=46; i++;}
 built_number[i]=significant_digits[i2]; i++;
 }
 built_number[i]=69; i++;//E
 //adjust exponent value appropriately
 //if most_significant_digit_position=1, then no change need occur
 exponent_value=exponent_value+most_significant_digit_position-1;
 //range check exponent value & return an error if necessary
 if (exponent_value>308){error(6); return 0;}
 if (exponent_value<-324)return 0;
 //range check significant digits (if necessary)
 //LIMIT FROM QB4.5 ---> PRINT VAL("1.797693134862315D+308"), the largest possible value
 if (exponent_value==308){
 for (i2=0;i2<num_significant_digits;i2++){
 if (significant_digits[i2]>val_max[i2]){error(6); return 0;}
 if (significant_digits[i2]<val_max[i2]) break;
 }
 }
 //add exponent's value
 i2=sprintf((char*)&built_number[i],"%I64i",exponent_value);
 i=i+i2;
}else{
 built_number[i]=48; i++;//0
}
built_number[i]=0;//NULL terminate
sscanf((char*)&built_number[0],"%lf",&return_value);
return return_value;
hex:
if (i>=(s->len-2)) return 0;
c=s->chr[i+1]; if ((c!=72)&&(c!=104)) return 0;//H or h?
hex_digits=0;
hex_value=0;
for (i=i+2;i<s->len;i++){
c=s->chr[i];
if ( ((c>=48)&&(c<=57)) || ((c>=65)&&(c<=70)) || ((c>=97)&&(c<=102)) ){//0-9 or A-F or a-f
if ((c>=48)&&(c<=57)) c-=48;
if ((c>=65)&&(c<=70)) c-=55;
if ((c>=97)&&(c<=102)) c-=87;
hex_value<<=4;
hex_value|=c;
if (hex_digits||c) hex_digits++;
if (hex_digits>16) {error(6); return 0;}
}else break;
}//i
return hex_value;
}






long unsupported_port_accessed=0;

long H3C8_palette_register_index=0;
long H3C9_next=0;
long palette_register_index=0;

void sub_out(long port,long data){
unsupported_port_accessed=0;
port=port&65535;
data=data&255;
if (port==968){//&H3C8, set palette register index
H3C8_palette_register_index=data;
goto done;
}
if (port==969){//&H3C9, set palette color
data=data&63;
if (H3C9_next==0){//red
pal[H3C8_palette_register_index]&=0x00FFFF;
pal[H3C8_palette_register_index]+=(qbr((double)data*4.063492f-0.4999999f)<<16);
}
if (H3C9_next==1){//green
pal[H3C8_palette_register_index]&=0xFF00FF;
pal[H3C8_palette_register_index]+=(qbr((double)data*4.063492f-0.4999999f)<<8);
}
if (H3C9_next==2){//blue
pal[H3C8_palette_register_index]&=0xFFFF00;
pal[H3C8_palette_register_index]+=qbr((double)data*4.063492f-0.4999999f);
}
H3C9_next=H3C9_next+1;
if (H3C9_next==3){
H3C9_next=0;
H3C8_palette_register_index=H3C8_palette_register_index+1;
H3C8_palette_register_index&=0xFF;
}
goto done;
}

unsupported_port_accessed=1;
done:
return;
error:
error(5);
}

//ALERT: OLD RANDOM FORMULAS, MADE OBSELETE BY 100% QB/QB4.5 COMPAT. FORMULA!
//Sourced from: http://support.microsoft.com/kb/28150
/*
' To try this example in VBDOS.EXE:
' 1. From the File menu, choose New Project.
' 2. Copy the code example to the Code window.
' 3. Press F5 to run the program.
DEFDBL A-Z  ' Requires double-precision intermediate variables.
a = 214013
c = 2531011
z = 2 ^ 24
INPUT "Input any seed value: ", x0
FOR count = 1 TO 25   ' print 25 random numbers between 0.0 and 1.0:
  temp = x0 * a + c
' Calculate (temp MOD z) and assign to x1:
  temp = temp / z
  x1 = (temp - FIX(temp)) * z
' Print the result as value between 0.0000000 and 1.0000000:
  result = x1 / z
  PRINT result
' Reseed the calculation before the next iteration:
  x0 = x1   ' x0 and x1 range from 0 to 16777216 (2^24)
NEXT
*/
/*
double rnd_seed=0.0;
void sub_randomize (float seed,long passed){
if (passed){
if (seed<0) seed=((double)-1.0f)/seed;
rnd_seed=seed;
return;
}
qbs_print(qbs_new_txt("Random-number seed (-32768 to 32767)? "),0);
static unsigned short integerseed;
qbs_input_variabletypes[1]=2;
qbs_input_variableoffsets[1]=&integerseed;
qbs_input(1,1);
rnd_seed=integerseed;
return;
}
float func_rnd(float value){
static double a=214013.0;//multiplier
static double c=2531011.0;//added
static double z=16777216.0;//2^24
static double temp,x1;
static double l=0;
if (value==0){
return l;
}
if (value<0){
rnd_seed=-value;
}
temp=(rnd_seed*a+c)/z;
x1=((double)(temp-(__int64)temp))*z;
rnd_seed=x1;
return l=x1/z;
}
*/

unsigned long rnd_seed=327680;
void sub_randomize (double seed,long passed){
if (passed){
//Dim As Uinteger m = cptr(Uinteger Ptr, @n)[1]
static unsigned long m;
m=((unsigned long*)&seed)[1];
//m Xor= (m Shr 16)
m^=(m>>16);
//rnd_seed = (m And &hffff) Shl 8 Or (rnd_seed And &hff)
rnd_seed=((m&0xffff)<<8)|(rnd_seed&0xff);
return;
}
qbs_print(qbs_new_txt("Random-number seed (-32768 to 32767)? "),0);
static short integerseed;
qbs_input_variabletypes[1]=16;//id.t=16 'a signed 16 bit integer
qbs_input_variableoffsets[1]=&integerseed;
qbs_input(1,1);
//rnd_seed = (m And &hffff) Shl 8 Or (rnd_seed And &hff) 'nb. same as above
rnd_seed=((integerseed&0xffff)<<8)|(rnd_seed&0xff);
return;
}
float func_rnd(float n,long passed){
static unsigned long m;
if (!passed) n=1.0f;
if (n!=0.0){
if (n<0.0){
m=*((unsigned long*)&n);
rnd_seed=(m&0xFFFFFF)+((m&0xFF000000)>>24);
}
rnd_seed=(rnd_seed*16598013+12820163)&0xFFFFFF;
}     
return (double)rnd_seed/0x1000000;
}
/*
Function Rnd(Byval n As Single = 1) As Double   
    If n <> 0.0 Then       
        If n < 0.0 Then
            Dim As Uinteger m = *cptr(Uinteger Ptr, @n)
            rnd_seed = (m And &hffffff) + (m And &hff000000) Shr 24
        End If       
        rnd_seed = (rnd_seed * 16598013 + 12820163) And &hffffff       
    End If
    Function = rnd_seed / &h1000000   
End Function
*/


























float func_timer(){
static unsigned long x;
static double d;
x=SDL_GetTicks();
x-=sdl_firsttimervalue;
x+=qb64_firsttimervalue;
//make timer value loop after midnight
//note: there are 86400000 milliseconds in 24hrs(1 day)
func_timer_fixoffset:
if (x>=86400000){
x-=86400000;
goto func_timer_fixoffset;
}
d=x;
//reduce accuracy to 18.2 "ticks" per second
d*=18.2;
d/=1000.0;
d=(unsigned long)d;//round
d/=18.2;
return (float)d;
}

void sub_sound(double frequency,double lengthinclockticks){
//note: there are 18.2 clock ticks per second
if (frequency<37.0) goto error;
if (frequency>32767.0) goto error;
if (lengthinclockticks<0.0) goto error;
if (lengthinclockticks>65535.0) goto error;
if (lengthinclockticks==0.0) return;
qb64_generatesound(frequency,lengthinclockticks/18.2,1);
return;
error:
error(5);
}

//force abs to return floating point numbers correctly
inline double func_abs(double d){
return fabs(d);
}
inline long double func_abs(long double d){
return fabs(d);
}
inline float func_abs(float d){
return fabs(d);
}
inline unsigned char func_abs(unsigned char d){return d;}
inline unsigned short func_abs(unsigned short d){return d;}
inline unsigned long func_abs(unsigned long d){return d;}
inline unsigned __int64 func_abs(unsigned __int64 d){return d;}
inline char func_abs(char d){return abs(d);}
inline short func_abs(short d){return abs(d);}
inline long func_abs(long d){return abs(d);}
inline __int64 func_abs(__int64 d){return abs(d);}

//FILE ACCESS SUBS/FUNCTIONS
//device handles
struct device_handle_struct
{
unsigned long open;//1 or 0
fstream fh;
ofstream ofh;
ifstream ifh;
long pos;
long eof_reached;
long read_access;
long write_access;
long type;
long record_length;
unsigned __int64 column;//used for tab'ing in OUTPUT modes (starts at 0!)
//...
};
unsigned long last_device_handle=65535;
//device_handle_struct *device_handle=(device_handle_struct*)calloc(65536*sizeof(device_handle_struct),1);
device_handle_struct device_handle[65536];

void sub_open(qbs *name,long type,long access,long sharing,long i,long record_length,long passed){



//?[{FOR RANDOM|FOR BINARY|FOR INPUT|FOR OUTPUT|FOR APPEND}]
//1 2
//[{ACCESS READ WRITE|ACCESS READ|ACCESS WRITE}]
//  3
//[{SHARED|LOCK READ WRITE|LOCK READ|LOCK WRITE}]{AS}[#]?[{LEN =}?]
//  4                                                   5        6[1]
static unsigned long x,x2,x3;
static qbs *tqbs=NULL;
if (!tqbs) tqbs=qbs_new(0,0);
static qbs *nullt=NULL;
if (!nullt) nullt=qbs_new(1,0);
nullt->chr[0]=0;



//check range of i
if ((i<1)||(i>last_device_handle)){error(52); return;}//Bad file name or number
//check if already open
if (device_handle[i].open){error(55); return;}//File already open





if (type<=1){//RANDOM (default)
//note: default record len=128
device_handle[i].record_length=128;
if (passed){
if ((record_length==0)||(record_length<-1)){error(5); return;}//Illegal function call
if (record_length==-1) record_length=128;
device_handle[i].record_length=record_length;
}
qbs_set(tqbs,qbs_add(name,nullt));//prepare null-terminated filename
device_handle[i].read_access=1; device_handle[i].write_access=1;
if (access==2) device_handle[i].write_access=0;
if (access==3) device_handle[i].read_access=0;
//file exists?
device_handle[i].ifh.open((const char*)tqbs->chr,ios::in);
if (device_handle[i].ifh.is_open()){
device_handle[i].ifh.close();
}else{
//create file
device_handle[i].ofh.open((const char*)tqbs->chr,ios::out);
if (device_handle[i].ofh.is_open()==NULL){error(64); return;}//Bad file name
device_handle[i].ofh.close();
}
device_handle[i].fh.open((const char*)tqbs->chr,ios::binary|ios::out|ios::in);
if (device_handle[i].fh.is_open()==NULL){error(64); return;}//Bad file name
device_handle[i].open=1;
device_handle[i].pos=0;
device_handle[i].eof_reached=0;
device_handle[i].type=1;
return;
}

if (type==2){//BINARY
//note: recordlength is ignored (as in QB4.5) for BINARY
qbs_set(tqbs,qbs_add(name,nullt));//prepare null-terminated filename
device_handle[i].read_access=1; device_handle[i].write_access=1;
if (access==2) device_handle[i].write_access=0;
if (access==3) device_handle[i].read_access=0;
//file exists?
device_handle[i].ifh.open((const char*)tqbs->chr,ios::in);
if (device_handle[i].ifh.is_open()){
device_handle[i].ifh.close();
}else{
//create file
device_handle[i].ofh.open((const char*)tqbs->chr,ios::out);
if (device_handle[i].ofh.is_open()==NULL){error(64); return;}//Bad file name
device_handle[i].ofh.close();
}
device_handle[i].fh.open((const char*)tqbs->chr,ios::binary|ios::out|ios::in);
if (device_handle[i].fh.is_open()==NULL){error(64); return;}//Bad file name
device_handle[i].open=1;
device_handle[i].pos=0;
device_handle[i].eof_reached=0;
device_handle[i].type=2;
return;
}



if (type==5){//APPEND
qbs_set(tqbs,qbs_add(name,nullt));//prepare null-terminated filename
device_handle[i].read_access=0;
device_handle[i].write_access=1;
if (access&&(access!=3)) error(54);//Bad file mode (must have write not read access)
device_handle[i].ifh.open((const char*)tqbs->chr,ios::in);
if (device_handle[i].ifh.is_open()){
device_handle[i].ifh.close();
}else{
//create the file
device_handle[i].ofh.open((const char*)tqbs->chr,ios::out);
if (device_handle[i].ofh.is_open()==NULL){error(64); return;}//cannot create file!
device_handle[i].ofh.close();
}
device_handle[i].fh.open((const char*)tqbs->chr,ios::binary|ios::out|ios::in);
if (device_handle[i].fh.is_open()==NULL){error(64); return;}//cannot open file!
device_handle[i].fh.seekp(0,ios::end);
device_handle[i].open=1;
device_handle[i].pos=device_handle[i].fh.tellp();
device_handle[i].eof_reached=0;
device_handle[i].type=4;//OUTPUT type
device_handle[i].column=0;
return;
}

if (type==4){//OUTPUT
qbs_set(tqbs,qbs_add(name,nullt));//prepare null-terminated filename
device_handle[i].read_access=0;
device_handle[i].write_access=1;
if (access&&(access!=3)) error(54);//Bad file mode (must have write not read access)
device_handle[i].fh.open((const char*)tqbs->chr,ios::binary|ios::out);
if (device_handle[i].fh.is_open()==NULL){error(64); return;}//cannot open file!
device_handle[i].open=1;
device_handle[i].pos=0;
device_handle[i].eof_reached=0;
device_handle[i].type=4;
device_handle[i].column=0;
return;
}

if (type==3){//INPUT
qbs_set(tqbs,qbs_add(name,nullt));//prepare null-terminated filename
device_handle[i].read_access=1;
device_handle[i].write_access=0;
if (access&&(access!=2)) error(54);//Bad file mode (must have read not write access)
device_handle[i].fh.open((const char*)tqbs->chr,ios::binary|ios::in);
if (device_handle[i].fh.is_open()==NULL){error(64); return;}//cannot open file!
device_handle[i].open=1;
device_handle[i].pos=0;
device_handle[i].eof_reached=0;
device_handle[i].type=3;
return;
}


exit(89);//unknown command
}

void sub_close(long i2,long passed){
static long i;
if (passed){
 i=i2;
 if (device_handle[i].open){
 if (device_handle[i].fh.is_open()) device_handle[i].fh.close();
 device_handle[i].open=0;
 }
}else{
 for (i=1;i<=65535;i++){
  if (device_handle[i].open){
  if (device_handle[i].fh.is_open()) device_handle[i].fh.close();
  device_handle[i].open=0;
  }
 }
}
}//close





long file_input_chr(long i){
//returns -1 if eof reached
static unsigned char c;
if (device_handle[i].eof_reached){
device_handle[i].fh.seekg(device_handle[i].pos,ios::beg);
if (!device_handle[i].fh.eof()) device_handle[i].eof_reached=0; else {device_handle[i].fh.clear(); return -1;}
}
device_handle[i].fh.read((char*)&c,1);
if (!device_handle[i].fh.gcount()){
device_handle[i].fh.clear();
device_handle[i].eof_reached=1;
return -1;
}else{
//CHR$(26)?
if (c==26){
device_handle[i].fh.seekg(device_handle[i].pos,ios::beg);//go back 1 byte
return -1;
}
device_handle[i].pos++;
}
return c;
}

void file_input_nextitem(long i,long lastc){
//this may require reversing a bit too!
long c,nextc;
c=lastc;
nextchr:
if (c==-1) return;
if (c==32){
nextc=file_input_chr(i);
if ( (nextc!=32)&&(nextc!=44)&&(nextc!=10)&&(nextc!=13) ){
device_handle[i].pos--; device_handle[i].fh.seekg(device_handle[i].pos,ios::beg); device_handle[i].eof_reached=0;
return;
}else{
c=nextc;
goto nextchr;
}
}
if (c==44) return;//,
if (c==10){//lf 
nextc=file_input_chr(i);
if (nextc==13) return;
//backtrack
device_handle[i].pos--; device_handle[i].fh.seekg(device_handle[i].pos,ios::beg); device_handle[i].eof_reached=0;
return;
}
if (c==13){//lf 
nextc=file_input_chr(i);
if (nextc==10) return;
//backtrack
device_handle[i].pos--; device_handle[i].fh.seekg(device_handle[i].pos,ios::beg); device_handle[i].eof_reached=0;
return;
}
c=file_input_chr(i);
goto nextchr;
}


char sub_file_print_spaces[32];
void sub_file_print(long i,qbs *str,long extraspace,long tab,long newline){
//assume correct mode
//assume pos is not past eof!
device_handle[i].fh.write((char*)str->chr,str->len);
device_handle[i].column+=str->len;

//add extra spaces as needed
static long nspaces,x;
static short cr_lf=13+10*256; 
nspaces=0;
if (extraspace){
nspaces++;
device_handle[i].column++;
}
if (tab){
//a space MUST be added
nspaces++;
device_handle[i].column++;
x=device_handle[i].column%14;
if (x!=0){
x=14-x;
nspaces+=x;
device_handle[i].column+=x;
}
}
if (nspaces){
device_handle[i].fh.write(&sub_file_print_spaces[0],nspaces);
}
if (newline){
device_handle[i].fh.write((char*)&cr_lf,2);
device_handle[i].column=0;
}
}

//number limits
const char *range_int64_max[]={"9223372036854775807"};//19 digits
const char *range_int64_neg_max[]={"9223372036854775808"};//19 digits
const char *range_uint64_max[]={"18446744073709551615"};//20 digits
const char *range_float_max[]=    {"17976931348623157"};//17 digits
                          
//universal number representation
unsigned short n_digits;
unsigned char n_digit[256];
__int64 n_exp;//if 0, there is one digit in front of the decimal place
unsigned char n_neg;//if 1, the number is negative
unsigned char n_hex;//if 1, the digits are in hexidecimal and n_exp should be ignored

long n_roundincrement(){
static long i,i2,i3;
if (n_digits==0) return 0;
if (n_digits>(n_exp+1)){//numbers exist after the decimal point
i=n_digit[n_exp+1]-48;
if (i>=5) return 1;
}
return 0;
}

long double n_float_value;
long n_float(){
//return value: Bit 0=successful
//data
static unsigned char built[32];
static __int64 value;
unsigned __int64 uvalue;
static long i,i2,i3;
static unsigned char *max;
max=(unsigned char*)range_float_max[0];
n_float_value=0; value=0; uvalue=0;
if (n_digits==0) return 1;
//hexadecimal?
if (n_hex){
if (n_digits>16) return 0;
for (i=0;i<n_digits;i++){
 i2=n_digit[i];
 if ((i2>=48)&&(i2<=57)) i2-=48;
 if ((i2>=65)&&(i2<=70)) i2-=55;
 if ((i2>=97)&&(i2<=102)) i2-=87;
 value<<=4;
 value|=i2;
}
n_float_value=value;
return 1;
}
//max range check (+-1.7976931348623157E308)
if (n_exp>308)return 0;//overflow
if (n_exp==308){
 i2=n_digits; if (i2>17) i2=17;
 for (i=0;i<i2;i++){
  if (n_digit[i]>max[i]) return 0;//overflow
  if (n_digit[i]<max[i]) break;
 }
}
//too close to 0?
if (n_exp<-324) return 1;
//read & return value (via C++ function)
//build number
i=0;
if (n_neg){built[i]=45; i++;}//-
built[i]=n_digit[0]; i++;
built[i]=46; i++;//.
if (n_digits==1){
built[i]=48; i++;//0
}else{
 i3=n_digits; if (i3>17) i3=17;
 for (i2=1;i2<i3;i2++){
 built[i]=n_digit[i2]; i++;
 }
}
built[i]=69; i++;//E
i2=sprintf((char*)&built[i],"%I64i",n_exp);
i=i+i2;

static double sscanf_fix;
sscanf((char*)&built[0],"%lf",&sscanf_fix);
n_float_value=sscanf_fix;

return 1;
}

__int64 n_int64_value;
long n_int64(){
//return value: Bit 0=successful
//data
static __int64 value;
unsigned __int64 uvalue;
static long i,i2;
static unsigned char *max; static unsigned char *neg_max;
static __int64 v0=build_int64(0x80000000,0x00000000);
static __int64 v1=build_int64(0x7FFFFFFF,0xFFFFFFFF);
max=(unsigned char*)range_int64_max[0]; neg_max=(unsigned char*)range_int64_neg_max[0];
n_int64_value=0; value=0; uvalue=0;
if (n_digits==0) return 1;
//hexadecimal?
if (n_hex){
if (n_digits>16) return 0;
for (i=0;i<n_digits;i++){
 i2=n_digit[i];
 if ((i2>=48)&&(i2<=57)) i2-=48;
 if ((i2>=65)&&(i2<=70)) i2-=55;
 if ((i2>=97)&&(i2<=102)) i2-=87;
 value<<=4;
 value|=i2;
}
n_int64_value=value;
return 1;
}
//range check: int64 (-9,223,372,036,854,775,808 to 9,223,372,036,854,775,807)
if (n_exp>18)return 0;//overflow
if (n_exp==18){
i2=n_digits; if (i2>19) i2=19;//only scan integeral digits
 for (i=0;i<i2;i++){
  if (n_neg){
  if (n_digit[i]>neg_max[i]) return 0;//overflow
  if (n_digit[i]<neg_max[i]) break;
  }else{
  if (n_digit[i]>max[i]) return 0;//overflow
  if (n_digit[i]<max[i]) break;
  }
 }
}
//calculate integeral value
i2=n_digits; if (i2>(n_exp+1)) i2=n_exp+1;
for (i=0;i<(n_exp+1);i++){
uvalue*=10;
if (i<i2) uvalue=uvalue+(n_digit[i]-48);
}
if (n_neg){
value=-uvalue;
}else{
value=uvalue;
}
//apply rounding
if (n_roundincrement()){
if (n_neg){
if (value==v0) return 0;
value--;
}else{
if (value==v1) return 0;
value++;
}
}
//return value
n_int64_value=value;
return 1;
}

unsigned __int64 n_uint64_value;
long n_uint64(){
//return value: Bit 0=successful
//data
static __int64 value;
unsigned __int64 uvalue;
static long i,i2;
static unsigned char *max;
static __int64 v0=build_uint64(0xFFFFFFFF,0xFFFFFFFF);
max=(unsigned char*)range_uint64_max[0];
n_uint64_value=0; value=0; uvalue=0;
if (n_digits==0) return 1;
//hexadecimal?
if (n_hex){
if (n_digits>16) return 0;
for (i=0;i<n_digits;i++){
 i2=n_digit[i];
 if ((i2>=48)&&(i2<=57)) i2-=48;
 if ((i2>=65)&&(i2<=70)) i2-=55;
 if ((i2>=97)&&(i2<=102)) i2-=87;
 uvalue<<=4;
 uvalue|=i2;
}
n_uint64_value=uvalue;
return 1;
}
//negative?
if (n_neg){
if (n_exp>=0) return 0;//cannot return a negative number!
}
//range check: int64 (0 to 18446744073709551615)
if (n_exp>19)return 0;//overflow
if (n_exp==19){
i2=n_digits; if (i2>20) i2=20;//only scan integeral digits
 for (i=0;i<i2;i++){ 
 if (n_digit[i]>max[i]) return 0;//overflow
 if (n_digit[i]<max[i]) break; 
 }
}
//calculate integeral value
i2=n_digits; if (i2>(n_exp+1)) i2=n_exp+1;
for (i=0;i<(n_exp+1);i++){
uvalue*=10;
if (i<i2) uvalue=uvalue+(n_digit[i]-48);
}
//apply rounding
if (n_roundincrement()){
if (n_neg){
return 0;
}else{
if (uvalue==v0) return 0;
uvalue++;
}
}
//return value
n_uint64_value=uvalue;
return 1;
}

long n_inputnumberfromdata(unsigned char *data,unsigned long *data_offset,unsigned long data_size){
//return values:
//0=success!
//1=Overflow
//2=Out of DATA
//3=Syntax error
//note: when read fails the data_offset MUST be restored to its old position

//data
static long i,i2;
static long step,c;
static long exponent_digits;
static unsigned char negate_exponent;
static __int64 exponent_value;
static long return_value;

return_value=1;//overflow (default)
step=0;
negate_exponent=0;
exponent_value=0;
exponent_digits=0;

//prepare universal number representation
n_digits=0; n_exp=0; n_neg=0; n_hex=0;

//Out of DATA?
if (*data_offset>=data_size) return 2;

//read character
c=data[*data_offset];

//hexadecimal number?
if (c==38){//&

(*data_offset)++; if (*data_offset>=data_size) goto gotnumber;
c=data[*data_offset];
if (c==44){(*data_offset)++; goto gotnumber;}
if ((c!=72)&&(c!=104)) return 3;//not H or h? Syntax error
nexthexchr:
(*data_offset)++; if (*data_offset>=data_size) goto gotnumber;
c=data[*data_offset];
if (c==44){(*data_offset)++; goto gotnumber;}

if ( ((c>=48)&&(c<=57)) || ((c>=65)&&(c<=70)) || ((c>=97)&&(c<=102)) ){//0-9 or A-F or a-f
if (n_digits==256) return 1;//Overflow
n_digit[n_digits]=c;
n_digits++;
n_hex=1;
goto nexthexchr;
}
return 3;//Syntax error
}

readnextchr:
if (c==44){(*data_offset)++; goto gotnumber;}

if (c==45){//-
if (step==0){n_neg=1; step=1; goto nextchr;}
if (step==3){negate_exponent=1; step=4; goto nextchr;}
return 3;//Syntax error
}

if (c==43){//+
if (step==0){step=1; goto nextchr;}
if (step==3){step=4; goto nextchr;}
return 3;//Syntax error
}

if ((c>=48)&&(c<=57)){//0-9

if (step<=1){//before decimal point
step=1;
if (n_digits||(c>48)){
if (n_digits) n_exp++;
if (n_digits==256) return 1;//Overflow
n_digit[n_digits]=c;
n_digits++;
}
}

if (step==2){//after decimal point
if ((n_digits==0)&&(c==48)) n_exp--;
if ((n_digits)||(c>48)){
if (n_digits==256) return 1;//Overflow
n_digit[n_digits]=c;
n_digits++;
}
}

if (step>=3){//exponent
step=4;
if ((exponent_digits)||(c>48)){
if (exponent_digits==18) return 1;//Overflow
exponent_value*=10;
exponent_value=exponent_value+(c-48);
exponent_digits++;
}
}

goto nextchr;
}

if (c==46){//.
if (step>1) return 3;//Syntax error
if (n_digits==0) n_exp=-1;
step=2; goto nextchr;
}

if ((c==68)||(c==69)||(c==100)||(c==101)){//D,E,d,e
if (step>2) return 3;//Syntax error
step=3; goto nextchr;
}

return 3;//Syntax error
nextchr:
(*data_offset)++; if (*data_offset>=data_size) goto gotnumber;
c=data[*data_offset];
goto readnextchr;

gotnumber:;
if (negate_exponent) n_exp-=exponent_value; else n_exp+=exponent_value;//complete exponent
if (n_digits==0) {n_exp=0; n_neg=0;}//clarify number
return 0;//success
}




















long n_inputnumberfromfile(long fileno){
//return values:
//0=success
//1=overflow
//2=eof

//data
static long i,i2;
static long step,c;
static long exponent_digits;
static unsigned char negate_exponent;
static __int64 exponent_value;
static long return_value;

return_value=1;//overflow (default)
step=0;
negate_exponent=0;
exponent_value=0;
exponent_digits=0;

//prepare universal number representation
n_digits=0; n_exp=0; n_neg=0; n_hex=0;

//skip any leading spaces
do{
c=file_input_chr(fileno);
if (c==-1){return_value=2; goto error;}//input past end of file
}while(c==32);

//hexadecimal number?
if (c==38){//&
c=file_input_chr(fileno);
if (c==-1) goto gotnumber;
if ((c!=72)&&(c!=104)) goto gotnumber;//not H or h?
nexthexchr:
c=file_input_chr(fileno);
if ( ((c>=48)&&(c<=57)) || ((c>=65)&&(c<=70)) || ((c>=97)&&(c<=102)) ){//0-9 or A-F or a-f
if (n_digits==256) goto error;//overflow
n_digit[n_digits]=c;
n_digits++;
n_hex=1;
goto nexthexchr;
}
goto gotnumber;
}

readnextchr:
if (c==-1) goto gotnumber;

if (c==45){//-
if (step==0){n_neg=1; step=1; goto nextchr;}
if (step==3){negate_exponent=1; step=4; goto nextchr;}
goto gotnumber;
}

if (c==43){//+
if (step==0){step=1; goto nextchr;}
if (step==3){step=4; goto nextchr;}
goto gotnumber;
}

if ((c>=48)&&(c<=57)){//0-9

if (step<=1){//before decimal point
step=1;
if (n_digits||(c>48)){
if (n_digits) n_exp++;
if (n_digits==256) goto error;//overflow
n_digit[n_digits]=c;
n_digits++;
}
}

if (step==2){//after decimal point
if ((n_digits==0)&&(c==48)) n_exp--;
if ((n_digits)||(c>48)){
if (n_digits==256) goto error;//overflow
n_digit[n_digits]=c;
n_digits++;
}
}

if (step>=3){//exponent
step=4;
if ((exponent_digits)||(c>48)){
if (exponent_digits==18) goto error;//overflow
exponent_value*=10;
exponent_value=exponent_value+(c-48);
exponent_digits++;
}
}

goto nextchr;
}

if (c==46){//.
if (step>1) goto gotnumber;
if (n_digits==0) n_exp=-1;
step=2; goto nextchr;
}

if ((c==68)||(c==69)||(c==100)||(c==101)){//D,E,d,e
if (step>2) goto gotnumber;
step=3; goto nextchr;
}

goto gotnumber;//invalid character
nextchr:
c=file_input_chr(fileno);
goto readnextchr;

gotnumber:;
if (negate_exponent) n_exp-=exponent_value; else n_exp+=exponent_value;//complete exponent
if (n_digits==0) {n_exp=0; n_neg=0;}//clarify number
file_input_nextitem(fileno,c);
return 0;//success

error:
file_input_nextitem(fileno,c);
return return_value;
}

void sub_file_line_input_string(long fileno,qbs *deststr){
static qbs *str,*character;
long c,nextc;
long inspeechmarks;
str=qbs_new(0,0);
c=file_input_chr(fileno);
if (c==-1){
qbs_set(deststr,str);
qbs_free(str);
error(62);//input past end of file
return;
}
character=qbs_new(1,0);
nextchr:
if (c==-1) goto gotstr;
if (c==10) goto gotstr;
if (c==13) goto gotstr;
character->chr[0]=c; qbs_set(str,qbs_add(str,character));
c=file_input_chr(fileno);
goto nextchr;
gotstr:
nextstr:
//scan until next item (or eof) reached
if (c==-1) goto returnstr;
if (c==10){//lf 
nextc=file_input_chr(fileno);
if (nextc==13) goto returnstr;
//backtrack
device_handle[fileno].pos--; device_handle[fileno].fh.seekg(device_handle[fileno].pos,ios::beg); device_handle[fileno].eof_reached=0;
goto returnstr;
}
if (c==13){//cr
nextc=file_input_chr(fileno);
if (nextc==10) goto returnstr;
//backtrack
device_handle[fileno].pos--; device_handle[fileno].fh.seekg(device_handle[fileno].pos,ios::beg); device_handle[fileno].eof_reached=0;
goto returnstr;
}
c=file_input_chr(fileno);
goto nextstr;
//return string
returnstr:
qbs_set(deststr,str);
qbs_free(str);
qbs_free(character);
return;
}

void sub_file_input_string(long fileno,qbs *deststr){
static qbs *str,*character;
long c,nextc;
long inspeechmarks;
str=qbs_new(0,0);
//skip whitespace (spaces & tabs)
do{
c=file_input_chr(fileno);
if (c==-1){
qbs_set(deststr,str);
qbs_free(str);
error(62);//input past end of file
return;
}
}while((c==32)||(c==9));
//quoted string?
inspeechmarks=0;
if (c==34){//"
inspeechmarks=1;
c=file_input_chr(fileno);
}
//read string
character=qbs_new(1,0);
nextchr:
if (c==-1) goto gotstr;
if (inspeechmarks){
if (c==34) goto gotstr;//"
}else{
if (c==44) goto gotstr;//,
if (c==10) goto gotstr;
if (c==13) goto gotstr;
}
character->chr[0]=c; qbs_set(str,qbs_add(str,character));
c=file_input_chr(fileno);
goto nextchr;
gotstr:
//cull trailing whitespace
if (!inspeechmarks){
cullstr:
if (str->len){
if ((str->chr[str->len-1]==32)||(str->chr[str->len-1]==9)){str->len--; goto cullstr;}
}
}
nextstr:
//scan until next item (or eof) reached
if (c==-1) goto returnstr;
if (c==44) goto returnstr;
if (c==10){//lf 
nextc=file_input_chr(fileno);
if (nextc==13) goto returnstr;
//backtrack
device_handle[fileno].pos--; device_handle[fileno].fh.seekg(device_handle[fileno].pos,ios::beg); device_handle[fileno].eof_reached=0;
goto returnstr;
}
if (c==13){//cr
nextc=file_input_chr(fileno);
if (nextc==10) goto returnstr;
//backtrack
device_handle[fileno].pos--; device_handle[fileno].fh.seekg(device_handle[fileno].pos,ios::beg); device_handle[fileno].eof_reached=0;
goto returnstr;
}
c=file_input_chr(fileno);
goto nextstr;
//return string
returnstr:
qbs_set(deststr,str);
qbs_free(str);
qbs_free(character);
return;
}

__int64 func_file_input_int64(long fileno){
static long i;
i=n_inputnumberfromfile(fileno);
if (i==1){error(6); return 0;}//overflow
if (i==2){error(62); return 0;}//input past end of file
if (n_int64()) return n_int64_value;
error(6);//overflow
return 0;
}

unsigned __int64 func_file_input_uint64(long fileno){
static long i;
i=n_inputnumberfromfile(fileno);
if (i==1){error(6); return 0;}//overflow
if (i==2){error(62); return 0;}//input past end of file
if (n_uint64()) return n_uint64_value;
error(6);//overflow
return 0;
}




void sub_read_string(unsigned char *data,unsigned long *data_offset,unsigned long data_size,qbs *deststr){
static qbs *str,*character;
static long c,inspeechmarks;
str=qbs_new(0,0);
character=qbs_new(1,0);
inspeechmarks=0;

if (*data_offset>=data_size){error(4); goto gotstr;}//Out of DATA

c=data[*data_offset];
nextchr:

if (c==44){//,
if (!inspeechmarks){
(*data_offset)++;
goto gotstr;
}
}

if (c==34){//"
if (!str->len) {inspeechmarks=1; goto skipchr;}
if (inspeechmarks) {inspeechmarks=0; goto skipchr;}
}

character->chr[0]=c; qbs_set(str,qbs_add(str,character));
skipchr:

(*data_offset)++; if (*data_offset>=data_size) goto gotstr;
c=data[*data_offset];
goto nextchr;

gotstr:
qbs_set(deststr,str);
qbs_free(str);
qbs_free(character);
return;
}

long double func_read_float(unsigned char *data,unsigned long *data_offset,unsigned long data_size,long typ){
static long i;
static __int64 maxval,minval;
static __int64 value;
static unsigned long old_data_offset;
old_data_offset=*data_offset;
i=n_inputnumberfromdata(data,data_offset,data_size);
//return values:
//0=success!
//1=Overflow
//2=Out of DATA
//3=Syntax error
//note: when read fails the data_offset MUST be restored to its old position
if (i==1){//Overflow
goto overflow;
}
if (i==2){//Out of DATA
error(4);
return 0;
}
if (i==3){//Syntax error
*data_offset=old_data_offset;
error(2); 
return 0;
}

/*
unsigned short n_digits;
unsigned char n_digit[256];
__int64 n_exp;//if 0, there is one digit in front of the decimal place
unsigned char n_neg;//if 1, the number is negative
unsigned char n_hex;//if 1, the digits are in hexidecimal and n_exp should be ignored
*/



if (!n_float()) goto overflow; //returns n_float_value
//range test & return value
if (typ&ISFLOAT){
 if ((typ&511)>=64) return n_float_value;
 if (n_float_value>3.402823466E+38) goto overflow;
return n_float_value;
}else{
 if (n_float_value<(-(9.2233720368547758E+18)))goto overflow;//too low to store!
 if (n_float_value>   9.2233720368547758E+18)  goto overflow;//too high to store!
 value=qbr(n_float_value);
 if (typ&ISUNSIGNED){
 maxval=(1<<(typ&511))-1;
 minval=0;
 }else{
 maxval=(1<<((typ&511)-1))-1;
 minval=-(1<<((typ&511)-1));
 }
 if ((value>maxval)||(value<minval)) goto overflow;
 return value;
}

overflow:
*data_offset=old_data_offset;
error(6); 
return 0;
}//func_file_input_float




































long double func_file_input_float(long fileno,long typ){
static long i;
static __int64 maxval,minval;
static __int64 value;
i=n_inputnumberfromfile(fileno);
if (i==1){error(6); return 0;}//overflow
if (i==2){error(62); return 0;}//input past end of file
if (!n_float()){error(6); return 0;} //returns n_float_value
//range test & return value
if (typ&ISFLOAT){
 if ((typ&511)>=64) return n_float_value;
 if (n_float_value>3.402823466E+38){error(6); return 0;}
 return n_float_value;
}else{
 if (n_float_value<(-(9.2233720368547758E+18))){error(6); return 0;}//too low to store!
 if (n_float_value>   9.2233720368547758E+18)  {error(6); return 0;}//too high to store!
 value=qbr(n_float_value);
 if (typ&ISUNSIGNED){
 maxval=(1<<(typ&511))-1;
 minval=0;
 }else{
 maxval=(1<<((typ&511)-1))-1;
 minval=-(1<<((typ&511)-1));
 }
 if ((value>maxval)||(value<minval)){error(6); return 0;}
 return value;
}
}//func_file_input_float







//revise following!
void *byte_element(unsigned __int64 offset,unsigned long length){
//add structure to xms stack (byte_element structures are never stored in cmem!)
void *p;
if ((mem_static_pointer+=12)<mem_static_limit) p=mem_static_pointer-12; else p=mem_static_malloc(12);
*((unsigned __int64*)p)=offset;
((unsigned long*)p)[2]=length;
return p;
}

void sub_get(long i,long offset,void *element,long passed){
static byte_element_struct *ele;
static long x;
if ((i<1)||(i>65535)){error(52); return;}
if (!device_handle[i].open){error(52); return;}
if (device_handle[i].type>2){error(54); return;}
if (!device_handle[i].read_access){error(75); return;}

ele=(byte_element_struct*)element;

if (device_handle[i].type==1){
if (ele->length>device_handle[i].record_length){error(59); return;}//Bad record length
if (passed){
offset--;
if (offset<0){error(63); return;}//Bad record number
offset*=device_handle[i].record_length;
offset++;
}
}

if (passed){
 offset--;
 if (offset<0){error(63); return;} 
 if (offset==device_handle[i].pos){
  if (device_handle[i].eof_reached){
   device_handle[i].fh.seekg(offset,ios::beg);
   if (device_handle[i].fh.eof()) device_handle[i].fh.clear(); else device_handle[i].eof_reached=0;   
  }  
 }else{
  device_handle[i].fh.seekg(offset,ios::beg);
  if (device_handle[i].fh.eof()){device_handle[i].eof_reached=1; device_handle[i].fh.clear();} else device_handle[i].eof_reached=0;  
  device_handle[i].pos=offset;
 } 
}else{
 if (device_handle[i].eof_reached){
  device_handle[i].fh.seekg(device_handle[i].pos,ios::beg);
  if (device_handle[i].fh.eof()) device_handle[i].fh.clear(); else device_handle[i].eof_reached=0;  
 }
}

device_handle[i].pos+=ele->length;

if (ele->length){
if (device_handle[i].eof_reached){
 memset((void*)(ele->offset),0,ele->length);
}else{
 device_handle[i].fh.read((char*)(ele->offset),ele->length);
 x=device_handle[i].fh.gcount();
 if (x<ele->length){
 device_handle[i].fh.clear();
 device_handle[i].eof_reached=1;
 memset((void*)(ele->offset+x),0,ele->length-x); 
 }
}
}
if (device_handle[i].type==2) return;//BINARY

//RANDOM
if (ele->length<device_handle[i].record_length){
x=device_handle[i].record_length-ele->length;
device_handle[i].fh.seekg(device_handle[i].pos+x,ios::beg);
if (device_handle[i].fh.eof()){
device_handle[i].fh.clear(); device_handle[i].eof_reached=1;
device_handle[i].fh.seekg(0,ios::end);
}
device_handle[i].pos+=x;
}

}//end (get)

void sub_get2(long i,long offset,qbs *str,long passed){
static long x;
if ((i<1)||(i>65535)){error(52); return;}
if (!device_handle[i].open){error(52); return;}
if (device_handle[i].type>2){error(54); return;}
//BINARY
if (device_handle[i].type==2){
if (!device_handle[i].read_access){error(75); return;}
sub_get(i,offset,byte_element((unsigned __int64)str->chr,str->len),passed);
return;
}
//RANDOM (copied and modified from sub_get)
if (!device_handle[i].read_access){str->len=0; error(75); return;}
if (device_handle[i].record_length<2){error(59); return;}//Bad record length

if (passed){
 offset--;
 if (offset<0){str->len=0; error(63); return;}//Bad record number
 offset*=device_handle[i].record_length;
 if (offset==device_handle[i].pos){
  if (device_handle[i].eof_reached){
   device_handle[i].fh.seekg(offset,ios::beg);
   if (device_handle[i].fh.eof()) device_handle[i].fh.clear(); else device_handle[i].eof_reached=0;
  }
 }else{
  device_handle[i].fh.seekg(offset,ios::beg);
  if (device_handle[i].fh.eof()) device_handle[i].eof_reached=1;
  device_handle[i].fh.clear();
  device_handle[i].pos=offset;
 }
}else{
 if (device_handle[i].eof_reached){
  device_handle[i].fh.seekg(device_handle[i].pos,ios::beg);
  if (device_handle[i].fh.eof()) device_handle[i].fh.clear(); else device_handle[i].eof_reached=0;
 }
}

//read the entire record
static char *data;
static long l,x2;
data=(char*)malloc(device_handle[i].record_length);
device_handle[i].pos+=device_handle[i].record_length;
device_handle[i].fh.read(data,device_handle[i].record_length);
x=device_handle[i].fh.gcount();
if (x<device_handle[i].record_length){
device_handle[i].fh.clear();
device_handle[i].eof_reached=1;
memset((void*)(data+x),0,device_handle[i].record_length-x);
}

x2=2;//offset where actual string data will be read from
l=((unsigned short*)data)[0];
if (l&32768){
 if (device_handle[i].record_length<4){
 //record length is too small to read the length data
 //move read position back to previous location
 device_handle[i].pos-=device_handle[i].record_length;
 device_handle[i].fh.seekg(device_handle[i].pos,ios::beg);
 if (device_handle[i].fh.eof()){device_handle[i].fh.clear(); device_handle[i].eof_reached=1;}
  free(data);
 str->len=0; error(59); return;//Bad record length
 }
x2=4;
l=((((unsigned short*)data)[1])<<15)+l-32768;
}
 if ((device_handle[i].record_length-x2)<l){
 //record_length cannot fit the string's data
 //move read position back to previous location
 device_handle[i].pos-=device_handle[i].record_length;
 device_handle[i].fh.seekg(device_handle[i].pos,ios::beg);
 if (device_handle[i].fh.eof()){device_handle[i].fh.clear(); device_handle[i].eof_reached=1;}
 free(data);
 str->len=0; error(59); return;//Bad record length
 }
//success
qbs_set(str,qbs_new_txt_len(data+x2,l));
free(data);
}

void sub_put(long i,long offset,void *element,long passed){
static byte_element_struct *ele;
static char *nullchrs;
static long x;
if ((i<1)||(i>65535)){error(52); return;}
if (!device_handle[i].open){error(52); return;}
if (device_handle[i].type>2){error(54); return;}
if (!device_handle[i].write_access){error(75); return;}

ele=(byte_element_struct*)element;

if (device_handle[i].type==1){
if (ele->length>device_handle[i].record_length){error(59); return;}//Bad record length
if (passed){
offset--;
if (offset<0){error(63); return;}//Bad record number
offset*=device_handle[i].record_length;
offset++;
}
}

if (passed){
 offset--;
 if (offset<0){error(63); return;} 
 if (offset==device_handle[i].pos){
  if (device_handle[i].eof_reached){
  device_handle[i].fh.seekp(offset,ios::beg);
  if (device_handle[i].fh.eof()){
  device_handle[i].fh.clear();
  //extend file
  device_handle[i].fh.seekp(0,ios::end);
  x=device_handle[i].fh.tellp();
  x=offset-x;
  nullchrs=(char*)calloc(x,1);
  device_handle[i].fh.write(nullchrs,x);
  free(nullchrs);
  device_handle[i].eof_reached=0;
  }
  }
 }else{
  //need to set new offset
  device_handle[i].fh.seekp(offset,ios::beg);
  if (device_handle[i].fh.eof()){
   device_handle[i].fh.clear();
  //extend file
  device_handle[i].fh.seekp(0,ios::end);
  x=device_handle[i].fh.tellp();
  x=offset-x;
  nullchrs=(char*)calloc(x,1);
  device_handle[i].fh.write(nullchrs,x);
  free(nullchrs);
  device_handle[i].eof_reached=0;
  } 
  device_handle[i].pos=offset;
 }
}else{
 if (device_handle[i].eof_reached){
 device_handle[i].fh.seekp(device_handle[i].pos,ios::beg);
 if (device_handle[i].fh.eof()){
  device_handle[i].fh.clear();
 //extend file
 device_handle[i].fh.seekp(0,ios::end);
 x=device_handle[i].fh.tellp();
 x=device_handle[i].pos-x;
 nullchrs=(char*)calloc(x,1);
 device_handle[i].fh.write(nullchrs,x);
 free(nullchrs);
 device_handle[i].eof_reached=0;
 }
 }
}

if (ele->length){
device_handle[i].fh.write((char*)(ele->offset),ele->length);
}
device_handle[i].pos+=ele->length;

if (device_handle[i].type==1){
if (ele->length<device_handle[i].record_length){
x=device_handle[i].record_length-ele->length;
device_handle[i].fh.seekp(device_handle[i].pos+x,ios::beg);
if (device_handle[i].fh.eof()){
device_handle[i].fh.clear();
device_handle[i].eof_reached=1;
}
if (device_handle[i].eof_reached){
device_handle[i].fh.seekp(device_handle[i].pos,ios::beg);
}
device_handle[i].pos+=x;
}
}

}

//put2 adds a 2-4 byte length descriptor to the data
//(used to PUT variable length strings in RANDOM mode)
void sub_put2(long i,long offset,void *element,long passed){
static byte_element_struct *ele;
static long l,x;
static unsigned char *data;
if ((i<1)||(i>65535)){error(52); return;}
if (!device_handle[i].open){error(52); return;}
if (device_handle[i].type>2){error(54); return;}
if (!device_handle[i].write_access){error(75); return;}
if (device_handle[i].type==1){
ele=(byte_element_struct*)element;
l=ele->length;
//[15][1][[16]]
if (l>32767){
data=(unsigned char*)malloc(l+4);
memcpy(&data[4],(char*)(ele->offset),l);
((unsigned short*)data)[0]=(l&32767)+32768;
x=l; x>>=15;
((unsigned short*)data)[1]=x;
ele->length+=4;
}else{
data=(unsigned char*)malloc(l+2);
memcpy(&data[2],(char*)(ele->offset),l);
((unsigned short*)data)[0]=l;
ele->length+=2;
}
ele->offset=(unsigned __int64)&data[0];
sub_put(i,offset,element,passed);
free(data);
}else{
sub_put(i,offset,element,passed);
}
}






void sub_graphics_get(long step1,float x1f,float y1f,long step2,float x2f,float y2f,void *element,unsigned long mask,long passed){
static long x1,y1,x2,y2;

//change coordinates according to step
if (step1){x1f=qbg_x+x1f; y1f=qbg_y+y1f;}
qbg_x=x1f; qbg_y=y1f;
if (step2){x2f=qbg_x+x2f; y2f=qbg_y+y2f;}
qbg_x=x2f; qbg_y=y2f;

//resolve coordinates
if (qbg_clipping_or_scaling){
if (qbg_clipping_or_scaling==2){
x1=qbr_float_to_long(x1f*qbg_scaling_x+qbg_scaling_offset_x)+qbg_view_offset_x;
y1=qbr_float_to_long(y1f*qbg_scaling_y+qbg_scaling_offset_y)+qbg_view_offset_y;
x2=qbr_float_to_long(x2f*qbg_scaling_x+qbg_scaling_offset_x)+qbg_view_offset_x;
y2=qbr_float_to_long(y2f*qbg_scaling_y+qbg_scaling_offset_y)+qbg_view_offset_y;
}else{
x1=qbr_float_to_long(x1f)+qbg_view_offset_x; y1=qbr_float_to_long(y1f)+qbg_view_offset_y;
x2=qbr_float_to_long(x2f)+qbg_view_offset_x; y2=qbr_float_to_long(y2f)+qbg_view_offset_y;
}
}else{
x1=qbr_float_to_long(x1f); y1=qbr_float_to_long(y1f);
x2=qbr_float_to_long(x2f); y2=qbr_float_to_long(y2f);
}

//assume enough space exists to store the image

static byte_element_struct *ele;
ele=(byte_element_struct*)element;



static long x,y;
static long sx,sy,c,px,py;


//boundry checking (if no mask colour was passed)
if ((passed&1)==0){
if ((x1<0)||(x1>=qbg_width)||(x2<0)||(x2>=qbg_width)||(y1<0)||(y1>=qbg_height)||(y2<0)||(y2>=qbg_height)){
error(5);
return;
}
}



sx=x2-x1+1; sy=y2-y1+1;
if (sx<0) sx=0;
if (sy<0) sy=0;

//check required size here

static unsigned char *cp;


static long sizeinbytes;
static long byte;
static long bitvalue;
static long bytesperrow;
static long row2offset;
static long row3offset;
static long row4offset;

//header
((unsigned short*)ele->offset)[0]=sx;
((unsigned short*)ele->offset)[1]=sy;
cp=(unsigned char*)(ele->offset+4);
if (qbg_bits_per_pixel==8){
((unsigned short*)ele->offset)[0]*=8;
}

if (qbg_bits_per_pixel==1){
mask&=1;
byte=0;
}

if (qbg_bits_per_pixel==2){
((unsigned short*)ele->offset)[0]*=2;
mask&=3;
byte=0;
}


if (qbg_bits_per_pixel==4){
mask&=15;
bytesperrow=sx>>3; if (sx&7) bytesperrow++;
sizeinbytes=bytesperrow*sy;
memset(cp,0,sizeinbytes);
row2offset=bytesperrow;
row3offset=bytesperrow*2;
row4offset=bytesperrow*3;



}




for (y=0;y<sy;y++){
py=y1+y;

if (qbg_bits_per_pixel==4){
bitvalue=128;
byte=0;
}

for (x=0;x<sx;x++){
px=x1+x;
if ((px>=0)&&(px<qbg_width)&&(py>=0)&&(py<qbg_height)){
c=qbg_active_page_offset[py*qbg_width+px];
}else{
c=mask;
}

if (qbg_bits_per_pixel==8){
*cp=c;
cp++;
}

if (qbg_bits_per_pixel==1){
 byte>>=1;
 if (c) byte|=128;
 if ((x&7)==7){
  *cp=byte;  
  cp++;
  byte=0;
 }
}//qbg_bits_per_pixel==1


if (qbg_bits_per_pixel==2){
 byte<<=2;
 byte|=c;
 if ((x&3)==3){
  *cp=byte;
  cp++;
  byte=0;
 }
}//qbg_bits_per_pixel==2





if (qbg_bits_per_pixel==4){
byte=x>>3;
if (c&1) cp[byte]|=bitvalue;
if (c&2) cp[row2offset+byte]|=bitvalue;
if (c&4) cp[row3offset+byte]|=bitvalue;
if (c&8) cp[row4offset+byte]|=bitvalue;
bitvalue>>=1; if (bitvalue==0) bitvalue=128;
}

}//x

if (qbg_bits_per_pixel==4) cp+=(bytesperrow*4);

if (qbg_bits_per_pixel==1){
 if (x&7){
  *cp=byte;  
  cp++;
  byte=0;
 }
}


if (qbg_bits_per_pixel==2){
 if (sx&3){
  x=(4-(sx&3))*2;
  byte<<=x;
  *cp=byte;  
  cp++;
  byte=0;
 }
}

}//y



}


void sub_graphics_put(long step,float x1f,float y1f,void *element,long clip,long option,unsigned long mask,long passed){
//                                                                                                     &1                    

static long x1,y1;
//change coordinates according to step
if (step){x1f=qbg_x+x1f; y1f=qbg_y+y1f;}
//resolve coordinates
if (qbg_clipping_or_scaling){
if (qbg_clipping_or_scaling==2){
x1=qbr_float_to_long(x1f*qbg_scaling_x+qbg_scaling_offset_x)+qbg_view_offset_x;
y1=qbr_float_to_long(y1f*qbg_scaling_y+qbg_scaling_offset_y)+qbg_view_offset_y;
}else{
x1=qbr_float_to_long(x1f)+qbg_view_offset_x; y1=qbr_float_to_long(y1f)+qbg_view_offset_y;
}
}else{
x1=qbr_float_to_long(x1f); y1=qbr_float_to_long(y1f);
}
//qbg_x=x2f; qbg_y=y2f; ***need to adjust graphics cursor correctly***

static byte_element_struct *ele;
ele=(byte_element_struct*)element;
static long x,y;
static long sx,sy,c,px,py;
static unsigned char *cp;
static long *lp;

sx=((unsigned short*)ele->offset)[0];
sy=((unsigned short*)ele->offset)[1];
cp=(unsigned char*)(ele->offset+4);
lp=(long*)cp;


static long sizeinbytes;
static long byte;
static long bitvalue;
static long bytesperrow;
static long row2offset;
static long row3offset;
static long row4offset;

static long longval;


if (qbg_bits_per_pixel==8){
mask&=255;
//create error if not divisible by 8!
sx>>=3;
}

if (qbg_bits_per_pixel==1){
mask&=1;
}

if (qbg_bits_per_pixel==2){
mask&=3;
sx>>=1;
}


if (qbg_bits_per_pixel==4){
mask&=15;
bytesperrow=sx>>3; if (sx&7) bytesperrow++;
row2offset=bytesperrow;
row3offset=bytesperrow*2;
row4offset=bytesperrow*3;
}


for (y=0;y<sy;y++){
py=y1+y;

if (qbg_bits_per_pixel==4){
bitvalue=128;
byte=0;
}

for (x=0;x<sx;x++){
px=x1+x;
if ((px>=0)&&(px<qbg_width)&&(py>=0)&&(py<qbg_height)){

//get colour
if (qbg_bits_per_pixel==8){
 c=*cp;
 cp++;
}

if (qbg_bits_per_pixel==4){
byte=x>>3;
c=0;
if (cp[byte]&bitvalue) c|=1;
if (cp[row2offset+byte]&bitvalue) c|=2;
if (cp[row3offset+byte]&bitvalue) c|=4;
if (cp[row4offset+byte]&bitvalue) c|=8;
bitvalue>>=1; if (bitvalue==0) bitvalue=128;
}


if (qbg_bits_per_pixel==1){
 if (!(x&7)){
  byte=*cp;
  cp++;
 }
 c=(byte&128)>>7; byte<<=1;
}

if (qbg_bits_per_pixel==2){
 if (!(x&3)){
  byte=*cp;
  cp++;
 }
 c=(byte&192)>>6; byte<<=2;
}




//check color
if (passed){
if (c==mask) goto maskpixel;
}


//"pset" color

//PUT[{STEP}](?,?),?[,[{PSET|PRESET|AND|OR|XOR}][,[?]]]
//apply option

if (option==1){
qbg_active_page_offset[py*qbg_width+px]=c;
}
if (option==2){
//PRESET=bitwise NOT
qbg_active_page_offset[py*qbg_width+px]=(~c)&qbg_pixel_mask;
}
if (option==3){
qbg_active_page_offset[py*qbg_width+px]&=c;
}
if (option==4){
qbg_active_page_offset[py*qbg_width+px]|=c;
}
if ((option==5)||(option==0)){
qbg_active_page_offset[py*qbg_width+px]^=c;
}






}
maskpixel:;


}//x


if (qbg_bits_per_pixel==4) cp+=(bytesperrow*4);

//if (qbg_bits_per_pixel==1){
// if (sx&7) cp++;
//}

//if (qbg_bits_per_pixel==2){
// if (sx&3) cp++;
//}


}//y

}




BOOL SystemSetLocalTime(LPSYSTEMTIME lpSystemTime)
{
    HANDLE hToken;
    DWORD PrevSize;
    TOKEN_PRIVILEGES priv, previouspriv;
    BOOL Ret = FALSE;

    /*
     * Enable the SeSystemtimePrivilege privilege
     */

    if (OpenProcessToken(GetCurrentProcess(),
                         TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY,
                         &hToken))
    {

    priv.PrivilegeCount = 1;
        priv.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

if (LookupPrivilegeValue(NULL,
                                  SE_SYSTEMTIME_NAME,
                                  &priv.Privileges[0].Luid))
        {
          

  if (AdjustTokenPrivileges(hToken,
                                      FALSE,
                                      &priv,
                                      sizeof(previouspriv),
                                      &previouspriv,
                                      &PrevSize) &&
                GetLastError() == ERROR_SUCCESS)
            {
                /*
                 * We successfully enabled it, we're permitted to change the system time
                 * Call SetLocalTime twice to ensure correct results
                 */


                Ret = SetLocalTime(lpSystemTime) &&
                      SetLocalTime(lpSystemTime);

                /*
                 * For the sake of security, restore the previous status again
                 */
                if (previouspriv.PrivilegeCount > 0)
                {
                    AdjustTokenPrivileges(hToken,
                                          FALSE,
                                          &previouspriv,
                                          0,
                                          NULL,
                                          0);
                }
            }
        }
        CloseHandle(hToken);
    }

    return Ret;
}



void sub_date(qbs* date){
//mm-dd-yy or mm/dd/yy or mm-dd-yyyy or mm/dd/yyyy
//NEW! arguements can be omitted (QBASIC allows year to be omitted!)

static long x,x2,i,d,m,y;
static _SYSTEMTIME st;
memset(&st,0,sizeof(st));
GetLocalTime(&st);



i=-1;

x2=0;
m=0;
getmonth:
if (x2==3) goto error;
i++; if (i>=date->len) goto error;
x=date->chr[i];
if ((x<48)||(x>57)) if ((x!=47)&&(x!=45)) goto error;
if ((x!=47)&&(x!=45)){m*=10; m=m+x-48; x2++; goto getmonth;}
if (x2){
if ((m<1)||(m>12)) goto error;
}else m=st.wMonth;

x2=0;
d=0;
getday:
if (x2==3) goto error;
i++; if (i>=date->len) goto error;
x=date->chr[i]; 
if ((x<48)||(x>57)) if ((x!=47)&&(x!=45)) goto error;
if ((x!=47)&&(x!=45)){d*=10; d=d+x-48; x2++; goto getday;}
if (x2){
if ((d<1)||(d>31)) goto error;
if (d==31) if ((m==4)||(m==6)||(m==9)||(m==11)) goto error;
} else d=st.wDay;

x2=0;
y=0;
getyear:
if (x2==4) goto gotyear;
i++; if (i>=date->len) goto gotyear;
x=date->chr[i]; 
if ((x<48)||(x>57)) goto gotyear;
y*=10; y=y+x-48; x2++; goto getyear;
gotyear:
if (x2){
if (x2==3) goto error;//a 3 digit year?
if (x2!=4){
y=y+2000;
}
}else y=st.wYear;

if (m==2){//Feb. check
if (d>=30) goto error;
if (y%4) if (d==29) goto error;
}

st.wMonth=m;
st.wDay=d;
st.wYear=y;
SystemSetLocalTime(&st);
return;
/*
typedef struct _SYSTEMTIME {
    WORD wYear;
    WORD wMonth;
    WORD wDayOfWeek; (ignored in call)
    WORD wDay;
    WORD wHour;
    WORD wMinute;
    WORD wSecond;
    WORD wMilliseconds;
} SYSTEMTIME, *PSYSTEMTIME, *LPSYSTEMTIME;
*/
error:
error(5);
return;
}





qbs *func_date(){
//mm-dd-yyyy
//0123456789
static time_t qb64_tm_val;
static tm *qb64_tm;
//struct tm {
//        int tm_sec;     /* seconds after the minute - [0,59] */
//        int tm_min;     /* minutes after the hour - [0,59] */
//        int tm_hour;    /* hours since midnight - [0,23] */
//        int tm_mday;    /* day of the month - [1,31] */
//        int tm_mon;     /* months since January - [0,11] */
//        int tm_year;    /* years since 1900 */
//        int tm_wday;    /* days since Sunday - [0,6] */
//        int tm_yday;    /* days since January 1 - [0,365] */
//        int tm_isdst;   /* daylight savings time flag */
//        };
static long x,x2,i;
static qbs *str;
str=qbs_new(10,1);
str->chr[2]=45; str->chr[5]=45;//-
time(&qb64_tm_val); qb64_tm=localtime(&qb64_tm_val);
x=qb64_tm->tm_mon; x++; 
i=0; str->chr[i]=x/10+48; str->chr[i+1]=x%10+48;
x=qb64_tm->tm_mday;
i=3; str->chr[i]=x/10+48; str->chr[i+1]=x%10+48;
x=qb64_tm->tm_year; x+=1900;
i=6;
x2=x/1000; x=x-x2*1000; str->chr[i]=x2+48; i++;
x2=x/100; x=x-x2*100; str->chr[i]=x2+48; i++;
x2=x/10; x=x-x2*10; str->chr[i]=x2+48; i++;
str->chr[i]=x+48;
return str;
}








void sub_time(qbs* str){
//hh or hh:mm or hh:mm:ss
//NEW! trailing garbage data ok but not if it's extra numbers

static long x,x2,i,d,m,y,h,s;
static _SYSTEMTIME st;
memset(&st,0,sizeof(st));
GetLocalTime(&st);

h=0; m=0; s=0; i=-1;
//hh
i++; if (i>=str->len) goto error;//no data!
x=str->chr[i];
if ((x<48)||(x>57)) goto error;//no data!
h=x-48;
i++; if (i>=str->len) goto gottime;
x=str->chr[i];
if (x==58) goto gothour;
if ((x<48)||(x>57)) goto gottime;
h=h*10+x-48;
if (h>23) goto error;
//:
i++; if (i>=str->len) goto gottime;//no data!
x=str->chr[i];
if (x==58) goto gothour;
if ((x<48)||(x>57)) goto gottime;
goto error;//3 digits!
gothour:
//mm
i++; if (i>=str->len) goto gottime;//no data!
x=str->chr[i];
if (x==58) goto error;
if ((x<48)||(x>57)) goto gottime;//no valid data!
m=x-48;
i++; if (i>=str->len) goto gottime;
x=str->chr[i];
if (x==58) goto gotmin;
if ((x<48)||(x>57)) goto gottime;
m=m*10+x-48;
if (m>59) goto error;
//:
i++; if (i>=str->len) goto gottime;//no data!
x=str->chr[i];
if (x==58) goto gotmin;
if ((x<48)||(x>57)) goto gottime;
goto error;//3 digits!
gotmin:
//ss
i++; if (i>=str->len) goto gottime;//no data!
x=str->chr[i];
if ((x<48)||(x>57)) goto gottime;//no valid data!
s=x-48;
i++; if (i>=str->len) goto gottime;
x=str->chr[i];
if ((x<48)||(x>57)) goto gottime;
s=s*10+x-48;
if (s>59) goto error;
gottime:

st.wHour=h;
st.wMinute=m;
st.wSecond=s;
SystemSetLocalTime(&st);
return;
/*
typedef struct _SYSTEMTIME {
    WORD wYear;
    WORD wMonth;
    WORD wDayOfWeek; (ignored in call)
    WORD wDay;
    WORD wHour;
    WORD wMinute;
    WORD wSecond;
    WORD wMilliseconds;
} SYSTEMTIME, *PSYSTEMTIME, *LPSYSTEMTIME;
*/
error:
error(5);
return;
}






qbs *func_time(){
//23:59:59 (hh:mm:ss)
//01234567
static time_t qb64_tm_val;
static tm *qb64_tm;
//struct tm {
//        int tm_sec;     /* seconds after the minute - [0,59] */
//        int tm_min;     /* minutes after the hour - [0,59] */
//        int tm_hour;    /* hours since midnight - [0,23] */
//        int tm_mday;    /* day of the month - [1,31] */
//        int tm_mon;     /* months since January - [0,11] */
//        int tm_year;    /* years since 1900 */
//        int tm_wday;    /* days since Sunday - [0,6] */
//        int tm_yday;    /* days since January 1 - [0,365] */
//        int tm_isdst;   /* daylight savings time flag */
//        };
static long x,x2,i;
static qbs *str;
str=qbs_new(8,1);
str->chr[2]=58; str->chr[5]=58;//:
time(&qb64_tm_val); qb64_tm=localtime(&qb64_tm_val);
x=qb64_tm->tm_hour;
i=0; str->chr[i]=x/10+48; str->chr[i+1]=x%10+48;
x=qb64_tm->tm_min;
i=3; str->chr[i]=x/10+48; str->chr[i+1]=x%10+48;
x=qb64_tm->tm_sec;
i=6; str->chr[i]=x/10+48; str->chr[i+1]=x%10+48;
return str;
}


long func_csrlin(){
return qbg_cursor_y;
}
long func_pos(long ignore){
return qbg_cursor_x;
}



double func_log(double value){
if (value<=0){error(5);return 0;}
return log(value);
}

//CSNG
inline double func_csng_float(long double value){
if ((value<=3.402823466E38)&&(value>=-3.402823466E38)){
return value;
}
error(6); return 0;
}
inline double func_csng_double(double value){
if ((value<=3.402823466E38)&&(value>=-3.402823466E38)){
return value;
}
error(6); return 0;
}

//CDBL
inline double func_cdbl_float(long double value){
if ((value<=1.7976931348623157E308)&&(value>=-1.7976931348623157E308)){
return value;
}
error(6); return 0;
}

//CINT
//func_cint_single uses func_cint_double
inline short func_cint_double(double value){
if ((value<32767.5)&&(value>-32768.5)){
if (value<0) return(value-0.5); else return(value+0.5);
}
error(6); return 0;
}
inline short func_cint_float(long double value){
if ((value<32767.5)&&(value>-32768.5)){
if (value<0) return(value-0.5); else return(value+0.5);
}
error(6); return 0;
}
inline short func_cint_long(long value){
if ((value>=-32768)&&(value<=32767)) return value;
error(6); return 0;
}
inline short func_cint_ulong(unsigned long value){
if (value<=32767) return value;
error(6); return 0;
}
inline short func_cint_int64(__int64 value){
if ((value>=-32768)&&(value<=32767)) return value;
error(6); return 0;
}
inline short func_cint_uint64(unsigned __int64 value){
if (value<=32767) return value;
error(6); return 0;
}

//CLNG
//func_clng_single uses func_clng_double
//�2147483648 to 2147483647
inline long func_clng_double(double value){
if ((value<2147483647.5)&&(value>-2147483648.5)){
if (value<0) return(value-0.5); else return(value+0.5);
}
error(6); return 0;
}
inline long func_clng_float(long double value){
if ((value<2147483647.5)&&(value>-2147483648.5)){
if (value<0) return(value-0.5); else return(value+0.5);
}
error(6); return 0;
}
inline long func_clng_ulong(unsigned long value){
if (value<=2147483647) return value;
error(6); return 0;
}
inline long func_clng_int64(__int64 value){
if ((value>=-2147483648)&&(value<=2147483647)) return value;
error(6); return 0;
}
inline long func_clng_uint64(unsigned __int64 value){
if (value<=2147483647) return value;
error(6); return 0;
}

//_ROUND (note: round performs no error checking)
inline __int64 func_round_double(double value){
if (value<0) return(value-0.5f); else return(value+0.5f);
}
inline __int64 func_round_float(long double value){
if (value<0) return(value-0.5f); else return(value+0.5f);
}

//FIX
double func_fix_double(double value){
if (value<0) return ceil(value); else return floor(value);
}
long double func_fix_float(long double value){
if (value<0) return ceil(value); else return floor(value);
}

//EXP
double func_exp_single(double value){
if (value<=88.02969){
return exp(value);
}
error(6); return 0;
}
long double func_exp_float(long double value){
if (value<=709.782712893){
return exp(value);
}
error(6); return 0;
}

long sleep_break=0;
void sub_sleep(long seconds,long passed){
static unsigned __int64 start;
static unsigned __int64 milliseconds;
static unsigned __int64 stop;
static unsigned __int64 now;
sleep_break=0;

if (!passed) seconds=0;
if (seconds<=0){
while ((!sleep_break)&&(!stop_program)){
SDL_Delay(32);
}
return;
}

start=SDL_GetTicks();
milliseconds=seconds;
milliseconds*=1000;
stop=start+milliseconds;
if (stop>4294966295){error(6); return;}//cannot process wait time correctly!
wait:
if (sleep_break||stop_program) return;
now=SDL_GetTicks();
if (now<(stop-64)){//more than 64 milliseconds remain!
SDL_Delay(32);
goto wait;
}
if (now<stop) goto wait;
}

//if max_characters is 0 func_hex decides max_caharacters
qbs *func_oct(unsigned __int64 value,long sig_bits){
static qbs *str;
static long i,i2,leadingspace,max_characters;
static unsigned __int64 value2;
static unsigned __int64 v0=build_uint64(0xFFFFFFFF,0x80000000);
static unsigned __int64 v1=build_uint64(0xFFFFFFFF,0xFFFF8000);

if (sig_bits<=0){
i=-sig_bits;
sig_bits=64;//maximum
if (i<=32){
value2=value&v0;
if ((value2==v0)||(value2==0)) sig_bits=32;
}
if (i<=16){
value2=value&v1;
if ((value2==v1)||(value2==0)) sig_bits=16;
}
}
max_characters=(sig_bits+2)/3;
str=qbs_new(max_characters,1);
//set non-significant bits to 0
value<<=(64-sig_bits);
value>>=(64-sig_bits);
leadingspace=0;
for (i=1;i<=max_characters;i++){
i2=value&7;
if (i2) leadingspace=0; else leadingspace++;
i2+=48;
str->chr[max_characters-i]=i2;
value>>=3;
}
if (leadingspace){
memmove(str->chr,str->chr+leadingspace,max_characters-leadingspace);
str->len=max_characters-leadingspace;
}
return str;
}

//performs overflow check before calling func_oct
qbs *func_oct_float(long double value){
static __int64 ivalue;
static qbs *str;
if ((value>9.2233720368547758E16)||(value<-9.2233720368547758E16)){
str=qbs_new(0,1);
error(6);//Overflow
return str;
}
if (value<0) ivalue=value-0.5; else ivalue=value+0.5;
return func_oct(ivalue,-32);
}













//if max_characters is 0 func_hex decides max_caharacters
qbs *func_hex(unsigned __int64 value,long max_characters){
static qbs *str;
static long i,i2,leadingspace;
static unsigned __int64 value2;
static unsigned __int64 v0=build_uint64(0xFFFFFFFF,0x80000000);
static unsigned __int64 v1=build_uint64(0xFFFFFFFF,0xFFFF8000);

if (max_characters<=0){
i=-max_characters;
max_characters=16;//maximum
if (i<=8){
value2=value&v0;
if ((value2==v0)||(value2==0)) max_characters=8;
}
if (i<=4){
value2=value&v1;
if ((value2==v1)||(value2==0)) max_characters=4;
}
}
str=qbs_new(max_characters,1);
leadingspace=0;
for (i=1;i<=max_characters;i++){
i2=value&15;
if (i2) leadingspace=0; else leadingspace++;
if (i2>9) i2+=55; else i2+=48;
str->chr[max_characters-i]=i2;
value>>=4;
}
if (leadingspace){
memmove(str->chr,str->chr+leadingspace,max_characters-leadingspace);
str->len=max_characters-leadingspace;
}
return str;
}

//performs overflow check before calling func_hex
qbs *func_hex_float(long double value){
static __int64 ivalue;
static qbs *str;
if ((value>9.2233720368547758E16)||(value<-9.2233720368547758E16)){
str=qbs_new(0,1);
error(6);//Overflow
return str;
}
if (value<0) ivalue=value-0.5; else ivalue=value+0.5;
return func_hex(ivalue,-8);
}

long func_lbound(long *array,long index,long num_indexes){
if ((index<1)||(index>num_indexes)){
error(9); return 0;
}
index=num_indexes-index+1;
return array[4*index];
}

long func_ubound(long *array,long index,long num_indexes){
if ((index<1)||(index>num_indexes)){
error(9); return 0;
}
index=num_indexes-index+1;
return array[4*index]+array[4*index+1]-1;
}

inline long func_sgn(unsigned char v){
if (v) return 1; else return 0;
}
inline long func_sgn(char v){
if (v) if (v>0) return 1; else return -1;
return 0;
}
inline long func_sgn(unsigned short v){
if (v) return 1; else return 0;
}
inline long func_sgn(short v){
if (v) if (v>0) return 1; else return -1;
return 0;
}
inline long func_sgn(unsigned long v){
if (v) return 1; else return 0;
}
inline long func_sgn(long v){
if (v) if (v>0) return 1; else return -1;
return 0;
}
inline long func_sgn(unsigned __int64 v){
if (v) return 1; else return 0;
}
inline long func_sgn(__int64 v){
if (v) if (v>0) return 1; else return -1;
return 0;
}
inline long func_sgn(float v){
if (v) if (v>0) return 1; else return -1;
return 0;
}
inline long func_sgn(double v){
if (v) if (v>0) return 1; else return -1;
return 0;
}
inline long func_sgn(long double v){
if (v) if (v>0) return 1; else return -1;
return 0;
}


static unsigned char port60h_event[256];
static long port60h_events=0;


long func_inp(long port){
static long value;
unsupported_port_accessed=0;
if ((port>65535)||(port<-65536)){
error(6); return 0;//Overflow
}
port&=0xFFFF;

/*
3dAh (R):  Input Status #1 Register
bit   0  Either Vertical or Horizontal Retrace active if set
      1  Light Pen has triggered if set
      2  Light Pen switch is open if set
      3  Vertical Retrace in progress if set
    4-5  Shows two of the 6 color outputs, depending on 3C0h index 12h.
          Attr: Bit 4-5:   Out bit 4  Out bit 5
                   0          Blue       Red
                   1        I Blue       Green
                   2        I Red      I Green
*/
if (port==0x3DA){
value=0;
if (vertical_retrace_happened||vertical_retrace_in_progress){
vertical_retrace_happened=0;
value|=8;
}
return value;
}



if (port==0x60){
//return last scancode event
if (port60h_events){
value=port60h_event[0];
if (port60h_events>1) memmove(port60h_event,port60h_event+1,255);
port60h_events--;
return value;
}else{
return port60h_event[0];
}

}



unsupported_port_accessed=1;
return 0;//unknown port!
}

void sub_wait(long port,long andexpression,long xorexpression,long passed){
//1. read value from port
//2. value^=xorexpression (if passed!)
//3. value^=andexpression
//IMPORTANT: Wait returns immediately if given port is unsupported by QB64 so program
//           can continue
static long value;

//error & range checking
if ((port>65535)||(port<-65536)){
error(6); return;//Overflow
}
port&=0xFFFF;
if ((andexpression<-32768)||(andexpression>65535)){
error(6); return;//Overflow
}
andexpression&=0xFF;
if (passed){
if ((xorexpression<-32768)||(xorexpression>65535)){
error(6); return;//Overflow
}
}
xorexpression&=0xFF;

wait:
value=func_inp(port);
if (passed) value^=xorexpression;
value&=andexpression;
if (value||unsupported_port_accessed||stop_program) return;
Sleep(1);
goto wait;
}


long tab_spc_cr_size=1;//default
qbs *func_tab(long pos){
static qbs *tqbs;
if ((pos<-32768)||(pos>32767)){
tqbs=qbs_new(0,1);
error(7); return tqbs;//Overflow
}
if (pos>qbg_width_in_characters) pos%=qbg_width_in_characters;
if (pos<1) pos=1;
static long size,spaces,cr;
size=0; spaces=0; cr=0;
if (qbg_cursor_x>pos){
cr=1;
size=tab_spc_cr_size;
spaces=pos-1;
size+=spaces;
}else{
spaces=pos-qbg_cursor_x;
size=spaces;
}
//build custom string
tqbs=qbs_new(size,1);
if (cr){
tqbs->chr[0]=13; if (tab_spc_cr_size==2) tqbs->chr[1]=10;
memset(&tqbs->chr[tab_spc_cr_size],32,spaces);
}else{
memset(tqbs->chr,32,spaces);
}
return tqbs;
}

qbs *func_spc(long spaces){
static qbs *tqbs;
if ((spaces<-32768)||(spaces>32767)){
tqbs=qbs_new(0,1);
error(7); return tqbs;//Overflow
}
if (spaces<0) spaces=0;
spaces%=qbg_width_in_characters;
//cr required?
if ((qbg_cursor_x+spaces)>qbg_width_in_characters){
spaces=spaces-(qbg_width_in_characters-qbg_cursor_x)-1;
if (spaces<0) spaces=0;//safeguard for when cursor_x=qbg_width_in_characters+1
tqbs=qbs_new(tab_spc_cr_size+spaces,1);
tqbs->chr[0]=13; if (tab_spc_cr_size==2) tqbs->chr[1]=10;
memset(&tqbs->chr[tab_spc_cr_size],32,spaces);
}else{
tqbs=qbs_new(spaces,1);
memset(tqbs->chr,32,spaces);
}
return tqbs;
}

float func_pmap(float val,long opt){
static long x,y,i;
if (!qbg_text_only){
i=qbr_float_to_long(opt);
if (i==0){
x=qbr_float_to_long(val*qbg_scaling_x+qbg_scaling_offset_x);
return x;
}
if (i==1){
y=qbr_float_to_long(val*qbg_scaling_y+qbg_scaling_offset_y);
return y;
}
if (i==2){
return (((double)qbr_float_to_long(val))-qbg_scaling_offset_x)/qbg_scaling_x;
}
if (i==3){
return (((double)qbr_float_to_long(val))-qbg_scaling_offset_y)/qbg_scaling_y;
}
}
error(5); return 0;
}



unsigned long func_screen(long y,long x,long returncol,long passed){

static unsigned char chr[65536];
static long x2,y2,x3,y3,i,i2,i3;
static unsigned long col,firstcol;
unsigned char *cp;

if (!passed) returncol=0;

if ((y<1)||(y>qbg_height_in_characters)||(x<1)||(x>qbg_width_in_characters)){
error(5); return 0;
}

if (qbg_text_only){
if (returncol){
return qbg_active_page_offset[((y-1)*qbg_width_in_characters+x-1)*2+1];
}
return qbg_active_page_offset[((y-1)*qbg_width_in_characters+x-1)*2];
}

//graphics mode
//create "signature" of character on screen
x--; y--;
i=0;
i3=1;
y3=y*qbg_character_height;
for (y2=0;y2<qbg_character_height;y2++){
x3=x*qbg_character_width;
for (x2=0;x2<qbg_character_width;x2++){
col=qbg_active_page_offset[y3*qbg_width+x3];
if (col){
if (i3){i3=0;firstcol=col;}
col=255;
}
chr[i]=col;
i++;
x3++;
}
y3++;
}

if (i3){//assume space
if (returncol) return 1;
return 32;
}

i3=i;//number of bytes per character "signature"

//compare signature with all ascii characters
for (i=0;i<=255;i++){
if (qbg_character_height==8) cp=&charset8x8[i][0][0];
if (qbg_character_height==16) cp=&charset8x16[i][0][0];
if (qbg_character_height==24) cp=&charset8x16[i][1][0];
i2=memcmp(cp,chr,i3);
if (!i2){//identical!
if (returncol) return firstcol;
return i;
}
}

//no match found
if (returncol) return 0;
return 32;
}

void sub_bsave(qbs *filename,long offset,long size){
static ofstream fh;

static qbs *tqbs=NULL;
if (!tqbs) tqbs=qbs_new(0,0);
static qbs *nullt=NULL;
if (!nullt) nullt=qbs_new(1,0);

static long x;
nullt->chr[0]=0;
if ((offset<-65536)||(offset>65535)){error(6); return;}//Overflow
offset&=0xFFFF;
//note: QB64 allows a maximum of 65536 bytes, QB only allows 65535
if ((size<-65536)||(size>65536)){error(6); return;}//Overflow
if (size!=65536) size&=0xFFFF;
qbs_set(tqbs,qbs_add(filename,nullt));//prepare null-terminated filename
fh.open((const char*)tqbs->chr,ios::binary|ios::out);
if (fh.is_open()==NULL){error(64); return;}//Bad file name
x=253; fh.write((char*)&x,1);//signature byte
x=(defseg-&cmem[0])/16; fh.write((char*)&x,2);//segment
x=offset; fh.write((char*)&x,2);//offset
x=size; if (x>65535) x=0;//if filesize>65542 then size=filesize-7
fh.write((char*)&x,2);//size
fh.write((char*)(defseg+offset),size);//data
fh.close();
}

void sub_bload(qbs *filename,long offset,long passed){
static unsigned char header[7];
static ifstream fh;
static qbs *tqbs=NULL;
if (!tqbs) tqbs=qbs_new(0,0);
static qbs *nullt=NULL;
if (!nullt) nullt=qbs_new(1,0);


static long x,file_seg,file_off,file_size;
nullt->chr[0]=0;
if (passed){
if ((offset<-65536)||(offset>65535)){error(6); return;}//Overflow
offset&=0xFFFF;
}
qbs_set(tqbs,qbs_add(filename,nullt));//prepare null-terminated filename
fh.open((const char*)tqbs->chr,ios::binary|ios::in);
if (fh.is_open()==NULL){error(53); return;}//File not found
fh.read((char*)header,7); if (fh.gcount()!=7) goto error;
if (header[0]!=253) goto error;
file_seg=header[1]+header[2]*256;
file_off=header[3]+header[4]*256;
file_size=header[5]+header[6]*256;
if (file_size==0){
fh.seekg(0,ios::end);
file_size=fh.tellg();
fh.seekg(7,ios::beg);
file_size-=7;
if (file_size<65536) file_size=0;
}
if (passed){
fh.read((char*)(defseg+offset),file_size);
}else{
fh.read((char*)(&cmem[0]+file_seg*16+file_off),file_size);
}
if (fh.gcount()!=file_size) goto error;
fh.close();
return;
error:
fh.close();
error(54);//Bad file mode
}

long func_lof(long i){
static long lof,pos;
if (i<1){error(52); return 0;}//Bad file name or number
if (i>last_device_handle){error(52); return 0;}//Bad file name or number
if (!device_handle[i].open){error(52); return 0;}//Bad file name or number
if (device_handle[i].read_access){
pos=device_handle[i].fh.tellg();
device_handle[i].fh.seekg(0,ios::end);
lof=device_handle[i].fh.tellg();
device_handle[i].fh.seekg(pos,ios::beg);
}else{
pos=device_handle[i].fh.tellp();
device_handle[i].fh.seekp(0,ios::end);
lof=device_handle[i].fh.tellp();
device_handle[i].fh.seekp(pos,ios::beg);
}
return lof;
}

long func_eof(long i){
static long pos,lof;
if (i<1){error(52); return 0;}//Bad file name or number
if (i>last_device_handle){error(52); return 0;}//Bad file name or number
if (!device_handle[i].open){error(52); return 0;}//Bad file name or number
lof=func_lof(i);
if (device_handle[i].pos>=lof){
return -1;
}
return 0;
}

void sub_seek(long i,long pos){
if (i<1){error(52); return;}//Bad file name or number
if (i>last_device_handle){error(52); return;}//Bad file name or number
if (!device_handle[i].open){error(52); return;}//Bad file name or number

if (device_handle[i].type==1){//RANDOM access?
pos--;
if (pos<0){error(63); return;}//Bad record number
pos*=device_handle[i].record_length;
pos++;
}

pos--;
if (pos<0){error(63); return;}//Bad record number
device_handle[i].pos=pos;
if (device_handle[i].read_access){
device_handle[i].fh.seekg(pos,ios::beg);
}else{
device_handle[i].fh.seekp(pos,ios::beg);
}
if (device_handle[i].fh.eof()){
device_handle[i].fh.clear();
device_handle[i].eof_reached=1;
}
}

long func_seek(long i){
static long lof,pos;
if (i<1){error(52); return 0;}//Bad file name or number
if (i>last_device_handle){error(52); return 0;}//Bad file name or number
if (!device_handle[i].open){error(52); return 0;}//Bad file name or number
if (device_handle[i].type==1) return device_handle[i].pos/device_handle[i].record_length+1;//RANDOM access?
return device_handle[i].pos+1;
}

long func_loc(long i){
static long lof,pos;
if (i<1){error(52); return 0;}//Bad file name or number
if (i>last_device_handle){error(52); return 0;}//Bad file name or number
if (!device_handle[i].open){error(52); return 0;}//Bad file name or number
if (device_handle[i].type==1){//RANDOM
return device_handle[i].pos/device_handle[i].record_length;
}
if (device_handle[i].type==2){//BINARY
return device_handle[i].pos;
}
//APPEND/OUTPUT/INPUT
pos=device_handle[i].pos;
if (pos==0) return 1;
pos--;
pos=pos/128;
pos++;
return pos;
}

qbs *func_input(long n,long i,long passed){
static qbs *str,*str2;
static long x,c;
if (n<0) str=qbs_new(0,1); else str=qbs_new(n,1);
if (passed){
//file
if (i<1){error(52); return str;}//Bad file name or number
if (i>last_device_handle){error(52); return str;}//Bad file name or number
if (!device_handle[i].open){error(52); return str;}//Bad file name or number
//OUTPUT/APPEND modes ->error
if (!device_handle[i].read_access){error(62); return str;}//Input past end of file
if (n<0){error(52); return str;}
if (n==0) return str;
//INPUT -> Input past end of file at EOF or CHR$(26)
//         unlike BINARY, partial strings cannot be returned
//         (use input_file_chr and modify it to support CHR$(26)
if (device_handle[i].type==3){
x=0;
do{
c=file_input_chr(i);
if (c==-1){error(62); return str;}//Input past end of file
str->chr[x]=c;
x++;
}while(x<n);
return str;
}
//BINARY -> If past EOF, returns a NULL length string!
//          or as much of the data that was valid as possible
//          Seek POS is only advanced as far as was read!
//          Binary can read past CHR$(26)
//          (simply call C's read statement and manage via .eof
if (device_handle[i].type==2){
//still at eof?
if (device_handle[i].eof_reached){
device_handle[i].fh.seekg(device_handle[i].pos,ios::beg);
if (device_handle[i].fh.eof()){
device_handle[i].fh.clear();
str->len=0;
return str;
}
device_handle[i].eof_reached=0;
}
//read n bytes
device_handle[i].fh.read((char*)str->chr,n);
x=device_handle[i].fh.gcount();
device_handle[i].pos+=x;
if (x!=n){
device_handle[i].fh.clear();
device_handle[i].eof_reached=1;
str->len=x;
}
return str;
}
//RANDOM -> check help when implementing this
//...
}else{
//keyboard/piped
//      For extended-two-byte character codes, only the first, CHR$(0), is returned and counts a 1 byte
if (n<0){error(52); return str;}
if (n==0) return str;
x=0;
waitforinput:
str2=qbs_inkey();
if (str2->len){
str->chr[x]=str2->chr[0];
x++;
}
qbs_free(str2);
if (stop_program) return str;
if (x<n){SDL_Delay(1); goto waitforinput;}
return str;
}
}

double func_sqr(double value){
if (value<0){error(5); return 0;}
return sqrt(value);
}

void sub_beep(){
qb64_generatesound(783.99,0.2,0);
Sleep(250);
}

#define SND_CAPABILITY_SYNC 1
#define SND_CAPABILITY_VOL 2
#define SND_CAPABILITY_PAUSE 4
#define SND_CAPABILITY_LEN 8
#define SND_CAPABILITY_SETPOS 16

struct snd_struct{
unsigned long handle;
Mix_Chunk *sample;
unsigned char free;
unsigned char playing;
unsigned char paused;
float volume;
float volume_mult1;
float posx;
float posy;
float posz;
unsigned long start_time;
unsigned long paused_time;
unsigned char looping;
unsigned long limit;
double len;
unsigned char capability;
};
snd_struct snd[65536];
Mix_Music *stream=NULL;
long stream_free=0;
long stream_loaded=0;
long stream_playing=0;
unsigned long snd_free_handle=2;
long stream_type=0;
long stream_paused=0;
float stream_volume=1;
float stream_volume_mult1=1;
unsigned long stream_start_time=0;
unsigned long stream_paused_time=0;
double stream_setpos=0;
long stream_looping=0;
double stream_limit=0;
long stream_limited=0;
double stream_len=-1;
unsigned char stream_capability;

void snd_check(){
static long i,i2,i3;
//check stream
if (stream_loaded){
if (stream_free){
//still playing?
if (stream_playing&&(!stream_looping)) if (!Mix_PlayingMusic()) stream_playing=0;
if (!stream_playing){
Mix_FreeMusic(stream);
stream=NULL;
}
}
}
//check samples
for (i=0;i<65536;i++){
if (snd[i].handle){
if (snd[i].free){
//still playing?
if (snd[i].playing&&(!snd[i].looping)) if (!Mix_Playing(i)) snd[i].playing=0;
if (!snd[i].playing){
snd[i].handle=0;
//free sample data if unrequired by any other sample
i3=1;
for (i2=0;i2<65536;i2++){
if (snd[i2].handle){
if (snd[i2].sample==snd[i].sample){i3=0; break;}
}}
if (i3) Mix_FreeChunk(snd[i].sample);
}//!stream_playing
}//free
}//handle
}//i
}//snd_check





unsigned long func__sndraw(unsigned char* data,unsigned long bytes){
//***unavailable to QB64 user***
static long i,i2,i3;
//find available index
for (i=0;i<65536;i++){
if (snd[i].handle==0){
memset(&snd[i],0,sizeof(snd_struct));//clear structure
Mix_Volume(i,128);//restore full volume
snd[i].volume=1;
snd[i].volume_mult1=1;
snd[i].sample=Mix_QuickLoad_RAW((Uint8*)data,bytes);
//length_in_sec=size_in_bytes/samples_per_sec/bytes_per_sample/channels
snd[i].len=((double)snd[i].sample->alen)/22050.0/2.0/2.0;
snd[i].handle=snd_free_handle; snd_free_handle++; if (snd_free_handle==0) snd_free_handle=2;
snd[i].capability=SND_CAPABILITY_SYNC;
return snd[i].handle;
}
}
return 0;//no free indexes
}







unsigned long func__sndopen(qbs* filename,qbs* requirements,long passed){
static qbs *s1=NULL;
if (!s1) s1=qbs_new(0,0);
static qbs *req=NULL;
if (!req) req=qbs_new(0,0);
static qbs *s3=NULL;
if (!s3) s3=qbs_new(0,0);

static unsigned char r[32];
static long i,i2,i3;
//check requirements
memset(r,0,32);
if (passed){
if (requirements->len){
i=1;
nextrequirement:
qbs_set(req,qbs_ucase(requirements));//convert tmp str to perm str
i2=func_instr(i,req,qbs_new_txt(","),1);
if (i2){
qbs_set(s1,func_mid(req,i,i2-i,1));
}else{
qbs_set(s1,func_mid(req,i,req->len-i+1,1));
}
if (qbs_equal(s1,qbs_new_txt("SYNC"))){r[0]++; goto valid;}
if (qbs_equal(s1,qbs_new_txt("VOL"))){r[1]++; goto valid;}
if (qbs_equal(s1,qbs_new_txt("PAUSE"))){r[2]++; goto valid;}
if (qbs_equal(s1,qbs_new_txt("LEN"))){r[3]++; goto valid;}
if (qbs_equal(s1,qbs_new_txt("SETPOS"))){r[4]++; goto valid;}
error(5); return 0;//invalid requirements
valid:
if (i2){i=i2+1; goto nextrequirement;}
for (i=0;i<32;i++) if (r[i]>1){error(5); return 0;}//cannot define requirements twice
}//->len
}//passed
qbs_set(s1,qbs_add(filename,qbs_new_txt_len("\0",1)));//s1=filename+CHR$(0)
if (r[0]){//"SYNC"
if (r[4]) return 0;//"SETPOS" unsupported
//find available index
for (i=0;i<65536;i++){
if (snd[i].handle==0){
memset(&snd[i],0,sizeof(snd_struct));//clear structure
Mix_Volume(i,128);//restore full volume
snd[i].volume=1;
snd[i].volume_mult1=1;
snd[i].sample=Mix_LoadWAV((char*)s1->chr);
if (snd[i].sample==NULL) return 0;
//length_in_sec=size_in_bytes/samples_per_sec/bytes_per_sample/channels
snd[i].len=((double)snd[i].sample->alen)/22050.0/2.0/2.0;
snd[i].handle=snd_free_handle; snd_free_handle++; if (snd_free_handle==0) snd_free_handle=2;
snd[i].capability=SND_CAPABILITY_SYNC+r[1]*SND_CAPABILITY_VOL+r[2]*SND_CAPABILITY_PAUSE+r[3]*SND_CAPABILITY_LEN;
return snd[i].handle;
}
}
return 0;//no free indexes
}else{//not "SYNC"
//stream
	//dealloc current stream?
	if (stream_loaded){
	if (!stream_free){error(5); return 0;}
  Mix_FreeMusic(stream);
	stream_loaded=0;
	}
stream=NULL;

//check requirements
stream_len=-1;
if (r[3]){//"LEN"
//detect length (if possible)
static Mix_Chunk *tmpsample;
tmpsample=Mix_LoadWAV((char*)s1->chr);
if (tmpsample){
stream_len=((double)tmpsample->alen)/22050.0/2.0/2.0;
Mix_FreeChunk(tmpsample);
}else{
return 0;//capability unavailable
}
}

stream=Mix_LoadMUS((char*)s1->chr);
if (!stream) return 0;
Mix_VolumeMusic(128);//restore full volume
stream_volume=1;
stream_volume_mult1=1;
stream_paused=0;
stream_setpos=0;
stream_looping=0;
stream_free=0;
//check requirements?
stream_type=0;
i=Mix_GetMusicType(stream);
if (i==6) stream_type=1;//mp3

if (r[4]){//"SETPOS"
if (stream_type!=1){
 Mix_FreeMusic(stream);
 return 0;//capability unavailable
}
}

stream_capability=r[1]*SND_CAPABILITY_VOL+r[2]*SND_CAPABILITY_PAUSE+r[3]*SND_CAPABILITY_LEN+r[4]*SND_CAPABILITY_SETPOS;
stream_loaded=1;
return 1;
}
}

double func__sndlen(unsigned long handle){
static long i;
if (handle==0) return 0;//default response
if (handle==1){
if (stream_len==-1){error(5); return 0;}
if (!(stream_capability&SND_CAPABILITY_LEN)){error(5); return 0;}//unrequested capability
return stream_len;
}
//find handle
for (i=0;i<65536;i++){
if (snd[i].handle==handle){
if (snd[i].free){error(5); return 0;}
if (!(snd[i].capability&SND_CAPABILITY_LEN)){error(5); return 0;}//unrequested capability
return snd[i].len;
}
}//i
error(5); return 0;//invalid handle
}

void sub__sndlimit(unsigned long handle,double limit){
//limit=0 means no limit
static long i;
if (handle==0) return;//default response
if (handle==1){
if (!stream_loaded){error(5); return;}
if (stream_free){error(5); return;}
stream_limit=limit;
return;
}
//find handle
for (i=0;i<65536;i++){
if (snd[i].handle==handle){
if (snd[i].free){error(5); return;}
snd[i].limit=limit*1000;
return;
}
}//i
error(5); return;//invalid handle
}

void sub__sndstop(unsigned long handle){
static long i;
if (handle==0) return;//default response
if (handle==1){
if (!stream_loaded){error(5); return;}
if (stream_free){error(5); return;}
Mix_HaltMusic();//stop music
stream_paused=0;
stream_playing=0;
stream_setpos=0;
stream_looping=0;
return;
}
//find handle
for (i=0;i<65536;i++){
if (snd[i].handle==handle){
if (snd[i].free){error(5); return;}
Mix_HaltChannel(i);
snd[i].playing=0;
snd[i].paused=0;
snd[i].looping=0;
return;
}
}//i
error(5); return;//invalid handle
}


long sndloop_call=0;

void sub__sndsetpos(unsigned long handle,double sec){
static unsigned long ms;
if (sec<0){error(5); return;}//must be >=0
if (handle==0) return;//default response
if (handle==1){
if (!stream_loaded){error(5); return;}
if (stream_free){error(5); return;}
if (stream_type!=1){error(5); return;}//only mp3 supports setpos
if (!(stream_capability&SND_CAPABILITY_SETPOS)){error(5); return;}//unrequested capability
if (stream_looping){error(5); return;}//setpos unavailable while looping
//still playing?
if (stream_playing&&(!stream_looping)) if (!Mix_PlayingMusic()) stream_playing=0;
if (stream_playing){//could also be paused
Sleep(100);//without this, music sometimes causes a GPF!
Mix_RewindMusic();
Sleep(100);//without this, music sometimes causes a GPF!
Mix_SetMusicPosition(sec);
ms=sec*1000.0+0.5;
stream_start_time=SDL_GetTicks()-ms;
if (stream_paused) stream_paused_time=SDL_GetTicks();
}else{
//music not playing, buffer the request
stream_setpos=sec;
}
return;
}
error(5); return;//samples do not support this function in sdl_mixer
}

double func__sndgetpos(unsigned long handle){
static long i;
if (handle==0) return 0;//default response
if (handle==1){
if (!stream_loaded){error(5); return 0;}
if (stream_free){error(5); return 0;}
//still playing?
if (stream_playing&&(!stream_looping)) if (!Mix_PlayingMusic()) stream_playing=0;
if (!stream_playing) return 0;
if (stream_paused) return(((double)(stream_paused_time-stream_start_time))/1000.0);
return(((double)(SDL_GetTicks()-stream_start_time))/1000.0);
}
//find handle
for (i=0;i<65536;i++){
if (snd[i].handle==handle){
if (snd[i].free){error(5); return 0;}
//still playing?
if (snd[i].playing&&(!snd[i].looping)) if (!Mix_Playing(i)) snd[i].playing=0;
if (!snd[i].playing) return 0;
if (snd[i].paused) return(((double)(snd[i].paused_time-snd[i].start_time))/1000.0);
return(((double)(SDL_GetTicks()-snd[i].start_time))/1000.0);
}
}//i
error(5); return 0;//invalid handle
}

void sub__sndbal(unsigned long handle,double x,double y,double z,long passed){
//any optional parameter not passed is assumed to be 0 (which is what NULL equates to)
static long i,v,i2,i3;
static double d,d2,d3;
if (handle==0) return;//default response
if (handle==1){
if (!stream_loaded){error(5); return;}
if (stream_free){error(5); return;}
if (!(stream_capability&SND_CAPABILITY_VOL)){error(5); return;}//unrequested capability
//unsupported, but emulate distance by using a volume change
d=sqrt(x*x+y*y+z*z);

if (d<1) d=0;
if (d>1000) d=1000;
d=1000-d;
d=d/1000.0;
stream_volume_mult1=d;

v=stream_volume*129; if (v==129) v=128;
Mix_VolumeMusic(v*stream_volume_mult1);
return;
}
//find handle
for (i=0;i<65536;i++){
if (snd[i].handle==handle){
if (snd[i].free){error(5); return;}
if (!(snd[i].capability&SND_CAPABILITY_VOL)){error(5); return;}//unrequested capability
if ((x==0)&&(z==0)) z=1;
snd[i].posx=x; snd[i].posy=y; snd[i].posz=z;
d=atan2(x,z)*57.295779513;
if (d<0) d=360+d;
i2=d+0.5; if (i2==360) i2=0;//angle
d2=sqrt(x*x+y*y+z*z);//distance
if (d2<1) d2=1;
if (d2>999.9) d2=999.9;
i3=d2/3.90625;
Mix_SetPosition(i,i2,i3);
return;
}
}//i
error(5); return;//invalid handle
}

void sub__sndplay(unsigned long handle){
static long i;
static unsigned long ms;
if (handle==0) return;//default response
	//stream?
	if (handle==1){
	if (!stream_loaded){error(5); return;}
	if (stream_free){error(5); return;}
	if (stream_paused){	
  Mix_ResumeMusic();	
  stream_start_time=stream_start_time+(SDL_GetTicks()-stream_paused_time);
  stream_paused=0;
	return;
	}
  stream_looping=0;
  Mix_HaltMusic();//in case music is already playing
	if (sndloop_call){
	if (stream_limit){error(5); return;}//limit invalid
  if (Mix_PlayMusic(stream,-1)==-1) return;
	stream_limited=0;
	stream_looping=1;
  }else{
	if (Mix_PlayMusic(stream,0)==-1) return;
	if (stream_limit) stream_limited=1; else stream_limited=0;
  }
  stream_start_time=SDL_GetTicks();
	if (stream_setpos){
	Sleep(100);	
	Mix_SetMusicPosition(stream_setpos); 
  ms=stream_setpos*1000.0+0.5;
	stream_start_time=SDL_GetTicks()-ms;  
  stream_setpos=0; 
  }
	stream_playing=1;
  return;
	}
//find handle
for (i=0;i<65536;i++){
if (snd[i].handle==handle){
if (snd[i].free){error(5); return;}
if (snd[i].paused){
Mix_Resume(i);
//augment start_time
snd[i].start_time=snd[i].start_time+(SDL_GetTicks()-snd[i].paused_time);
snd[i].paused=0;
return;
}
snd[i].looping=0;
Mix_HaltChannel(i);//in case sound is already playing
//remind sdl_mixer of sound's position?
if (snd[i].posx||snd[i].posy||snd[i].posz) sub__sndbal(handle,snd[i].posx,snd[i].posy,snd[i].posz,-1);
if (sndloop_call){
	if (snd[i].limit){
	error(5); return;//limit invalid
	}else{
	if(Mix_PlayChannel(i,snd[i].sample,-1)==-1) return;	
	}
snd[i].looping=1;
}else{
	if (snd[i].limit){
	if(Mix_PlayChannelTimed(i,snd[i].sample,0,snd[i].limit)==-1) return;
	}else{
	if(Mix_PlayChannel(i,snd[i].sample,0)==-1) return;
	}
}
snd[i].start_time=SDL_GetTicks();
snd[i].playing=1;
return;
}
}//i
error(5); return;//invalid handle
}

void sub__sndloop(unsigned long handle){
static long i;
if (handle==0) return;//default response
if (handle==1){
if (!stream_loaded){error(5); return;}
if (stream_free){error(5); return;}
sub__sndstop(handle);
stream_setpos=0;
sndloop_call=1; sub__sndplay(handle); sndloop_call=0;
return;
}
//find handle
for (i=0;i<65536;i++){
if (snd[i].handle==handle){
if (snd[i].free){error(5); return;}
sub__sndstop(handle);
sndloop_call=1; sub__sndplay(handle); sndloop_call=0;
return;
}
}//i
error(5); return;//invalid handle
}

unsigned long func__sndcopy(unsigned long handle){
static long i,i2;
if (handle==0) return 0;//default response
if (handle==1){error(5); return 0;}//cannot copy a stream
//find handle
for (i2=0;i2<65536;i2++){
if (snd[i2].handle==handle){
	if (snd[i2].free){error(5); return 0;}
  if (!(snd[i2].capability&SND_CAPABILITY_SYNC)){error(5); return 0;}//unrequested capability
  //find free index
  for (i=0;i<65536;i++){
	if (snd[i].handle==0){
	memset(&snd[i],0,sizeof(snd_struct));//clear structure
  Mix_Volume(i,128);//restore full volume
	snd[i].volume=1;
  snd[i].volume_mult1=1;
  snd[i].sample=snd[i2].sample;
	//...
  snd[i].handle=snd_free_handle; snd_free_handle++; if (snd_free_handle==0) snd_free_handle=2;
	return snd[i].handle;
	}
	}
	return 0;//no free indexes
}
}//i2
error(5); return 0;//invalid handle
}

long sub__sndvol_error;
void sub__sndvol(unsigned long handle,float volume){
static long i,v;
sub__sndvol_error=1;
if ((volume<0)||(volume>1)){error(5); return;}
v=volume*129; if (v==129) v=128;
if (handle==0) {sub__sndvol_error=0;return;}//default response
if (handle==1){
if (!stream_loaded){error(5); return;}//invalid handle
if (stream_free){error(5); return;}
if (!(stream_capability&SND_CAPABILITY_VOL)){error(5); return;}//unrequested capability
Mix_VolumeMusic((float)v*stream_volume_mult1);
stream_volume=volume;
sub__sndvol_error=0;
return;
}
//find handle
for (i=0;i<65536;i++){
if (snd[i].handle==handle){
if (snd[i].free){error(5); return;}
if (!(snd[i].capability&SND_CAPABILITY_VOL)){error(5); return;}//unrequested capability
Mix_Volume(i,(float)v*snd[i].volume_mult1);
snd[i].volume=volume;
sub__sndvol_error=0;
return;
}
}//i
error(5); return;//invalid handle
}




void sub__sndpause(unsigned long handle){
static long i;
if (handle==0) return;//default response
if (handle==1){
if (!stream_loaded){error(5); return;}
if (stream_free){error(5); return;}
if (!(stream_capability&SND_CAPABILITY_PAUSE)){error(5); return;}//unrequested capability
if (stream_paused) return;
//still playing?
if (stream_playing&&(!stream_looping)) if (!Mix_PlayingMusic()) stream_playing=0;
if (!stream_playing) return;
Mix_PauseMusic();
stream_paused_time=SDL_GetTicks();
stream_paused=1;
return;
}
//find handle
for (i=0;i<65536;i++){
if (snd[i].handle==handle){
if (snd[i].free){error(5); return;}
if (!(snd[i].capability&SND_CAPABILITY_PAUSE)){error(5); return;}//unrequested capability
if (snd[i].paused) return;
//still playing?
if (snd[i].playing&&(!snd[i].looping)) if (!Mix_Playing(i)) snd[i].playing=0;
if (!snd[i].playing) return;
Mix_Pause(i);
snd[i].paused_time=SDL_GetTicks();
snd[i].paused=1;
return;
}
}//i
error(5); return;//invalid handle
}

long func__sndpaused(unsigned long handle){
static long i;
if (handle==0) return 0;//default response
if (handle==1){
if (!stream_loaded){error(5); return 0;}
if (stream_free){error(5); return 0;}
if (!(stream_capability&SND_CAPABILITY_PAUSE)){error(5); return 0;}//unrequested capability
if (stream_paused) return -1;
return 0;
}
//find handle
for (i=0;i<65536;i++){
if (snd[i].handle==handle){
if (snd[i].free){error(5); return 0;}
if (!(snd[i].capability&SND_CAPABILITY_PAUSE)){error(5); return 0;}//unrequested capability
if (snd[i].paused) return -1;
return 0;
}
}//i
error(5); return 0;//invalid handle
}


long func__sndplaying(unsigned long handle){
static long i;
if (handle==0) return 0;//default response
if (handle==1){
if (!stream_loaded){error(5); return 0;}
if (stream_free){error(5); return 0;}
//still playing?
if (stream_playing&&(!stream_looping)) if (!Mix_PlayingMusic()) stream_playing=0;
if (stream_paused) return 0;
if (stream_playing) return -1;
return 0;
}
//find handle
for (i=0;i<65536;i++){
if (snd[i].handle==handle){
if (snd[i].free){error(5); return 0;}
//still playing?
if (snd[i].playing&&(!snd[i].looping)) if (!Mix_Playing(i)) snd[i].playing=0;
if (snd[i].paused) return 0;
if (snd[i].playing) return -1;
return 0;
}
}//i
error(5); return 0;//invalid handle
}

void sub__sndclose(unsigned long handle){
static long i;
if (handle==0) return;//default response
if (handle==1){
if (!stream_loaded){error(5); return;}//invalid handle
if (stream_free){error(5); return;}//freed already
stream_free=1;
snd_check();
return;
}
//find handle
for (i=0;i<65536;i++){
if (snd[i].handle==handle){
if (snd[i].free){error(5); return;}//freed already
snd[i].free=1;
snd_check();
return;
}
}//i
error(5); return;//invalid handle
}

//"macros"
void sub__sndplayfile(qbs *filename,long sync,double volume,long passed){
static unsigned long handle;
static long setvolume;
static qbs *syncstr=NULL;
if (!syncstr) syncstr=qbs_new(0,0);
setvolume=0;
if (passed&2){
if ((volume<0)||(volume>1)){error(5); return;}
if (volume!=1) setvolume=1;
}
if ((!setvolume)&&(!sync)) syncstr->len=0;
if ((setvolume)&&(!sync)) qbs_set(syncstr,qbs_new_txt("VOL"));
if ((!setvolume)&&(sync)) qbs_set(syncstr,qbs_new_txt("SYNC"));
if ((setvolume)&&(sync)) qbs_set(syncstr,qbs_new_txt("SYNC,VOL"));
if (syncstr->len){
handle=func__sndopen(filename,syncstr,1);
}else{
handle=func__sndopen(filename,NULL,0);
}
if (handle==0) return;
if (setvolume) sub__sndvol(handle,volume);
sub__sndplay(handle);
sub__sndclose(handle);
}

void sub__sndplaycopy(unsigned long handle,double volume,long passed){
unsigned long handle2;
handle2=func__sndcopy(handle);
if (!handle2) return;//an error has already happened
if (passed){
sub__sndvol(handle2,volume);
if (sub__sndvol_error){
sub__sndclose(handle2);
return;
}
}
sub__sndplay(handle2);
sub__sndclose(handle2);
}

qbs *func_command_str=NULL;
qbs *func_command(){
static qbs *tqbs;
tqbs=qbs_new(func_command_str->len,1);
memcpy(tqbs->chr,func_command_str->chr,func_command_str->len);
return tqbs;
}


char g_tmp_char;
unsigned char g_tmp_uchar;
short g_tmp_short;
unsigned short g_tmp_ushort;
long g_tmp_long;
unsigned long g_tmp_ulong;
__int64 g_tmp_int64;
unsigned __int64 g_tmp_uint64;
float g_tmp_float;
double g_tmp_double;
long double g_tmp_longdouble;
qbs *g_swap_str;
const unsigned char QBMAIN_data[]={
#include "..\temp\userdata.txt"
};
qbs *pass_str;

#include "..\temp\regsf.txt"
#include "..\temp\global.txt"

int QBMAIN(void *unused)
{
long tmp_long;
long tmp_fileno;
static unsigned long data_offset=0;
static unsigned char *data=(unsigned char*)&QBMAIN_data[0];
unsigned long qbs_tmp_base=qbs_tmp_list_nexti;
#include "..\temp\maindata.txt"
#include "..\temp\mainerr.txt"
#include "..\temp\main.txt"
//...



int main( int argc, char* argv[] )
{
//WINDOWS SPECIFIC CONTENT
//HWND hWnd = GetConsoleWindow();
//ShowWindow( hWnd, SW_HIDE ); 
//END WINDOWS SPECIFIC CONTENT
FreeConsole();




//#ifndef _TM_DEFINED
//struct tm {
//        int tm_sec;     /* seconds after the minute - [0,59] */
//        int tm_min;     /* minutes after the hour - [0,59] */
//        int tm_hour;    /* hours since midnight - [0,23] */
//        int tm_mday;    /* day of the month - [1,31] */
//        int tm_mon;     /* months since January - [0,11] */
//        int tm_year;    /* years since 1900 */
//        int tm_wday;    /* days since Sunday - [0,6] */
//        int tm_yday;    /* days since January 1 - [0,365] */
//        int tm_isdst;   /* daylight savings time flag */
//        };
tm *qb64_tm;
time_t qb64_tm_val;
time_t qb64_tm_val_old;



//call both timing routines as close as possible to each other to maximize accuracy
//wait for second "hand" to "tick over"/move
time(&qb64_tm_val_old);
do{
time(&qb64_tm_val);
}while(qb64_tm_val==qb64_tm_val_old);
sdl_firsttimervalue=SDL_GetTicks();
qb64_tm=localtime(&qb64_tm_val);
//calculate localtime as milliseconds past midnight
//TODO: WHEN TIMER IS CALLED IT MUST SOMETIMES FORCE THE VALUE TO LOOP
qb64_firsttimervalue=qb64_tm->tm_hour*3600+qb64_tm->tm_min*60+qb64_tm->tm_sec;
qb64_firsttimervalue*=1000;

//init. main() temporary variables
long i,i2,i3,i4;
unsigned char c,c2,c3,c4;
long x,x2,x3,x4;
long y,y2,y3,y4;
long z,z2,z3,z4;

for (i=0;i<=65535;i++) device_handle[i].open=0;

for (i=0;i<32;i++) sub_file_print_spaces[i]=32;


port60h_event[0]=128;


mem_static_size=1048576;//1MEG
mem_static=(unsigned char*)malloc(mem_static_size);
mem_static_pointer=mem_static;
mem_static_limit=mem_static+mem_static_size;

memset(&cmem[0],0,sizeof(cmem));


memset(&keyon[0],0,sizeof(keyon));
dblock=(unsigned long)&cmem+1280;//0:500h

//define "nothing"
cmem_sp-=8; nothingvalue=(unsigned __int64*)(dblock+cmem_sp);
nothingvalue=0;
nothingstring=qbs_new_cmem(0,0);

i=argc;
if (i>1){
//calculate required size of COMMAND$ string
i2=0;
for (i=1;i<argc;i++){
i2+=strlen(argv[i]);
if (i!=1) i2++;//for a space
}
//create COMMAND$ string
func_command_str=qbs_new(i2,0);
//build COMMAND$ string
i3=0;
for (i=1;i<argc;i++){
if (i!=1){func_command_str->chr[i3]=32; i3++;}
memcpy(&func_command_str->chr[i3],argv[i],strlen(argv[i])); i3+=strlen(argv[i]);
}
}else{
func_command_str=qbs_new(0,0);
}

//init SDL
if ( SDL_Init(SDL_INIT_AUDIO|SDL_INIT_VIDEO|SDL_INIT_CDROM|SDL_INIT_TIMER) < 0 ) {
        fprintf(stderr, "Unable to init SDL: %s\n", SDL_GetError());
        exit(100);
    }




if (Mix_OpenAudio(22050,AUDIO_S16,2,1024)==-1) exit(10);
Mix_AllocateChannels(65536);
memset(snd,0,sizeof(snd));





/*

// load the MP3 file "music.mp3" to play as music

if (Mix_OpenAudio(44100,AUDIO_S16,2,1024)==-1) exit(3);

Mix_Music *music;


music=Mix_LoadMUS("sweet.mp3");
if(!music) {
exit(13);
}
if(Mix_PlayMusic(music, 0)==-1) {
exit(14);    
}

music=Mix_LoadMUS("ps4town.mid");
if(!music) {
exit(13);
}
if(Mix_PlayMusic(music, 0)==-1) {
exit(14);    
}

//Mix_LoadWAV can load OGG & MP3 to play them symmultaneously
//but streaming is better (or is it?)



//Mix_VolumeMusic(128);


//SleepEx(10000,0);
//exit(4);

*/


//memset(&sounds[0],0,sizeof(sample)*256);


/*
//Set 16-bit stereo audio at 22Khz
fmt.freq = 44100;
fmt.format = AUDIO_S16;
fmt.channels = 2;
fmt.samples = 4096;
fmt.callback = mixaudio;
fmt.userdata = NULL;
// Open the audio device and start playing sound!
if ( SDL_OpenAudio(&fmt, NULL) < 0 ) {
fprintf(stderr, "Unable to open audio: %s\n", SDL_GetError());
exit(101);
}
SDL_PauseAudio(0);
*/






//set key repeat rate
SDL_EnableKeyRepeat(500,30);
//safer to use default key repeat rates which aren't dissimilar to those used above

//enable unicode
SDL_EnableUNICODE(1);

//init fake keyb. cyclic buffer
cmem[0x41a]=30; cmem[0x41b]=0; //head
cmem[0x41c]=30; cmem[0x41d]=0; //tail

SDL_WM_SetIcon(SDL_LoadBMP(".\\data\\qb64icon.bmp"), NULL);
SDL_WM_SetCaption("Untitled",NULL);

screen = SDL_SetVideoMode(320, 240, 32, SDL_SWSURFACE);//|SDL_FULLSCREEN); SDL_SWSURFACE
    if ( screen == NULL ) {
        fprintf(stderr, "Unable to set video mode: %s\n", SDL_GetError());
        exit(102);
    }
unsigned long *pixel;
pixel=(unsigned long*)screen->pixels;
//SDL_ShowCursor(0);

//SDL_Cursor * mycursor=SDL_CreateCursor
		//(Uint8 *data, Uint8 *mask, int w, int h, int hot_x, int hot_y);
SDL_Cursor * mycursor=init_system_cursor(arrow);
SDL_SetCursor(mycursor);

ifstream fh;

//pre-check for required files
fh.open (".\\data\\qb64icon.bmp",ios::binary|ios::out|ios::in);
if (fh.is_open()){
fh.close();
}else{MessageBox(NULL,"QB64ICON.BMP","Data File Missing!",MB_OK); exit(1);}

//load the default 256 color palette
fh.open (".\\data\\qb64.pal",ios::binary|ios::out|ios::in);
if (fh.is_open()){
fh.read((char*)&qbg_palette_256,256*4);
fh.close();
}else{MessageBox(NULL,"QB64.PAL","Data File Missing!",MB_OK); exit(1);}

fh.open (".\\data\\qb64ega.pal",ios::binary|ios::out|ios::in);
if (fh.is_open()){
fh.read((char*)&qbg_palette_64,64*4);
fh.close();
}else{MessageBox(NULL,"QB64EGA.PAL","Data File Missing!",MB_OK); exit(1);}

//manually set screen 10 palette
pal_mode10[0][0]=0;
pal_mode10[0][1]=0;
pal_mode10[0][2]=0;
pal_mode10[0][3]=0x808080;
pal_mode10[0][4]=0x808080;
pal_mode10[0][5]=0x808080;
pal_mode10[0][6]=0xFFFFFF;
pal_mode10[0][7]=0xFFFFFF;
pal_mode10[0][8]=0xFFFFFF;
pal_mode10[1][0]=0;
pal_mode10[1][1]=0x808080;
pal_mode10[1][2]=0xFFFFFF;
pal_mode10[1][3]=0;
pal_mode10[1][4]=0x808080;
pal_mode10[1][5]=0xFFFFFF;
pal_mode10[1][6]=0;
pal_mode10[1][7]=0x808080;
pal_mode10[1][8]=0xFFFFFF;

//load the 8x8 character set
fh.open (".\\data\\charset8.raw",ios::binary|ios::out|ios::in);
if (fh.is_open()){
fh.read((char*)&charset8x8,256*8*8);
fh.close();
}else{MessageBox(NULL,"CHARSET8.RAW","Data File Missing!",MB_OK); exit(1);}

//load the 8x16 character set
fh.open (".\\data\\chrset16.raw",ios::binary|ios::out|ios::in);
if (fh.is_open()){
fh.read((char*)&charset8x16,256*16*8);
fh.close();
}else{MessageBox(NULL,"CHRSET16.RAW","Data File Missing!",MB_OK); exit(1);}


qbg_screen(0,NULL,NULL,NULL,1);
SDL_Delay(100);//Delay required to prevent thread accessing func. at same time


    thread = SDL_CreateThread(QBMAIN, NULL);
    if ( thread == NULL ) {
        fprintf(stderr, "Unable to create thread: %s\n", SDL_GetError());
        return 0;
    }


unsigned long subsystem_timer_next=0;
subsystem_timer_next=SDL_GetTicks();
unsigned long newtime;


subsystem_loop:
newtime=SDL_GetTicks();

if (sndqueue_first!=sndqueue_next){
if (sndqueue_played==0){
 sndqueue_played=1;
 if (sndqueue_first==sndqueue_wait){suspend_program^=2; sndqueue_wait=-1;}
 sub__sndplay(sndqueue[sndqueue_first]);
 sndqueue_first++;
}else{
 i=sndqueue_first-1; if (i==-1) i=sndqueue_lastindex;
 if (!func__sndplaying(sndqueue[i])){
 sub__sndclose(sndqueue[i]);
 if (sndqueue_first==sndqueue_wait){suspend_program^=2; sndqueue_wait=-1;}
 sub__sndplay(sndqueue[sndqueue_first]);
 sndqueue_first++; if (sndqueue_first>sndqueue_lastindex) sndqueue_first=0;
 }
}
}

if (newtime<subsystem_timer_next){
if (newtime<(subsystem_timer_next-1)) Sleep(1);
goto subsystem_loop;
}
subsystem_timer_next+=16;



if (close_program) goto end_program;


vertical_retrace_happened=1;
vertical_retrace_in_progress=1;


//screen 2 special formula!
if (qbg_mode==2){
if (full_screen){
 if ((qbg_program_window_width!=640)||(qbg_program_window_height!=480)||(full_screen_in_use!=full_screen)){
  qbg_program_window_width=640; qbg_program_window_height=480;
  screen = SDL_SetVideoMode(qbg_program_window_width, qbg_program_window_height, 32, SDL_SWSURFACE|(SDL_FULLSCREEN*full_screen));//|SDL_FULLSCREEN); SDL_SWSURFACE
  pixel=(unsigned long*)screen->pixels;
  full_screen_in_use=full_screen;
 }
}else{
 if ((qbg_program_window_width!=640)||(qbg_program_window_height!=400)||(full_screen_in_use!=full_screen)){
  qbg_program_window_width=640; qbg_program_window_height=400;
  screen = SDL_SetVideoMode(qbg_program_window_width, qbg_program_window_height, 32, SDL_SWSURFACE|(SDL_FULLSCREEN*full_screen));//|SDL_FULLSCREEN); SDL_SWSURFACE  
  pixel=(unsigned long*)screen->pixels;
  full_screen_in_use=full_screen;
 }
}
unsigned char *cp;
unsigned long *lp;
cp=qbg_visual_page_offset;
lp=pixel;
i2=qbg_program_window_width*qbg_program_window_height;
if (full_screen) {lp=lp+25600; i2=640*400;}
i3=0;
for (i=0;i<i2;i++){
*lp=pal[*cp];
i3++;
if (i3==640){cp-=640;i3=-640;}
cp++;
lp++;
}
goto screen_refreshed;
}//SCREEN 2 specific

if (qbg_text_only){
qbg_width=qbg_width_in_characters*qbg_character_width;
qbg_height=qbg_height_in_characters*qbg_character_height;
}
long qbg_y_offset;
qbg_y_offset=0;
x=qbg_width; y=qbg_height;
//fix aspect ratio for full screen
if (full_screen){
x2=x/4; y2=y/3;
if (x2!=y2){//aspect incorrect!
if (x2>y2){
y=x2*3;
qbg_y_offset=(y-qbg_height)/2;
}
}
}

if ((qbg_program_window_width!=x)||(qbg_program_window_height!=y)||(full_screen_in_use!=full_screen)){
qbg_program_window_width=x; qbg_program_window_height=y;
screen = SDL_SetVideoMode(qbg_program_window_width, qbg_program_window_height, 32, SDL_SWSURFACE|(SDL_FULLSCREEN*full_screen));//|SDL_FULLSCREEN); SDL_SWSURFACE
pixel=(unsigned long*)screen->pixels;
full_screen_in_use=full_screen;
}

if (qbg_text_only){
unsigned char *cp,*cp2;
unsigned long *lp;
qbg_y_offset=qbg_y_offset*qbg_program_window_width;
i=SDL_GetTicks()&256;
i4=SDL_GetTicks()&128;
cp=qbg_visual_page_offset;
y2=0;
for (y=0;y<qbg_height_in_characters;y++){
x2=0;
for (x=0;x<qbg_width_in_characters;x++){
//draw the character
if (qbg_character_height==8){
cp2=&charset8x8[*cp][0][0];
}else{
if (qbg_character_height==16){
cp2=&charset8x16[*cp][0][0];
}else{//assume 14
cp2=&charset8x16[*cp][1][0];
}
}
if (qbg_character_width==16) z2=1; else z2=0;
//set the correct color
cp++;
c=*cp&0xF;//foreground col
c2=(*cp>>4)&7;//background col
c3=*cp>>7;//flashing?
if (c3&&i) c=c2;
i2=pal[c];
i3=pal[c2];
lp=pixel+y2*qbg_width_in_characters*qbg_character_width+x2+qbg_y_offset;
z=qbg_width_in_characters*qbg_character_width-qbg_character_width;
for (y3=0;y3<qbg_character_height;y3++){
for (x3=0;x3<qbg_character_width;x3++){
if (*cp2) *lp=i2; else *lp=i3;
if (z2){
if (x3&z2) cp2++;
}else{
cp2++;
}
lp++;
}
lp+=z;
}//y3,x3
//

//###DRAW CURSOR IF NECESSARY###
long cx,cy;
cx=qbg_cursor_x; cy=qbg_cursor_y;
if (qbg_visual_page!=qbg_active_page){
cx=qbg_cursor_x_previous[qbg_visual_page]; cy=qbg_cursor_y_previous[qbg_visual_page];
}

if (qbg_cursor_show&&i4&&((cx-1)==x)&&((cy-1)==y)){
long v1,v2;
unsigned char from_bottom;//bottom is the 2nd bottom scanline in width ?x25
unsigned char half_cursor;//if set, overrides all following values
unsigned char size;//if 0, no cursor is drawn, if 255, from begin to bottom
unsigned char begin;//only relevant if from_bottom was not specified
v1=qbg_cursor_firstvalue;
v2=qbg_cursor_lastvalue;
from_bottom=0;
half_cursor=0;
size=0;
begin=0;
//RULE: IF V2=0, NOTHING (UNLESS V1=0)
if (v2==0){
if (v1==0){size=1; goto cursor_created;}
goto cursor_created;//no cursor!
}
//RULE: IF V2<V1, FROM V2 TO BOTTOM
if (v2<v1){begin=v2; size=255; goto cursor_created;}
//RULE: IF V1=V2, SINGLE SCANLINE AT V1 (OR BOTTOM IF V1>=4)
if (v1==v2){
if (v1<=3){begin=v1; size=1; goto cursor_created;}
from_bottom=1; size=1; goto cursor_created;
}
//NOTE: V2 MUST BE LARGER THAN V1!
//RULE: IF V1>=3, CALC. DIFFERENCE BETWEEN V1 & V2
//                IF DIFF=1, 2 SCANLINES AT BOTTOM
//                IF DIFF=2, 3 SCANLINES AT BOTTOM
//                OTHERWISE HALF CURSOR
if (v1>=3){
if ((v2-v1)==1){from_bottom=1; size=2; goto cursor_created;}
if ((v2-v1)==2){from_bottom=1; size=3; goto cursor_created;}
half_cursor=1; goto cursor_created;
}
//RULE: IF V1<=1, IF V2<=3 FROM V1 TO V3 ELSE FROM V1 TO BOTTOM
if (v1<=1){
if (v2<=3){begin=v1;size=v2-v1+1; goto cursor_created;} 
begin=v1;size=255; goto cursor_created;
}
//RULE: IF V1=2, IF V2=3, 2 TO 3
//               IF V2=4, 3 SCANLINES AT BOTTOM
//               IF V2>=5, FROM 2 TO BOTTOM
//(assume V1=2)
if (v2==3){begin=2;size=2; goto cursor_created;}
if (v2==4){from_bottom=1; size=3; goto cursor_created;}
begin=2;size=255;
cursor_created:

if (half_cursor){
//half cursor
y3=qbg_character_height-1;
size=qbg_character_height/2;
c=*cp&0xF;//foreground col
i2=pal[c];
draw_half_curs:
lp=pixel+(y2+y3)*qbg_width_in_characters*qbg_character_width+x2+qbg_y_offset;
for (x3=0;x3<qbg_character_width;x3++){
*lp=i2;
lp++;
}
y3--;
size--;
if (size) goto draw_half_curs;
}else{
if (from_bottom){
//cursor from bottom
y3=qbg_character_height-1;
if (y3==15) y3=14;//leave bottom line blank in 8x16 char set
c=*cp&0xF;//foreground col
i2=pal[c];
draw_curs_from_bottom:
lp=pixel+(y2+y3)*qbg_width_in_characters*qbg_character_width+x2+qbg_y_offset;
for (x3=0;x3<qbg_character_width;x3++){
*lp=i2;
lp++;
}
y3--;
size--;
if (size) goto draw_curs_from_bottom;
}else{
//cursor from begin using size
if (begin<qbg_character_height){
y3=begin;
c=*cp&0xF;//foreground col
i2=pal[c];
if (size==255) size=qbg_character_height-begin;
draw_curs_from_begin:
lp=pixel+(y2+y3)*qbg_width_in_characters*qbg_character_width+x2+qbg_y_offset;
for (x3=0;x3<qbg_character_width;x3++){
*lp=i2;
lp++;
}
y3++;
size--;
if (size) goto draw_curs_from_begin;
}
}
}



}//draw cursor?






cp++;
x2=x2+qbg_character_width;
}
y2=y2+qbg_character_height;
}
goto screen_refreshed;
}//text only



if (qbg_mode==10){
//pal_mode10[0-1][0-8]
//long qbg_color_assign[256];//for modes with quasi palettes!
i2=SDL_GetTicks()&512;
if (i2) i2=1;

for (i=0;i<=3;i++){
pal[i]=pal_mode10[i2][qbg_color_assign[i]];

}
}

if (qbg_bytes_per_pixel==1){
unsigned char *cp;
unsigned long *lp;

cp=qbg_visual_page_offset;
lp=pixel+(qbg_y_offset*qbg_program_window_width);
i=0xA000*16;
i2=qbg_program_window_width*(qbg_program_window_height-qbg_y_offset*2);


for (i=0;i<i2;i++){
*lp=pal[*cp];
cp++;
lp++;
}
}

screen_refreshed:
vertical_retrace_in_progress=0;

SDL_UpdateRect(screen, 0, 0, 0, 0);














//update input
SDL_Event event;
    while ( SDL_PollEvent(&event) ) {

        switch (event.type) {

case SDL_KEYUP:
if (event.key.keysym.sym<65536){
keyon[event.key.keysym.sym]=0;
if (port60h_events==256){memmove(port60h_event,port60h_event+1,255); port60h_events=255;}
port60h_event[port60h_events]=event.key.keysym.scancode+128;
port60h_events++;
}
break;

case SDL_KEYDOWN:

sleep_break=1;
static unsigned long key;
key=event.key.keysym.sym;
/*
(&H417 in QB)
40:0017   2  Keyboard status bits; see Keyboard Shift Status Flags
40:0019   1  Current (accumulating) value of Alt+numpad pseudo-key input;
             normally 0.  When [Alt] is released, value is stored in
             keyboard buffer at 001e.
40:001a   2  Addr of keyboard buffer head (keystroke at that addr is next)
40:001c   2  Address of keyboard buffer tail
***range from 30 to 60 even number only***
***if head=tail then no data is available***
40:001e  32  Keyboard buffer.  BIOS stores keystrokes here (head and tail
             point to addresses from 041eH to 043dH inclusive).
***first byte is ASCII CHR or 0***
***second byte is the scancode***
*/
//"If the high 9 bits of the character are 0, then this maps to the equivalent ASCII character"
if (event.key.keysym.sym<65536){
keyon[event.key.keysym.sym]=1;
if (port60h_events==256){memmove(port60h_event,port60h_event+1,255); port60h_events=255;}
port60h_event[port60h_events]=event.key.keysym.scancode;
port60h_events++;
}
//ALT-ENTER handling
if (keyon[SDLK_RALT]||keyon[SDLK_LALT]){
if ((event.key.keysym.sym==SDLK_KP_ENTER)||(event.key.keysym.sym==SDLK_RETURN)){
full_screen++; if (full_screen==2) full_screen=0;
goto silent_key;
}
}
//CTRL-BREAK handling
if (keyon[SDLK_RCTRL]||keyon[SDLK_LCTRL]){
if ((event.key.keysym.sym==SDLK_BREAK)||(event.key.keysym.sym==SDLK_PAUSE)||(event.key.keysym.sym==302)){//scroll lock can occur instead of break!
goto end_program;
}
}
/* Skip special keys
  SDLK_NUMLOCK		= 300,
	SDLK_CAPSLOCK		= 301,
	SDLK_SCROLLOCK		= 302,
	SDLK_RSHIFT		= 303,
	SDLK_LSHIFT		= 304,
	SDLK_RCTRL		= 305,
	SDLK_LCTRL		= 306,
	SDLK_RALT		= 307,
  SDLK_LALT		= 308,
*/


if ((key>=300)&&(key<=308)){
goto silent_key;
}

//BREAK handling
if ((event.key.keysym.sym==SDLK_BREAK)||(event.key.keysym.sym==SDLK_PAUSE)){
suspend_program|=1;
qbevent=1;
goto silent_key;
}else{
if (suspend_program&1){
suspend_program^=1;
goto silent_key;
}
}

if ((event.key.keysym.unicode&0xFF80)==0){
c=event.key.keysym.unicode&0x7F;
if (c){
//add to cyclic buffer
i=cmem[0x41a];
i2=cmem[0x41c];
//only add keypress if it fits in buffer
i3=i2+2;
if (i3==62) i3=30;
if (i!=i3){
cmem[0x400+i2]=c;
cmem[0x400+i2+1]=event.key.keysym.scancode;
cmem[0x41c]=i3;//fix tail location
goto gotkey;
}
}//c!=0
}else{
//printf("An International Character.\n");
goto gotkey;
}
//pass scancode only
if (event.key.keysym.scancode==55) goto gotkey; //PRINTSCREEN/SYSTEMSREQUEST ignore "7"
i=cmem[0x41a];
i2=cmem[0x41c];
i3=i2+2;
if (i3==62) i3=30;
if (i!=i3){
cmem[0x400+i2]=0;
cmem[0x400+i2+1]=event.key.keysym.scancode;
//special cases:
//F11 change "W" to CHR$(133)
if (event.key.keysym.scancode==87) cmem[0x400+i2+1]=133;
//F12 change "X" to CHR$(134)
if (event.key.keysym.scancode==88) cmem[0x400+i2+1]=134;
cmem[0x41c]=i3;//fix tail location
goto gotkey;
}
gotkey:;
silent_key:
break;
case SDL_MOUSEMOTION:
//         printf("Mouse moved by %d,%d to (%d,%d)\n", 
//   <9             event.motion.xrel, event.motion.yrel,
//                event.motion.x, event.motion.y);
break;
case SDL_MOUSEBUTTONDOWN:
//                printf("Mouse button %d pressed at (%d,%d)\n",
//                       event.button.button, event.button.x, event.button.y);
break;
case SDL_QUIT:
goto end_program;
}
}












static double pos;
if (stream_limited){
if (stream_loaded){
if (stream_playing){//worth checking?
pos=func__sndgetpos(1);
if (pos>=stream_limit){
sub__sndstop(1);
stream_limited=0;
}}}}







goto subsystem_loop;

end_program:
stop_program=1;
qbevent=1;
SDL_WaitThread(thread, NULL);
SDL_ShowCursor(0);
SDL_FreeCursor(mycursor);
SDL_CloseAudio();
atexit(SDL_Quit);
exit(0);
}

