QB64 COMPILER V0.61SC DOCUMENTATION
===================================

Important changes since V0.6
----------------------------
The QB64 compiler is now a self-compiled Windows program. Due to QB64 not having a pure console mode yet, SCREEN 0 windows "pop-up" as each QB64 executable begins.
It corrects the following problems:
-EXIT SUB/EXIT FUNCTION weren't supported
-There were significant limitations on the maximum number of variables
-When the value of an equation is passed to a sub/func wasn't always passed with the correct type
-Some local sub/func variables were being assigned global names when created
-END didn't work inside a sub/func
-Programs couldn't exit (via CTRL-break or X button) inside a sub/func
-WHILE/DO WHILE/LOOP WHILE couldn't be passed a variable, it had to be an equation
-The OPEN (file) statement didn't work because of a problem introduced in demo 6
-FOR/NEXT counter variables being set inside the loop weren't handled properly
-FOR/NEXT statements didn't work correctly when used in indwelling subs/functions
-Passing an array's element of the same type as a sub/functions parameter didn't pass the element's offset
-The DOS version of compile.exe was unstable and frequently ran out of memory/stack space/etc.
-DEFINT/etc. calls were ignored by sub/function initialization
-DOSBOX was required under some Windows configurations to run the compiler
The COMMAND$ function has also been implemented

Thanks for trying QB64! The goal of QB64 is to create programs from BASIC source for Windows, Mac OSX and Linux whilst being 100% compatible with Microsoft QBASIC/QB4.5

At present, QB64 only compiles programs on/for Microsoft Windows.

To compile a .BAS program simply run the program COMPILE.BAT. It will prompt you to enter the .BAS file's name. Make sure your .BAS file was saved in text format not the QB4.5 compressed file format.

Due to the large volume of example .BAS files which can be compiled they have been put into a folder called "samples". Please read "samples.txt" for an explanation about each example.

QB64 is still in development and many things still need to be implemented. However Demo #6 has significantly more implemented QB features than unimplemented. So you can understand the limitations of Demo #6 a list of UNIMPLEMENTED features is provided. EVERYTHING ELSE WORKS!

Demo #6 Restrictions/Unimplemented Features
1. Cannot use user defined types
2. Cannot use ON ... EVENTS (however, ON ERROR GOTO and error handling is implemented)
3. Cannot use metacommand $INCLUDE
4. Cannot use CONST
5. Cannot use TRON/TROFF
6. Cannot use COM, SCRN, LPT, KYBD, CONS in an OPEN statement
7. Cannot call machine code (CALL ABSOLUTE, CALL INTERRUPT)
8. Port access is still very limited:
OUT &H3C8 & &H3C9 work
INP &H3DA & &H60 work
9. Cannot use the following DOS file commands: CHAIN, SHELL, FILES, KILL, NAME, FILEATTR, CHDIR, MKDIR, RMDIR, ENVIRON, ENVIRON$, RUN
10. The following commands are also unavailable: PRINT[#]USING, LPRINT, LPOS, DRAW, PLAY, CLEAR, FIELD, LOCK, UNLOCK, IOCTL, IOCTL$, PEN, STICK, STRING, SETMEM, FRE, FIELD
11. DIM SHARED works, but STATIC and SHARED commands within SUBs/FUNCTIONs don't

Known issues:
1. Error handling is done incorrectly. (will be fixed in Demo #7)
 Example of problem:
 ON ERROR GOTO 10
 PRINT SQR(-1) 'reports the error, but after resume still prints 0
 END
 10
 RESUME NEXT
2. BIT-type variables/arrays are not fully implemented in certain subs/functions which are passed their offset. (will be fixed in Demo #7)
3. Certain functions which accept a floating point number always return a DOUBLE precision answer. (will be fixed in Demo #7)
 Example of problem:
 PRINT SIN(1.234!) 'prints a longer answer in QB64 than in QBASIC
(Please report any other problems you encounter so they can be fixed for Demo #7)
4. See the QB64 forum for details about recently found problems. Demo #7 will be devoted to fixing these issues and other incompatabilities.

What features does QB64 have that QBASIC doesn't?
-------------------------------------------------
INPUT statement uses input protection which stops the user from typing in invalid data before they can press ENTER. Try it with fixed length strings to limit how many characters a user can enter. No more "REDO FROM START" messages!
-------------------------------------------------
DATA TYPES & THEIR USAGE:
_BIT			name`
_UNSIGNED _BIT		name~`
_BIT*4			name`4
_UNSIGNED _BIT*4	name~`4
_BYTE			name%%
_UNSIGNED _BYTE		name~%%
INTEGER			name%
_UNSIGNED INTEGER	name~%
LONG			name&
_UNSIGNED LONG		name~&
_INTEGER64		name&&
_UNSIGNED _INTEGER64	name~&&
SINGLE			name!
DOUBLE			name#
_FLOAT			name##
STRING			name$
STRING*100		name$100
-------------------------------------------------
Instead of having DEFBIT,DEFUBT,DEFBYT,DEFUBY etc. for all the new data types there is a simple command which can be used like DEFINT for new types (or old types if you want to) as follows...
_DEFINE A-C,Z AS DOUBLE 'the same as DEFDBL A-C,Z
-------------------------------------------------
For RANDOM access files, record lengths can be greater than 32767 bytes. Variable length string headers allow for larger strings whilst still being 100% QB compatible with smaller strings.
-------------------------------------------------
BLOAD/BSAVE can save/load 65536 bytes, not just 65535
-------------------------------------------------
_ROUND can also be used to round values to integers (CINT & CLNG imposed limitations on the output)
-------------------------------------------------
Graphics GET supports a new optional argument. If used the area to store can be partially/all off-screen and off-screen pixels are set to the value specified eg.
GET (-10,-10)-(10,10),a,3
Graphics PUT format has been extended to PUT[{STEP}](?,?),?[,[{_CLIP}][{PSET|PRESET|AND|OR|XOR}][,?]] where _CLIP allows drawing partially/all off-screen and the final optional argument can specify a mask color to skip when drawing.
-------------------------------------------------
Support for playing .mid, .wav, .mp3 and other formats.
Commands include:
_SNDPLAYFILE		Simple command to play a sound file (with limited options)
_SNDOPEN		Returns a handle to a sound file
_SNDCLOSE		Unloads a sound file (waits until after it has finished playing)
_SNDPLAY		Plays a sound
_SNDSTOP		Stops a playing (or paused) sound
_SNDPLAYING		Returns whether a sound is being played
_SNDLOOP		Like _SNDPLAY but sound is looped
_SNDLIMIT		Stops playing a sound after it has been playing for a set number of seconds
_SNDGETPOS		Returns to current playing position in seconds
_SNDCOPY		Copies a sound (so two or more of the same sound can be played at once)
_SNDPLAYCOPY		Copies a sound, plays it and automatically closes the copy
_SNDPAUSE		Pauses a sound
_SNDPAUSED		Checks if a sound is paused
_SNDLEN			Returns the length of a sound in seconds
_SNDVOL			Sets the volume of a sound
_SNDBAL			Sets the balance/3D position of a sound
_SNDSETPOS		Changes the current/starting playing position of a sound in seconds
For more information, read audio.txt in your qb64 folder.
Also check out audio.bas in the samples folder, you'll need some audio files to test this with!
