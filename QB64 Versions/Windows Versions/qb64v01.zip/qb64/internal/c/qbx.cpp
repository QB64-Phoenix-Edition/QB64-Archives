//WINDOWS SPECIFIC CONTENT
#define _WIN32_WINNT 0x0500
#include "stdafx2.h"
#include "float.h"
#include "math.h"
#include "time.h"
//END WINDOWS SPECIFIC CONTENT

//#include "stdafx.h"
#include "SDL.h"
#include "SDL_audio.h"
#include "SDL_thread.h"

#include <iostream>
#include <fstream>
using namespace std;

unsigned long qb64_firsttimervalue;
unsigned long sdl_firsttimervalue;

unsigned char qb64_musicforeground=0;

unsigned char qbevent=0;
unsigned char wait_needed=255;

SDL_Surface * screen;
unsigned char full_screen=0;
unsigned char full_screen_in_use=0;

unsigned char qbg_vertical_retrace_port=8;

__int64 qbr(long double f){if (f<0) return(f-0.5f); else return(f+0.5f);}
long qbr_float_to_long(float f){if (f<0) return(f-0.5f); else return(f+0.5f);}
long qbr_double_to_long(double f){if (f<0) return(f-0.5f); else return(f+0.5f);}

static const char *arrow[] = {
  /* width height num_colors chars_per_pixel */
  "    32    32        3            1",
  /* colors */
  "X c #000000",
  ". c #ffffff",
  "  c None",
  /* pixels */
"X                               ",
"XX                              ",
"X.X                             ",
"X..X                            ",
"X...X                           ",
"X....X                          ",
"X.....X                         ",
"X......X                        ",
"X.......X                       ",
"X........X                      ",
"X.........X                     ",
"X......XXXXX                    ",
"X...X..X                        ",
"X..XX..X                        ",
"X.X  X..X                       ",
"XX   X..X                       ",
"X     X..X                      ",
"      X..X                      ",
"       X..X                     ",
"       X..X                     ",
"        XX                      ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
  "0,0"
};

static SDL_Cursor *init_system_cursor(const char *image[])
{
  int i, row, col;
  Uint8 data[4*32];
  Uint8 mask[4*32];
  int hot_x, hot_y;

  i = -1;
  for ( row=0; row<32; ++row ) {
    for ( col=0; col<32; ++col ) {
      if ( col % 8 ) {
        data[i] <<= 1;
        mask[i] <<= 1;
      } else {
        ++i;
        data[i] = mask[i] = 0;
      }
      switch (image[4+row][col]) {
        case 'X':
          data[i] |= 0x01;
          mask[i] |= 0x01;//?
          break;
        case '.':
          mask[i] |= 0x01;
          break;
        case ' ':
          break;
      }
    }
  }
  sscanf(image[4+row], "%d,%d", &hot_x, &hot_y);
  return SDL_CreateCursor(data, mask, 32, 32, hot_x, hot_y);
}

unsigned char lock_subsystem=0;
unsigned char stop_program=0;
unsigned char program_wait=0;

long global_counter=0;

extern void mixaudio(void *unused, Uint8 *stream, int len);
SDL_AudioSpec fmt;
SDL_AudioSpec fmt2;

#define NUM_SOUNDS 256
struct sample{
    Uint8 *data;
    Uint32 dpos;
    Uint32 dlen;
};

sample sounds[NUM_SOUNDS];

void mixaudio(void *unused, Uint8 *stream, int len)
{
    int i;
    Uint32 amount;

    for ( i=0; i<NUM_SOUNDS; ++i ) {
        amount = (sounds[i].dlen-sounds[i].dpos);
        if ( amount > len ) {
            amount = len;
        }
        SDL_MixAudio(stream, &sounds[i].data[sounds[i].dpos], amount, SDL_MIX_MAXVOLUME);
        sounds[i].dpos += amount;
    }
}

//note: for stereo(2) channels store each sample left:right:left:right:...etc
//      NOT right then left!
void qb64_playwavbuffer(void* offset,long bytes,long frequency,long bitspersample,long channels){
static long i,format;
static SDL_AudioCVT cvt;

if (qb64_musicforeground){
//wait for foreground line to open
foregroundline_wait: if (sounds[255].dpos!=sounds[255].dlen) {SDL_Delay(1); goto foregroundline_wait;}
i=255;
goto foregroundlineopen;
}

for (i=0;i<(NUM_SOUNDS-1);i++){
if (sounds[i].dpos==sounds[i].dlen){//unused index found!
foregroundlineopen:
format=AUDIO_S16;
//if (bitspersample==????) format=????;
//...
SDL_BuildAudioCVT(&cvt,format,channels,frequency,AUDIO_S16,2,44100);
cvt.buf=(unsigned __int8*)malloc(bytes*cvt.len_mult);
memcpy(cvt.buf,offset,bytes);
cvt.len=bytes;
SDL_ConvertAudio(&cvt);
SDL_LockAudio();
if (sounds[i].data) free(sounds[i].data);
sounds[i].data = cvt.buf;
sounds[i].dlen = cvt.len_cvt;
sounds[i].dpos = 0;
SDL_UnlockAudio();
return;
}//unused index found
}//index loop
//note: qb64_playwavbuffer does not return any information either now, whilst
//      or after a buffer is played
}

//optomized buffer player (no conversion code is needed)
void qb64_playwavbuffer44100x16x2(void* offset,long bytes){
static long i;

if (qb64_musicforeground){
//wait for foreground line to open
foregroundline_wait: if (sounds[255].dpos!=sounds[255].dlen) {SDL_Delay(1); goto foregroundline_wait;}
i=255;
goto foregroundlineopen;
}

for (i=0;i<(NUM_SOUNDS-1);i++){
if (sounds[i].dpos==sounds[i].dlen){//unused index found!
foregroundlineopen:
SDL_LockAudio();
if (sounds[i].data) free(sounds[i].data);
sounds[i].data = (unsigned __int8*)offset;
sounds[i].dlen = bytes;
sounds[i].dpos = 0;
SDL_UnlockAudio();
return;
}
}
}

void qb64_generatesound(double f,double l){
//f=frequency (ie. waves per second)
//l=length in seconds
//always creates a triangular wave
static short shortval;
static long i;
static short *p,*firstp;
static long s;//number of samples needed
static long b;//bytes needed
static double v;
static long dir;
static double rate;//rate of change per sample
s=l*44100.0; s++;//samples
b=s*4;
p=(short*)malloc(b);
firstp=p;
v=0;
dir=1;//up
//rate=number of ossilations in one second*distance per ossilation/samples per sec
//note:131072=32768*4
rate=f*131072.0/44100.0;
for (i=0;i<s;i++){
shortval=((long)v)-32768;
*p=shortval;
p++;
*p=shortval;
p++;
if (dir){
v+=rate;
if (v>=65536.0){v=65536.0-(v-65536.0); dir=0;}
}else{
v-=rate;
if (v<0.0){v=-v; dir=1;}
}
}//i


qb64_playwavbuffer44100x16x2(firstp,b);
}



void PlaySound(char *file)
{

/*
How it Works!
1. find an empty sound slot (currently 256 available) and store number in variable index
2. load the wav file, putting data into 
   i) "wave"(a structure containing info. about the format)
   ii) *data(a pointer, presumably to the raw data of the loaded wav file)
   iii) dlen(the length of the data IN BYTES)
3. build SDL_AudioCVT cvt, a structure(set with a function call) which explains
   a source format and a destination format for wav data
4. although cvt has been set, it's cvt.buf data pointer is undefined.
   a buffer is malloc'd of dlen*cvt.len_mult (len_mult is what the original 
   size must be multiplied by to have enough space for the converted buffer)
   the original data to be converted is copied into the destination buffer
   cvt.len is also set to dlen to specify the size of the source data
5. SDL_ConvertAudio(&cvt) is called to convert the source format's data into
   the destination format's data
6. if there is data in the "index" slot from a previous playing it is free'd
7. the following code is used to begin playing the raw wave data:
    SDL_LockAudio();
    sounds[index].data = cvt.buf;
    sounds[index].dlen = cvt.len_cvt;
    sounds[index].dpos = 0;
    SDL_UnlockAudio();
   the REASON it begins playing immediatly is because the callback c++ mixaudio
   function sees that dpos is not at the end and "out-mixes" the audio
(and now it all makes perfect sense ;) )
*/

    int index;
    SDL_AudioSpec wave;
    Uint8 *data;
    Uint32 dlen;
    SDL_AudioCVT cvt;

    /* Look for an empty (or finished) sound slot */
    for ( index=0; index<(NUM_SOUNDS-1); ++index ) {
        if ( sounds[index].dpos == sounds[index].dlen ) {
            break;
        }
    }
    if ( index == (NUM_SOUNDS-1) )
        return;

    /* Load the sound file and convert it to 16-bit stereo at 22kHz */
    if ( SDL_LoadWAV(file, &wave, &data, &dlen) == NULL ) {
        fprintf(stderr, "Couldn't load %s: %s\n", file, SDL_GetError());
        return;
    }
    SDL_BuildAudioCVT(&cvt, wave.format, wave.channels, wave.freq,
                            AUDIO_S16,   2,             44100);
    cvt.buf = (Uint8*)malloc(dlen*cvt.len_mult);
    memcpy(cvt.buf, data, dlen);
    
    cvt.len = dlen;
    SDL_ConvertAudio(&cvt);
    SDL_FreeWAV(data);

    /* Put the sound data in the slot (it starts playing immediately) */
    if ( sounds[index].data ) {
        free(sounds[index].data);
    }
    SDL_LockAudio();
    sounds[index].data = cvt.buf;
    sounds[index].dlen = cvt.len_cvt;
    sounds[index].dpos = 0;
    SDL_UnlockAudio();
}

//nb. abreviations are used in variable names to save typing, here are some of the expansions
//cmem=conventional memory
//qbs=qbick basic string (refers to the emulation of quick basic strings)
//sp=stack pointer
//dblock=a 64K memory block in conventional memory holding single variables and strings

unsigned char cmem[1114098];//16*65535+65535+3 (enough for highest referencable dword in conv memory)
unsigned long qbs_cmem_sp=0;
unsigned long cmem_sp=65536;
unsigned long dblock;//32bit offset of dblock
unsigned char keyon[65536];

struct qbs
{
unsigned char *chr; //a 32 bit pointer to the string's data
unsigned long len;
unsigned char in_cmem; //set to 1 if in the conventional memory DBLOCK
unsigned long listi; //the index in the list of strings that references it
unsigned char tmp; //set to 1 if the string can be deleted immediately after being processed
unsigned long tmplisti; //the index in the list of strings that references it
unsigned char fixed; //fixed length string
unsigned char readonly; //set to 1 if string is read only
};

qbs *qbs_malloc=(qbs*)calloc(sizeof(qbs)*65536,1);//~1MEG
unsigned long qbs_malloc_next=0;//the next idex in qbs_malloc to use
unsigned long *qbs_malloc_freed=(unsigned long*)malloc(4*65536);
unsigned long qbs_malloc_freed_size=65536;
unsigned long qbs_malloc_freed_num=0;//number of freed qbs descriptors
qbs *qbs_new_descriptor(){
if (qbs_malloc_freed_num){
return (qbs*)memset((void *)qbs_malloc_freed[--qbs_malloc_freed_num],0,sizeof(qbs));
}
if (qbs_malloc_next==65536){
qbs_malloc=(qbs*)calloc(sizeof(qbs)*65536,1);//~1MEG
qbs_malloc_next=0;
}
return &qbs_malloc[qbs_malloc_next++];
}
void qbs_free_descriptor(qbs *str){
if (qbs_malloc_freed_num==qbs_malloc_freed_size){
 qbs_malloc_freed_size*=2;
 qbs_malloc_freed=(unsigned long*)realloc(qbs_malloc_freed,qbs_malloc_freed_size*4);
}
qbs_malloc_freed[qbs_malloc_freed_num]=(unsigned long)str;
qbs_malloc_freed_num++;
return;
}

//Used to track strings in 16bit memory
unsigned long *qbs_cmem_list=(unsigned long*)malloc(65536*4);
unsigned long  qbs_cmem_list_lasti=65535;
unsigned long  qbs_cmem_list_nexti=0;
//Used to track strings in 32bit memory
unsigned long *qbs_list=(unsigned long*)malloc(65536*4);
unsigned long  qbs_list_lasti=65535;
unsigned long  qbs_list_nexti=0;
//Used to track temporary strings for later removal when they fall out of scope
//*Some string functions delete a temporary string automatically after they have been
// passed one to save memory. In this case qbstring_templist[?]=0xFFFFFFFF
unsigned long *qbs_tmp_list=(unsigned long*)malloc(65536*4);
unsigned long  qbs_tmp_list_lasti=65535;
unsigned long  qbs_tmp_list_nexti=1;
//entended string memory
unsigned char *qbs_data=(unsigned char*)malloc(1048576);
unsigned long qbs_data_size=1048576;
unsigned long qbs_sp=0;

void qbs_free(qbs *str){
if (str->fixed||str->readonly){
 qbs_free_descriptor(str);
 return;
}
if (str->tmplisti){
 qbs_tmp_list[str->tmplisti]=0xFFFFFFFF;
 if ((qbs_tmp_list_nexti-1)==str->tmplisti) qbs_tmp_list_nexti--;
}
if (str->in_cmem){
 qbs_cmem_list[str->listi]=0xFFFFFFFF;
 if ((qbs_cmem_list_nexti-1)==str->listi) qbs_cmem_list_nexti--;
}else{
 qbs_list[str->listi]=0xFFFFFFFF;
 if ((qbs_list_nexti-1)==str->listi) qbs_list_nexti--;
}
qbs_free_descriptor(str);
return;
}

void qbs_cmem_concat_list(){
unsigned long i;
unsigned long d;
qbs *tqbs;
d=0;
for (i=0;i<qbs_cmem_list_nexti;i++){
 if (i!=d){
  if (qbs_cmem_list[i]!=0xFFFFFFFF){
   tqbs=(qbs*)qbs_cmem_list[i];
   tqbs->listi=d;
   qbs_cmem_list[d]=(unsigned long)tqbs;
   d++;
  }
 }
}
qbs_cmem_list_nexti=d;
//if string listings are taking up more than half of the list array double the list array's size
if (qbs_cmem_list_nexti>=(qbs_cmem_list_lasti/2)){
qbs_cmem_list_lasti*=2;
qbs_cmem_list=(unsigned long*)realloc(qbs_cmem_list,(qbs_cmem_list_lasti+1)*4);
}
return;
}

void qbs_concat_list(){
unsigned long i;
unsigned long d;
qbs *tqbs;
d=0;
for (i=0;i<qbs_list_nexti;i++){
 if (i!=d){
  if (qbs_list[i]!=0xFFFFFFFF){
   tqbs=(qbs*)qbs_list[i];
   tqbs->listi=d;
   qbs_list[d]=(unsigned long)tqbs;
   d++;
  }
 }
}
qbs_list_nexti=d;
//if string listings are taking up more than half of the list array double the list array's size
if (qbs_list_nexti>=(qbs_list_lasti/2)){
qbs_list_lasti*=2;
qbs_list=(unsigned long*)realloc(qbs_list,(qbs_list_lasti+1)*4);
}
return;
}

void qbs_tmp_concat_list(){
if (qbs_tmp_list_nexti>=(qbs_tmp_list_lasti/2)){
qbs_tmp_list_lasti*=2;
qbs_tmp_list=(unsigned long*)realloc(qbs_tmp_list,(qbs_tmp_list_lasti+1)*4);
}
return;
}


void qbs_concat(unsigned long bytesrequired){
//this does not change indexing, only ->chr pointers and the location of their data
long i;
unsigned char *dest;
qbs *tqbs;
dest=(unsigned char*)qbs_data;
qbs_sp=0;
if (qbs_list_nexti){
 for (i=0;i<qbs_list_nexti;i++){
  if (qbs_list[i]!=0xFFFFFFFF){
   tqbs=(qbs*)qbs_list[i];
   if (tqbs->chr!=dest){    
    if (tqbs->len) {memmove(dest,tqbs->chr,tqbs->len); dest+=tqbs->len; qbs_sp+=tqbs->len;}
    tqbs->chr=dest;
   }
  }
 }
}
if ((qbs_sp+bytesrequired)>qbs_data_size){
 unsigned long qbs_data_oldoffset;
 qbs_data_oldoffset=(unsigned long)qbs_data;
 qbs_data_size=qbs_data_size*2+bytesrequired;
 qbs_data=(unsigned char*)realloc(qbs_data,qbs_data_size);
 long difference;
 if ((unsigned long)qbs_data>=qbs_data_oldoffset){
  difference=(unsigned long)qbs_data-qbs_data_oldoffset;
 }else{
  difference=-(qbs_data_oldoffset-(unsigned long)qbs_data);
 }
 for (i=0;i<qbs_list_nexti;i++){
  tqbs=(qbs*)qbs_list[i];
  tqbs->chr=tqbs->chr+difference;
 }
}
return;
}

//as the cmem stack has a limit if bytesrequired cannot be met this exits and returns an error
//the cmem stack cannot after all be extended!
//so bytesrequired is only passed to possibly generate an error, or not generate one
void qbs_concat_cmem(unsigned long bytesrequired){
//this does not change indexing, only ->chr pointers and the location of their data
long i;
unsigned char *dest;
qbs *tqbs;
dest=(unsigned char*)dblock;
qbs_cmem_sp=0;
if (qbs_cmem_list_nexti){
 for (i=0;i<qbs_cmem_list_nexti;i++){
  if (qbs_cmem_list[i]!=0xFFFFFFFF){
   tqbs=(qbs*)qbs_cmem_list[i];
   if (tqbs->chr!=dest){    
    if (tqbs->len) {memmove(dest,tqbs->chr,tqbs->len); dest+=tqbs->len; qbs_cmem_sp+=tqbs->len;}
    tqbs->chr=dest;
   }
  }
 }
}
if ((qbs_cmem_sp+bytesrequired)>cmem_sp){
 printf("NOT ENOUGH CONVENTIONAL MEMORY DYNAMIC STRING SPACE AVAILABLE!");
 PlaySound(".\\data\\beep.wav");
 SDL_Delay(3000);
 exit(1);
}
return;
}

qbs *qbs_new_cmem(long size,unsigned char tmp){
if ((qbs_cmem_sp+size)>cmem_sp) qbs_concat_cmem(size);
qbs *newstr;
newstr=qbs_new_descriptor();
newstr->len=size;
newstr->chr=(unsigned char*)dblock+qbs_cmem_sp;
qbs_cmem_sp+=size;
newstr->in_cmem=1;
if (qbs_cmem_list_nexti>qbs_cmem_list_lasti) qbs_cmem_concat_list();
newstr->listi=qbs_cmem_list_nexti; qbs_cmem_list[newstr->listi]=(unsigned long)newstr; qbs_cmem_list_nexti++;
if (tmp){
if (qbs_tmp_list_nexti>qbs_tmp_list_lasti) qbs_tmp_concat_list();
newstr->tmplisti=qbs_tmp_list_nexti; qbs_tmp_list[newstr->tmplisti]=(unsigned long)newstr; qbs_tmp_list_nexti++;
newstr->tmp=1;
}
return newstr;
}

qbs *qbs_new_txt(const char *txt){
qbs *newstr;
newstr=qbs_new_descriptor();
newstr->len=strlen(txt);
newstr->chr=(unsigned char*)txt;
if (qbs_tmp_list_nexti>qbs_tmp_list_lasti) qbs_tmp_concat_list();
newstr->tmplisti=qbs_tmp_list_nexti; qbs_tmp_list[newstr->tmplisti]=(unsigned long)newstr; qbs_tmp_list_nexti++;
newstr->tmp=1;
newstr->readonly=1;
return newstr;
}

qbs *qbs_new_fixed(unsigned char *offset,unsigned long size){
qbs *newstr;
newstr=qbs_new_descriptor();
newstr->len=size;
newstr->chr=offset;
if (qbs_tmp_list_nexti>qbs_tmp_list_lasti) qbs_tmp_concat_list();
newstr->tmplisti=qbs_tmp_list_nexti; qbs_tmp_list[newstr->tmplisti]=(unsigned long)newstr; qbs_tmp_list_nexti++;
newstr->tmp=1;
newstr->fixed=1;
return newstr;
}

qbs *qbs_new(long size,unsigned char tmp){
if ((qbs_sp+size)>qbs_data_size) qbs_concat(size);
qbs *newstr;
newstr=qbs_new_descriptor();
newstr->len=size;
newstr->chr=qbs_data+qbs_sp;
qbs_sp+=size;
if (qbs_list_nexti>qbs_list_lasti) qbs_concat_list();
newstr->listi=qbs_list_nexti; qbs_list[newstr->listi]=(unsigned long)newstr; qbs_list_nexti++;
if (tmp){
if (qbs_tmp_list_nexti>qbs_tmp_list_lasti) qbs_tmp_concat_list();
newstr->tmplisti=qbs_tmp_list_nexti; qbs_tmp_list[newstr->tmplisti]=(unsigned long)newstr; qbs_tmp_list_nexti++;
if (tmp==2) newstr->tmp=1;
}
return newstr;
}

qbs *qbs_set(qbs *deststr,qbs *srcstr){
long i;
qbs *tqbs;

//fixed deststr
if (deststr->fixed){
 if (srcstr->len>=deststr->len){
  memcpy(deststr->chr,srcstr->chr,deststr->len);
 }else{
  memcpy(deststr->chr,srcstr->chr,srcstr->len);
  memset(deststr->chr+srcstr->len,32,deststr->len-srcstr->len);//pad with spaces
 }
 goto qbs_set_return;
}
//non-fixed deststr

//can srcstr be aquired by deststr?
if (srcstr->tmp){
if (srcstr->fixed==0){
if (srcstr->readonly==0){
if (srcstr->in_cmem==deststr->in_cmem){
if (deststr->in_cmem){
 //unlist deststr and acquire srcstr's list index
 qbs_cmem_list[deststr->listi]=0xFFFFFFFF;
 qbs_cmem_list[srcstr->listi]=(unsigned long)deststr;
 deststr->listi=srcstr->listi;
}else{
 //unlist deststr and acquire srcstr's list index
 qbs_list[deststr->listi]=0xFFFFFFFF;
 qbs_list[srcstr->listi]=(unsigned long)deststr;
 deststr->listi=srcstr->listi;
}
if (srcstr->tmp){
 qbs_tmp_list[srcstr->tmplisti]=0xFFFFFFFF;
 if (srcstr->tmplisti==(qbs_tmp_list_nexti-1)) qbs_tmp_list_nexti--;//correct last tmp index for performance
}
deststr->chr=srcstr->chr;
deststr->len=srcstr->len;
qbs_free_descriptor(srcstr);
return deststr;//nb. This return cannot be changed to a goto qbs_set_return!
}}}}

//srcstr is equal length or shorter
if (srcstr->len<=deststr->len){
 memcpy(deststr->chr,srcstr->chr,srcstr->len);
 deststr->len=srcstr->len;
 goto qbs_set_return;
}

//srcstr is longer
if (deststr->in_cmem){
 if (deststr->listi==(qbs_cmem_list_nexti-1)){//last index
  if (((unsigned long)deststr->chr+srcstr->len)<=(dblock+cmem_sp)){//space available
   memcpy(deststr->chr,srcstr->chr,srcstr->len);
   deststr->len=srcstr->len;  
   qbs_cmem_sp=(unsigned long)deststr->chr+deststr->len-(unsigned long)dblock;
   goto qbs_set_return;
  }
 }
 //deststr is not the last index so locate next valid index
 i=deststr->listi+1;
 qbs_set_nextindex:
 if (qbs_cmem_list[i]!=0xFFFFFFFF){
  tqbs=(qbs*)qbs_cmem_list[i];
  if (tqbs==srcstr){
   if (srcstr->tmp==1) goto skippedtmpsrcindex;
  }
  if ((deststr->chr+srcstr->len)>tqbs->chr) goto qbs_set_cmem_concat_required;
  memcpy(deststr->chr,srcstr->chr,srcstr->len);
  deststr->len=srcstr->len;
  goto qbs_set_return;
 }
 skippedtmpsrcindex:
 i++;
 if (i!=qbs_cmem_list_nexti) goto qbs_set_nextindex;
 //all next indexes invalid!
 qbs_cmem_list_nexti=deststr->listi+1;//adjust nexti
 if (((unsigned long)deststr->chr+srcstr->len)<=(dblock+cmem_sp)){//space available
   memmove(deststr->chr,srcstr->chr,srcstr->len);//overlap possible due to sometimes aquiring srcstr's space
   deststr->len=srcstr->len;
   qbs_cmem_sp=(unsigned long)deststr->chr+deststr->len-(unsigned long)dblock;
   goto qbs_set_return;
 }
qbs_set_cmem_concat_required:
//srcstr could not fit in deststr
//"realloc" deststr
qbs_cmem_list[deststr->listi]=0xFFFFFFFF;//unlist
if ((qbs_cmem_sp+srcstr->len)>cmem_sp){//must concat!
qbs_concat_cmem(srcstr->len);
}
if (qbs_cmem_list_nexti>qbs_cmem_list_lasti) qbs_cmem_concat_list();
qbs_cmem_list[qbs_cmem_list_nexti]=(unsigned long)deststr; qbs_cmem_list_nexti++; //relist
deststr->chr=(unsigned char*)dblock+qbs_cmem_sp;
deststr->len=srcstr->len;
qbs_cmem_sp+=deststr->len;
memcpy(deststr->chr,srcstr->chr,srcstr->len);
goto qbs_set_return;
}

//not in cmem
 if (deststr->listi==(qbs_list_nexti-1)){//last index
  if (((unsigned long)deststr->chr+srcstr->len)<=((unsigned long)qbs_data+qbs_data_size)){//space available
   memcpy(deststr->chr,srcstr->chr,srcstr->len);
   deststr->len=srcstr->len;
   qbs_sp=(unsigned long)deststr->chr+deststr->len-(unsigned long)qbs_data;
   goto qbs_set_return;
  }
 }
 //deststr is not the last index so locate next valid index
 i=deststr->listi+1;
 qbs_set_nextindex2:
 if (qbs_list[i]!=0xFFFFFFFF){
  tqbs=(qbs*)qbs_list[i];
  if (tqbs==srcstr){
   if (srcstr->tmp==1) goto skippedtmpsrcindex2;
  }
  if ((deststr->chr+srcstr->len)>tqbs->chr) goto qbs_set_concat_required;
  memcpy(deststr->chr,srcstr->chr,srcstr->len);
  deststr->len=srcstr->len;
  goto qbs_set_return;
 }
 skippedtmpsrcindex2:
 i++;
 if (i!=qbs_list_nexti) goto qbs_set_nextindex2;
 //all next indexes invalid!
 qbs_list_nexti=deststr->listi+1;//adjust nexti 
 if (((unsigned long)deststr->chr+srcstr->len)<=((unsigned long)qbs_data+qbs_data_size)){//space available
   memmove(deststr->chr,srcstr->chr,srcstr->len);//overlap possible due to sometimes aquiring srcstr's space
   deststr->len=srcstr->len;
   qbs_sp=(unsigned long)deststr->chr+deststr->len-(unsigned long)qbs_data;
   goto qbs_set_return;
 }
qbs_set_concat_required:
//srcstr could not fit in deststr
//"realloc" deststr
qbs_list[deststr->listi]=0xFFFFFFFF;//unlist
if ((qbs_sp+srcstr->len)>qbs_data_size){//must concat!
qbs_concat(srcstr->len);
}
if (qbs_list_nexti>qbs_list_lasti) qbs_concat_list();
qbs_list[qbs_list_nexti]=(unsigned long)deststr; qbs_list_nexti++; //relist
deststr->chr=qbs_data+qbs_sp;
deststr->len=srcstr->len;
qbs_sp+=deststr->len;
memcpy(deststr->chr,srcstr->chr,srcstr->len);
//(fall through to qbs_set_return)

qbs_set_return:
if (srcstr->tmp){//remove srcstr if it is a tmp string
qbs_free(srcstr);
}

return deststr;
}

qbs *qbs_add(qbs *str1,qbs *str2){
qbs *tqbs;
if (!str2->len) return str1;//pass on
if (!str1->len) return str2;//pass on
//may be possible to acquire str1 or str2's space but...
//1. check if dest has enough space (because its data is already in the correct place)
//2. check if source has enough space
//3. give up
//nb. they would also have to be a tmp, var. len str in ext memory!
//brute force method...
tqbs=qbs_new(str1->len+str2->len,1);
memcpy(tqbs->chr,str1->chr,str1->len);
memcpy(tqbs->chr+str1->len,str2->chr,str2->len);
if (str1->tmp) qbs_free(str1);
if (str2->tmp) qbs_free(str2);
return tqbs;
}

qbs *qbs_ucase(qbs *str){
unsigned long i;
unsigned char *c;
if (!str->len) return str;//pass on
qbs *tqbs=NULL;
if (str->tmp){ if (!str->fixed){ if (!str->readonly){ if (!str->in_cmem){ tqbs=str; }}}}
if (!tqbs){
//also pass on if already uppercase
c=str->chr;
for (i=0;i<str->len;i++){
 if ((*c>=97)&&(*c<=122)) goto qbs_ucase_cantpass;
 c++;
}
return str;
qbs_ucase_cantpass:
tqbs=qbs_new(str->len,1); memcpy(tqbs->chr,str->chr,str->len);
}
c=tqbs->chr;
for (i=0;i<tqbs->len;i++){
 if ((*c>=97)&&(*c<=122)) *c-=32;
 c++;
}
if (tqbs!=str) if (str->tmp) qbs_free(str);
return tqbs;
}

qbs *qbs_lcase(qbs *str){
unsigned long i;
unsigned char *c;
if (!str->len) return str;//pass on
qbs *tqbs=NULL;
if (str->tmp){ if (!str->fixed){ if (!str->readonly){ if (!str->in_cmem){ tqbs=str; }}}}
if (!tqbs){
//also pass on if already lowercase
c=str->chr;
for (i=0;i<str->len;i++){
 if ((*c>=65)&&(*c<=90)) goto qbs_lcase_cantpass;
 c++;
}
return str;
qbs_lcase_cantpass:
tqbs=qbs_new(str->len,1); memcpy(tqbs->chr,str->chr,str->len);
}
c=tqbs->chr;
for (i=0;i<tqbs->len;i++){
 if ((*c>=65)&&(*c<=90)) *c+=32;
 c++;
}
if (tqbs!=str) if (str->tmp) qbs_free(str);
return tqbs;
}

qbs *qbs_left(qbs *str,long l){
if (l>str->len) l=str->len;
if (l<0) l=0;
if (l==str->len) return str;//pass on
if (str->tmp){ if (!str->fixed){ if (!str->readonly){ if (!str->in_cmem){ str->len=l; return str; }}}}
qbs *tqbs;
tqbs=tqbs=qbs_new(l,1);
if (l) memcpy(tqbs->chr,str->chr,l);
if (str->tmp) qbs_free(str);
return tqbs;
}

qbs *qbs_right(qbs *str,long l){
if (l>str->len) l=str->len;
if (l<0) l=0;
if (l==str->len) return str;//pass on
if (str->tmp){ if (!str->fixed){ if (!str->readonly){ if (!str->in_cmem){
str->chr=str->chr+(str->len-l);
str->len=l; return str;
}}}}
qbs *tqbs;
tqbs=qbs_new(l,1);
if (l) memcpy(tqbs->chr,str->chr+str->len-l,l);
tqbs->len=l;
if (str->tmp) qbs_free(str);
return tqbs;
}

qbs *qbs_ltrim(qbs *str){
if (!str->len) return str;//pass on
if (*str->chr!=32) return str;//pass on
if (str->tmp){ if (!str->fixed){ if (!str->readonly){ if (!str->in_cmem){//acquire?
qbs_ltrim_nextchar:
if (*str->chr==32){
str->chr++;
if (--str->len) goto qbs_ltrim_nextchar;
}
return str;
}}}}
long i;
i=0;
qbs_ltrim_nextchar2: if (str->chr[i]==32) {i++; if (i<str->len) goto qbs_ltrim_nextchar2;}
qbs *tqbs;
tqbs=qbs_new(str->len-i,1);
if (tqbs->len) memcpy(tqbs->chr,str->chr+i,tqbs->len);
if (str->tmp) qbs_free(str);
return tqbs;
}

qbs *qbs_rtrim(qbs *str){
if (!str->len) return str;//pass on
if (str->chr[str->len-1]!=32) return str;//pass on
if (str->tmp){ if (!str->fixed){ if (!str->readonly){ if (!str->in_cmem){//acquire?
qbs_rtrim_nextchar:
if (str->chr[str->len-1]==32){
if (--str->len) goto qbs_rtrim_nextchar;
}
return str;
}}}}
long i;
i=str->len;
qbs_rtrim_nextchar2: if (str->chr[i-1]==32) {i--; if (i) goto qbs_rtrim_nextchar2;}
//i is the number of characters to keep
qbs *tqbs;
tqbs=qbs_new(i,1);
if (i) memcpy(tqbs->chr,str->chr,i);
if (str->tmp) qbs_free(str);
return tqbs;
}

qbs *qbs_inkey(){
//lock_subsystem=1;
//qbs_inkey_subs_wait:
//SDL_Delay(10);
//if (lock_subsystem==1) goto qbs_inkey_subs_wait;
qbs *tqbs;
tqbs=qbs_new(2,1);
if (cmem[0x41a]!=cmem[0x41c]){
tqbs->chr[0]=cmem[0x400+cmem[0x41a]];
tqbs->chr[1]=cmem[0x400+cmem[0x41a]+1];
if (tqbs->chr[0]) tqbs->len=1;
cmem[0x41a]+=2;
if (cmem[0x41a]==62) cmem[0x41a]=30;
}else{
tqbs->len=0;
}
//lock_subsystem=0;
return tqbs;
}





//singed integers
qbs *qbs_str(long value){
qbs *tqbs;
tqbs=qbs_new(11,1);
if (value<0){
tqbs->len=sprintf((char*)tqbs->chr,"%i",value);
}else{
tqbs->len=sprintf((char*)tqbs->chr+1,"%i",value)+1;
tqbs->chr[0]=32;
}
return tqbs;
}
qbs *qbs_str(short value){
qbs *tqbs;
tqbs=qbs_new(6,1);
if (value<0){
tqbs->len=sprintf((char*)tqbs->chr,"%i",value);
}else{
tqbs->len=sprintf((char*)tqbs->chr+1,"%i",value)+1;
tqbs->chr[0]=32;
}
return tqbs;
}
qbs *qbs_str(char value){
qbs *tqbs;
tqbs=qbs_new(4,1);
if (value<0){
tqbs->len=sprintf((char*)tqbs->chr,"%i",value);
}else{
tqbs->len=sprintf((char*)tqbs->chr+1,"%i",value)+1;
tqbs->chr[0]=32;
}
return tqbs;
}

//unsigned integers
qbs *qbs_str(unsigned long value){
qbs *tqbs;
tqbs=qbs_new(11,1);
tqbs->len=sprintf((char*)tqbs->chr+1,"%u",value)+1;
tqbs->chr[0]=32;
return tqbs;
}
qbs *qbs_str(unsigned short value){
qbs *tqbs;
tqbs=qbs_new(6,1);
tqbs->len=sprintf((char*)tqbs->chr+1,"%u",value)+1;
tqbs->chr[0]=32;
return tqbs;
}
qbs *qbs_str(unsigned char value){
qbs *tqbs;
tqbs=qbs_new(4,1);
tqbs->len=sprintf((char*)tqbs->chr+1,"%u",value)+1;
tqbs->chr[0]=32;
return tqbs;
}


unsigned char func_str_fmt[7];
unsigned char qbs_str_buffer[32];

qbs *qbs_str(float value){
static qbs *tqbs;
tqbs=qbs_new(16,1);
static long l,i,i2,i3,digits,exponent;
l=sprintf((char*)&qbs_str_buffer,"% .6E",value);
//IMPORTANT: assumed l==14
digits=7;
for (i=8;i>=1;i--){
if (qbs_str_buffer[i]==48){
digits--;
}else{
if (qbs_str_buffer[i]!=46) break;
}
}//i
//no significant digits? simply return 0
if (digits==0){
tqbs->len=2; tqbs->chr[0]=32; tqbs->chr[1]=48;//tqbs=[space][0]
return tqbs;
}
//calculate exponent
exponent=(qbs_str_buffer[11]-48)*100+(qbs_str_buffer[12]-48)*10+(qbs_str_buffer[13]-48);
if (qbs_str_buffer[10]==45) exponent=-exponent;
if ((exponent<=6)&&((exponent-digits)>=-8)) goto asdecimal;
//fix up exponent to conform to QBASIC standards
//i. cull trailing 0's after decimal point (use digits to help)
//ii. cull leading 0's of exponent
i3=0;
i2=digits+2;
if (digits==1) i2--;//don't include decimal point
for (i=0;i<i2;i++) {tqbs->chr[i3]=qbs_str_buffer[i]; i3++;}
for (i=9;i<=10;i++) {tqbs->chr[i3]=qbs_str_buffer[i]; i3++;}
exponent=abs(exponent);
//i2=13;
//if (exponent>9) i2=12;
i2=12;//override: if exponent is less than 10 still display a leading 0
if (exponent>99) i2=11;
for (i=i2;i<=13;i++) {tqbs->chr[i3]=qbs_str_buffer[i]; i3++;}
tqbs->len=i3;
return tqbs;
/////////////////////
asdecimal:
//calculate digits after decimal point in var. i
i=-(exponent-digits+1);
if (i<0) i=0;
func_str_fmt[0]=37;//"%"
func_str_fmt[1]=32;//" "
func_str_fmt[2]=46;//"."
func_str_fmt[3]=i+48;
func_str_fmt[4]=102;//"f"
func_str_fmt[5]=0;
tqbs->len=sprintf((char*)tqbs->chr,(const char*)&func_str_fmt,value);
if (tqbs->chr[1]==48){//must manually cull leading 0
memmove(tqbs->chr+1,tqbs->chr+2,tqbs->len-2);
tqbs->len--;
}
return tqbs;
}

qbs *qbs_str(double value){
static qbs *tqbs;
tqbs=qbs_new(32,1);
static long l,i,i2,i3,digits,exponent;
l=sprintf((char*)&qbs_str_buffer,"% .15E",value);
//IMPORTANT: assumed l==23
qbs_str_buffer[18]=68; //change E to D (QBASIC standard)
digits=16;
for (i=17;i>=1;i--){
if (qbs_str_buffer[i]==48){
digits--;
}else{
if (qbs_str_buffer[i]!=46) break;
}
}//i
//no significant digits? simply return 0
if (digits==0){
tqbs->len=2; tqbs->chr[0]=32; tqbs->chr[1]=48;//tqbs=[space][0]
return tqbs;
}
//calculate exponent
exponent=(qbs_str_buffer[20]-48)*100+(qbs_str_buffer[21]-48)*10+(qbs_str_buffer[22]-48);
if (qbs_str_buffer[19]==45) exponent=-exponent;
//OLD if ((exponent<=15)&&((exponent-digits)>=-16)) goto asdecimal;
if ((exponent<=15)&&((exponent-digits)>=-17)) goto asdecimal;
//fix up exponent to conform to QBASIC standards
//i. cull trailing 0's after decimal point (use digits to help)
//ii. cull leading 0's of exponent
i3=0;
i2=digits+2;
if (digits==1) i2--;//don't include decimal point
for (i=0;i<i2;i++) {tqbs->chr[i3]=qbs_str_buffer[i]; i3++;}
for (i=18;i<=19;i++) {tqbs->chr[i3]=qbs_str_buffer[i]; i3++;}
exponent=abs(exponent);
//i2=22;
//if (exponent>9) i2=21;
i2=21;//override: if exponent is less than 10 still display a leading 0
if (exponent>99) i2=20;
for (i=i2;i<=22;i++) {tqbs->chr[i3]=qbs_str_buffer[i]; i3++;}
tqbs->len=i3;
return tqbs;
/////////////////////
asdecimal:
//calculate digits after decimal point in var. i
i=-(exponent-digits+1);
if (i<0) i=0;
func_str_fmt[0]=37;//"%"
func_str_fmt[1]=32;//" "
func_str_fmt[2]=46;//"."
if (i>9){
func_str_fmt[3]=49;//"1"
func_str_fmt[4]=(i-10)+48;
}else{
func_str_fmt[3]=48;//"0"
func_str_fmt[4]=i+48;
}
func_str_fmt[5]=102;//"f"
func_str_fmt[6]=0;
tqbs->len=sprintf((char*)tqbs->chr,(const char*)&func_str_fmt,value);
if (tqbs->chr[1]==48){//must manually cull leading 0
memmove(tqbs->chr+1,tqbs->chr+2,tqbs->len-2);
tqbs->len--;
}
return tqbs;
}

qbs *qbs_str(long double value){
//not fully implemented
return qbs_str((double)value);
}


long qbs_equal(qbs *str1,qbs *str2){
if (str1->len!=str2->len) return 0;
if (memcmp(str1->chr,str2->chr,str1->len)==0) return -1;
return 0;
}
long qbs_notequal(qbs *str1,qbs *str2){
if (str1->len!=str2->len) return -1;

if (memcmp(str1->chr,str2->chr,str1->len)==0) return 0;
return -1;
}
long qbs_greaterthan(qbs *str1,qbs *str2){
long i;
if (str1->len<=str2->len){
i=memcmp(str1->chr,str2->chr,str1->len);
if (i>0) return -1;
return 0;
}else{
i=memcmp(str1->chr,str2->chr,str2->len);
if (i<0) return 0;
return -1;
}
}

long qbs_asc(qbs *str){
if (str->len) return str->chr[0];
return 0;
}

long qbs_len(qbs *str){
return str->len;
}

long qbg_program_window_width=320;
long qbg_program_window_height=240;


long qbg_mode=-1;//-1 means not initialized!
long qbg_text_only;
//text & graphics modes
long qbg_height_in_characters, qbg_width_in_characters;
long qbg_top_row, qbg_bottom_row;
long qbg_cursor_x, qbg_cursor_y;
long qbg_character_height, qbg_character_width;
unsigned long qbg_color, qbg_background_color;
//text mode ONLY
long qbg_cursor_show;
long qbg_cursor_firstvalue, qbg_cursor_lastvalue;//these values need revision
//graphics modes ONLY
long qbg_width, qbg_height;
float qbg_x, qbg_y;
long qbg_bits_per_pixel, qbg_pixel_mask; //for monochrome modes 1b, for 16 color 1111b, for 256 color 11111111b
long qbg_bytes_per_pixel;
long qbg_clipping_or_scaling;//1=clipping, 2=clipping and scaling
long qbg_view_x1, qbg_view_y1, qbg_view_x2, qbg_view_y2;
long qbg_view_offset_x, qbg_view_offset_y;
float qbg_scaling_x, qbg_scaling_y;
float qbg_scaling_offset_x, qbg_scaling_offset_y;
float qbg_window_x1, qbg_window_y1, qbg_window_x2, qbg_window_y2;
long qbg_pages;
unsigned long *qbg_pageoffsets;
long *qbg_cursor_x_previous; //used to recover old cursor position
long *qbg_cursor_y_previous;


long qbg_active_page;
unsigned char *qbg_active_page_offset;
long qbg_visual_page;
unsigned char *qbg_visual_page_offset;
long qbg_color_assign[256];//for modes with quasi palettes!

unsigned long pal_mode10[2][9];

unsigned long pal[256];
unsigned char charset8x8[256][8][8];
unsigned char charset8x16[256][16][8];


unsigned long qbg_palette_256[256];
unsigned long qbg_palette_64[64];

long lineclip_draw;//1=draw, 0=don't draw
long lineclip_x1,lineclip_y1,lineclip_x2,lineclip_y2;
long lineclip_skippixels;//the number of pixels from x1,y1 which won't be drawn

void lineclip(long x1,long y1,long x2,long y2,long xmin,long ymin,long xmax,long ymax){
static double mx,my,y,x,d;
static long xdis,ydis;
//is it a single point? (needed to avoid "division by 0" errors)
lineclip_skippixels=0;

if (x1==x2){ if (y1==y2){
if (x1>=xmin){ if (x1<=xmax){ if (y1>=ymin){ if (y1<=ymax){
goto singlepoint;
}}}}
lineclip_draw=0;
return;
}}

if (x1>=xmin){ if (x1<=xmax){ if (y1>=ymin){ if (y1<=ymax){
goto gotx1y1;
}}}}
mx=(x2-x1)/fabs(y2-y1); my=(y2-y1)/fabs(x2-x1);
//right wall from right
if (x1>xmax){
if (mx<0){
y=(double)y1+((double)x1-(double)xmax)*my;
if (y>=ymin){ if (y<=ymax){
  //double space indented values calculate pixels to skip
  xdis=x1; ydis=y1;
x1=xmax; y1=qbr_float_to_long(y);
  xdis=abs(xdis-x1); ydis=abs(ydis-y1);
  if (xdis>=ydis) lineclip_skippixels=xdis; else lineclip_skippixels=ydis;
goto gotx1y1;
}}
}
}
//left wall from left
if (x1<xmin){
if (mx>0){
y=(double)y1+((double)xmin-(double)x1)*my;
if (y>=ymin){ if (y<=ymax){
  //double space indented values calculate pixels to skip
  xdis=x1; ydis=y1;
x1=xmin; y1=qbr_float_to_long(y);
  xdis=abs(xdis-x1); ydis=abs(ydis-y1);
  if (xdis>=ydis) lineclip_skippixels=xdis; else lineclip_skippixels=ydis;
goto gotx1y1;
}}
}
}
//top wall from top
if (y1<ymin){
if (my>0){
x=(double)x1+((double)ymin-(double)y1)*mx;
if (x>=xmin){ if (x<=xmax){
  //double space indented values calculate pixels to skip
  xdis=x1; ydis=y1;
x1=qbr_float_to_long(x); y1=ymin;
  xdis=abs(xdis-x1); ydis=abs(ydis-y1);
  if (xdis>=ydis) lineclip_skippixels=xdis; else lineclip_skippixels=ydis;
goto gotx1y1;
}}
}
}
//bottom wall from bottom
if (y1>ymax){
if (my<0){
x=(double)x1+((double)y2-(double)ymax)*mx;
if (x>=xmin){ if (x<=xmax){
  //double space indented values calculate pixels to skip
  xdis=x1; ydis=y1;
x1=qbr_float_to_long(x); y1=ymax;
  xdis=abs(xdis-x1); ydis=abs(ydis-y1);
  if (xdis>=ydis) lineclip_skippixels=xdis; else lineclip_skippixels=ydis;
goto gotx1y1;
}}
}
}
lineclip_draw=0;
return;
gotx1y1:

if (x2>=xmin){ if (x2<=xmax){ if (y2>=ymin){ if (y2<=ymax){
goto gotx2y2;
}}}}


mx=(x1-x2)/fabs(y1-y2); my=(y1-y2)/fabs(x1-x2);
//right wall from right
if (x2>xmax){
if (mx<0){
y=(double)y2+((double)x2-(double)xmax)*my;
if (y>=ymin){ if (y<=ymax){
x2=xmax; y2=qbr_float_to_long(y);
goto gotx2y2;
}}
}
}
//left wall from left
if (x2<xmin){
if (mx>0){
y=(double)y2+((double)xmin-(double)x2)*my;
if (y>=ymin){ if (y<=ymax){
x2=xmin; y2=qbr_float_to_long(y);
goto gotx2y2;
}}
}
}
//top wall from top
if (y2<ymin){
if (my>0){
x=(double)x2+((double)ymin-(double)y2)*mx;
if (x>=xmin){ if (x<=xmax){
x2=qbr_float_to_long(x); y2=ymin;
goto gotx2y2;
}}
}
}
//bottom wall from bottom
if (y2>ymax){
if (my<0){
x=(double)x2+((double)y2-(double)ymax)*mx;
if (x>=xmin){ if (x<=xmax){
x2=qbr_float_to_long(x); y2=ymax;
goto gotx2y2;
}}
}
}
lineclip_draw=0;
return;
gotx2y2:
singlepoint:
lineclip_draw=1;
lineclip_x1=x1; lineclip_y1=y1; lineclip_x2=x2; lineclip_y2=y2;


return;
}

//initialises the palette data for qbg_mode
void qbg_restorepalette(){

/*
SCREEN Mode 1 Syntax:  COLOR [background][,palette]
   � background is the screen color (range = 0-15)
   � palette is a three-color palette (range = 0-1)
     0 = green, red, and brown         1 = cyan, magenta, and bright white
Note: option 1 is the default, palette can override these though
OPTION 1:*DEFAULT*
0=black(color 0)
1=cyan(color 3)
2=purple(color 5)
3=light grey(color 7)
OPTION 0:
0=black(color 0)
1=green(color 2)
2=red(color 4)
3=brown(color 6)
*/
if (qbg_mode==1){
pal[0]=qbg_palette_256[0];
pal[1]=qbg_palette_256[3];
pal[2]=qbg_palette_256[5];
pal[3]=qbg_palette_256[7];
return;
}

if (qbg_mode==2){//black/white 2 color palette
pal[0]=0;
pal[1]=0xFFFFFF;
return;
}

if (qbg_mode==9){//16 colors selected from 64 possibilities
pal[0]=qbg_palette_64[0];
pal[1]=qbg_palette_64[1];
pal[2]=qbg_palette_64[2];
pal[3]=qbg_palette_64[3];
pal[4]=qbg_palette_64[4];
pal[5]=qbg_palette_64[5];
pal[6]=qbg_palette_64[20];
pal[7]=qbg_palette_64[7];
pal[8]=qbg_palette_64[56];
pal[9]=qbg_palette_64[57];
pal[10]=qbg_palette_64[58];
pal[11]=qbg_palette_64[59];
pal[12]=qbg_palette_64[60];
pal[13]=qbg_palette_64[61];
pal[14]=qbg_palette_64[62];
pal[15]=qbg_palette_64[63];
return;
}

if (qbg_mode==10){//4 colors selected from 9 possibilities (does not use pal[] array)
qbg_color_assign[0]=0;
qbg_color_assign[1]=4;
qbg_color_assign[2]=6;
qbg_color_assign[3]=8;
return;
}

if (qbg_mode==11){//black/white 2 color palette
pal[0]=0;
pal[1]=0xFFFFFF;
return;
}

//default 256 color palette (some screens only access bottom 16 colors)


memcpy(pal,qbg_palette_256,1024);


}

//this is NOT the PALETTE USING sub which still needs to be created
void qbg_palette(long attribute,long col,long passed){

if (!(passed&3)){
if (!passed){
void qbg_restorepalette();
return;
}
goto qbg_palette_error;
}

if (qbg_mode==13){
if ((attribute<0)||(attribute>255)) goto qbg_palette_error;
if (col&0xFFC0C0C0) goto qbg_palette_error;//11111111110000001100000011000000b
long r,g,b;
r=col&63;
g=(col>>8)&63;
b=(col>>16)&63;
r=qbr((double)r*4.063492f-0.4999999f);
g=qbr((double)g*4.063492f-0.4999999f);
b=qbr((double)b*4.063492f-0.4999999f);
pal[attribute]=b+g*256+r*65536;
//pal[attribute]=(((col<<2)&0xFF)<<16)+(((col>>6)&0xFF)<<8)+((col>>14)&0xFF);
return;
}

if (qbg_mode==12){
if ((attribute<0)||(attribute>15)) goto qbg_palette_error;
if (col&0xFFC0C0C0) goto qbg_palette_error;//11111111110000001100000011000000b
pal[attribute]=(((col<<2)&0xFF)<<16)+(((col>>6)&0xFF)<<8)+((col>>14)&0xFF);
return;
}

if (qbg_mode==11){
if ((attribute<0)||(attribute>1)) goto qbg_palette_error;
if (col&0xFFC0C0C0) goto qbg_palette_error;//11111111110000001100000011000000b
pal[attribute]=(((col<<2)&0xFF)<<16)+(((col>>6)&0xFF)<<8)+((col>>14)&0xFF);
return;
}

if (qbg_mode==10){
if ((attribute<0)||(attribute>3)) goto qbg_palette_error;
if ((col<0)||(col>8)) goto qbg_palette_error;
qbg_color_assign[attribute]=col;
return;
}

if (qbg_mode==9){
if ((attribute<0)||(attribute>15)) goto qbg_palette_error;
if ((col<0)||(col>63)) goto qbg_palette_error;
pal[attribute]=qbg_palette_64[col];
return;
}

if (qbg_mode==8){
if ((attribute<0)||(attribute>15)) goto qbg_palette_error;
if ((col<0)||(col>15)) goto qbg_palette_error;
pal[attribute]=qbg_palette_256[col];
return;
}

if (qbg_mode==7){
if ((attribute<0)||(attribute>15)) goto qbg_palette_error;
if ((col<0)||(col>15)) goto qbg_palette_error;
pal[attribute]=qbg_palette_256[col];
return;
}

if (qbg_mode==2){
if ((attribute<0)||(attribute>1)) goto qbg_palette_error;
if ((col<0)||(col>15)) goto qbg_palette_error;
pal[attribute]=qbg_palette_256[col];
return;
}

if (qbg_mode==1){
if ((attribute<0)||(attribute>15)) goto qbg_palette_error;
if ((col<0)||(col>15)) goto qbg_palette_error;
pal[attribute]=qbg_palette_256[col];
return;
}

if (qbg_mode==0){
if ((attribute<0)||(attribute>15)) goto qbg_palette_error;
if ((col<0)||(col>63)) goto qbg_palette_error;
pal[attribute]=qbg_palette_64[col];
return;
}

qbg_palette_error:
MessageBox(NULL,"Illegal Function Call","ERROR!",MB_OK);//ERROR!
return;

}//qbg_palette (end)

void qbg_sub_color(long col1,long col2,long bordercolor,long passed){
//PRE-ERROR CHECKING
if (!passed){
//note. many screens (such as 13) change nothing if nothing is passed
//      this has been adopted as the default response in this case
return;
}

if (qbg_mode==13){
if (passed&6) goto qbg_sub_color_error;
if ((col1>255)||(col1<0)) goto qbg_sub_color_error;
qbg_color=col1;
return;
}
if (qbg_mode==12){
if (passed&6) goto qbg_sub_color_error;
if ((col1>15)||(col1<0)) goto qbg_sub_color_error;
qbg_color=col1;
return;
}
if (qbg_mode==11){
if (passed&6) goto qbg_sub_color_error;
if ((col1>1)||(col1<0)) goto qbg_sub_color_error;
qbg_color=col1;
return;
}
if (qbg_mode==10){
if (passed&4) goto qbg_sub_color_error;
if (passed&1) if ((col1>3)||(col1<0)) goto qbg_sub_color_error;
if (passed&2) if ((col2>8)||(col2<0)) goto qbg_sub_color_error;
if (passed&1) qbg_color=col1;
if (passed&2) qbg_color_assign[0]=col2;
return;
}
if (qbg_mode==9){
if (passed&4) goto qbg_sub_color_error;
if (passed&1) if ((col1>15)||(col1<0)) goto qbg_sub_color_error;
if (passed&2) if ((col2>63)||(col2<0)) goto qbg_sub_color_error;
if (passed&1) qbg_color=col1;
if (passed&2) pal[0]=qbg_palette_64[col2];
return;
}
if (qbg_mode==8){
if (passed&4) goto qbg_sub_color_error;
if (passed&1) if ((col1>15)||(col1<0)) goto qbg_sub_color_error;
if (passed&2) if ((col2>15)||(col2<0)) goto qbg_sub_color_error;
if (passed&1) qbg_color=col1;
if (passed&2) pal[0]=qbg_palette_256[col2];
return;
}
if (qbg_mode==7){
if (passed&4) goto qbg_sub_color_error;
if (passed&1) if ((col1>15)||(col1<0)) goto qbg_sub_color_error;
if (passed&2) if ((col2>15)||(col2<0)) goto qbg_sub_color_error;
if (passed&1) qbg_color=col1;
if (passed&2) pal[0]=qbg_palette_256[col2];
return;
}
if (qbg_mode==2){
if (passed&4) goto qbg_sub_color_error;
if (passed&1) if ((col1>1)||(col1<0)) goto qbg_sub_color_error;
if (passed&2) if ((col2>15)||(col2<0)) goto qbg_sub_color_error;
if (passed&1) qbg_color=col1;
if (passed&2) pal[0]=qbg_palette_256[col2];
return;
}
if (qbg_mode==1){
if (passed&4) goto qbg_sub_color_error;
if (passed&1){
if ((col1>15)||(col1<0)) goto qbg_sub_color_error;
pal[0]=qbg_palette_256[col1];
}
if (passed&2){
if (col2&1){
pal[1]=qbg_palette_256[3];
pal[2]=qbg_palette_256[5];
pal[3]=qbg_palette_256[7];
}else{
pal[1]=qbg_palette_256[2];
pal[2]=qbg_palette_256[4];
pal[3]=qbg_palette_256[6];
}
}
return;
}
if (qbg_mode==0){
if (passed&1) if ((col1>31)||(col1<0)) goto qbg_sub_color_error;
if (passed&2) if ((col2>7)||(col2<0)) goto qbg_sub_color_error;
if (passed&1) qbg_color=col1;
if (passed&2) qbg_background_color=col2;
return;
}
qbg_sub_color_error:
MessageBox(NULL,"Illegal Function Call","ERROR!",MB_OK);//ERROR!
return;
}


void validate_video_page(long pagenumber){
static long i,i2;
static unsigned char *c;
if (pagenumber>=qbg_pages){
i=pagenumber+1;//i=indexes needed
qbg_pageoffsets=(unsigned long*)realloc(qbg_pageoffsets,i*4);
qbg_cursor_x_previous=(long*)realloc(qbg_cursor_x_previous,i*4);
qbg_cursor_y_previous=(long*)realloc(qbg_cursor_y_previous,i*4);
//clear top of realloc'd arrays
for (i=qbg_pages;i<=pagenumber;i++){
qbg_pageoffsets[i]=NULL;
qbg_cursor_x_previous[i]=0; qbg_cursor_y_previous[i]=0;
}
qbg_pages=pagenumber+1;
//clear new video page
if (qbg_mode==0){
i2=qbg_width_in_characters*qbg_height_in_characters*2;
qbg_pageoffsets[pagenumber]=(unsigned long)malloc(i2);
c=(unsigned char*)qbg_pageoffsets[pagenumber];
for (i=0;i<i2;i+=2){c[i]=32; c[i+1]=7;}
}else{
qbg_pageoffsets[pagenumber]=(unsigned long)calloc(qbg_width*qbg_height*qbg_bytes_per_pixel,1);
}
}//pagenumber>=qbg_pages
return;
}

void select_default_colors(){
qbg_color=15; qbg_background_color=0;
if (qbg_mode==0){qbg_color=7; qbg_background_color=0;}
if (qbg_mode==1){qbg_color=3; qbg_background_color=0;}
if (qbg_mode==2){qbg_color=1; qbg_background_color=0;}
if (qbg_mode==10){qbg_color=3; qbg_background_color=0;}
if (qbg_mode==11){qbg_color=1; qbg_background_color=0;}
return;
}


//############### SCREEN SUBS/FUNCTIONS BEGIN HERE
void qbg_screen(long mode,long color_switch,long active_page,long visual_page,long passed){
long i;

//PRE-ERROR CHECKING
//check if anything has changed, if not simply return
i=0;
if (passed&1){
if (qbg_mode!=mode) i=1;
if (mode<0) goto error;
if (mode==3) goto error;
if (mode==4) goto error;
if (mode==5) goto error;
if (mode==6) goto error;
if (mode>13) goto error;
}
if (passed&4){
if (qbg_active_page!=active_page) i=1;
if (active_page<0) goto error;
 if ((passed&8)==0){//if visual page not specified it is assumed to be the active page!
 passed+=8;
 visual_page=active_page;
 }
}
if (passed&8){
if (qbg_visual_page!=visual_page) i=1;
if (visual_page<0) goto error;
}
if (i==0) return;















//assume a standard mode


//change to new mode
if (passed&1){
if (mode!=qbg_mode){


if (full_screen_in_use){
SDL_FillRect(screen,NULL,0);//clear screen
}


//...remove old mode's data...
//...clear A000-C800
//memset(&cmem[655360],0,819200-655360);

//mode=13;
//qbg_width_in_characters=40; qbg_height_in_characters=43;

/*
Screen 13
  � 320 x 200 graphics
  � 40 x 25 text format, character box size of 8 x 8
  � Assignment of up to 256K colors to up to 256 attributes
*/
if (mode==13){
qbg_mode=13;
qbg_text_only=0;
//text & graphics modes
qbg_height_in_characters=25; qbg_width_in_characters=40;
qbg_top_row=1; qbg_bottom_row=24;
qbg_cursor_x=1; qbg_cursor_y=1;
qbg_character_height=8; qbg_character_width=8;
qbg_color=15; qbg_background_color=0;
//text mode ONLY
qbg_cursor_show=0;
qbg_cursor_firstvalue=0; qbg_cursor_lastvalue=0;//these values need revision
//graphics modes ONLY
qbg_width=320; qbg_height=200;
qbg_x=160; qbg_y=100;
qbg_bits_per_pixel=8; qbg_pixel_mask=0xFF; //for monochrome modes 1b, for 16 color 1111b, for 256 color 11111111b
qbg_bytes_per_pixel=1;
qbg_clipping_or_scaling=0;//1=clipping, 2=clipping and scaling
qbg_view_x1=0; qbg_view_y1=0; qbg_view_x2=319; qbg_view_y2=199;
qbg_view_offset_x=0; qbg_view_offset_y=0;
qbg_scaling_x=1; qbg_scaling_y=1;
qbg_scaling_offset_x=0; qbg_scaling_offset_y=0;
qbg_window_x1=0; qbg_window_y1=0; qbg_window_x2=319; qbg_window_y2=199;
qbg_pageoffsets=(unsigned long*)calloc(qbg_pages=1,4);
qbg_cursor_x_previous=(long*)calloc(qbg_pages,4); qbg_cursor_y_previous=(long*)calloc(qbg_pages,4);
qbg_active_page=0;
qbg_active_page_offset=&cmem[655360];
qbg_visual_page=0;
qbg_visual_page_offset=&cmem[655360];
qbg_restorepalette();
qbg_pageoffsets[0]=(unsigned long)&cmem[655360];
memset(qbg_active_page_offset,0,64000);
}//13

/*
Screen 12
  � 640 x 480 graphics
  � 80 x 30 or 80 x 60 text format, character box size of 8 x 16 or 8 x 8
  � Assignment of up to 256K colors to 16 attributes
  � VGA required
*/
if (mode==12){
qbg_mode=12;
qbg_text_only=0;
//text & graphics modes
if ((qbg_width_in_characters==80)&&(qbg_height_in_characters==60)){
qbg_height_in_characters=60; qbg_width_in_characters=80; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=8; qbg_character_width=8;
}else{
qbg_height_in_characters=30; qbg_width_in_characters=80; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=16; qbg_character_width=8;
}
qbg_cursor_x=1; qbg_cursor_y=1;
qbg_color=15; qbg_background_color=0;
//text mode ONLY
qbg_cursor_show=0;
qbg_cursor_firstvalue=0; qbg_cursor_lastvalue=0;//these values need revision
//graphics modes ONLY
qbg_width=640; qbg_height=480;
qbg_x=320; qbg_y=240;
qbg_bits_per_pixel=4; qbg_pixel_mask=0xF; //for monochrome modes 1b, for 16 color 1111b, for 256 color 11111111b
qbg_bytes_per_pixel=1;
qbg_clipping_or_scaling=0;//1=clipping, 2=clipping and scaling
qbg_view_x1=0; qbg_view_y1=0; qbg_view_x2=qbg_width-1; qbg_view_y2=qbg_height-1;
qbg_view_offset_x=0; qbg_view_offset_y=0;
qbg_scaling_x=1; qbg_scaling_y=1;
qbg_scaling_offset_x=0; qbg_scaling_offset_y=0;
qbg_window_x1=0; qbg_window_y1=0; qbg_window_x2=qbg_width-1; qbg_window_y2=qbg_height-1;
qbg_pageoffsets=(unsigned long*)calloc(qbg_pages=1,4);
qbg_cursor_x_previous=(long*)calloc(qbg_pages,4); qbg_cursor_y_previous=(long*)calloc(qbg_pages,4);
qbg_pageoffsets[0]=(unsigned long)calloc(307200,1);
qbg_active_page=0;
qbg_active_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_visual_page=0;
qbg_visual_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_restorepalette();
}//12

/*
Screen 11
  � 640 x 480 graphics
  � 80 x 30 or 80 x 60 text format, character box size of 8 x 16 or 8 x 8
  � Assignment of up to 256K colors to 2 attributes
*/
if (mode==11){
qbg_mode=11;
qbg_text_only=0;
//text & graphics modes
if ((qbg_width_in_characters==80)&&(qbg_height_in_characters==60)){
qbg_height_in_characters=60; qbg_width_in_characters=80; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=8; qbg_character_width=8;
}else{
qbg_height_in_characters=30; qbg_width_in_characters=80; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=16; qbg_character_width=8;
}
qbg_cursor_x=1; qbg_cursor_y=1;
qbg_color=1; qbg_background_color=0;
//text mode ONLY
qbg_cursor_show=0;
qbg_cursor_firstvalue=0; qbg_cursor_lastvalue=0;//these values need revision
//graphics modes ONLY
qbg_width=640; qbg_height=480;
qbg_x=320; qbg_y=240;
qbg_bits_per_pixel=4; qbg_pixel_mask=1; //for monochrome modes 1b, for 16 color 1111b, for 256 color 11111111b
qbg_bytes_per_pixel=1;
qbg_clipping_or_scaling=0;//1=clipping, 2=clipping and scaling
qbg_view_x1=0; qbg_view_y1=0; qbg_view_x2=qbg_width-1; qbg_view_y2=qbg_height-1;
qbg_view_offset_x=0; qbg_view_offset_y=0;
qbg_scaling_x=1; qbg_scaling_y=1;
qbg_scaling_offset_x=0; qbg_scaling_offset_y=0;
qbg_window_x1=0; qbg_window_y1=0; qbg_window_x2=qbg_width-1; qbg_window_y2=qbg_height-1;
qbg_pageoffsets=(unsigned long*)calloc(qbg_pages=1,4);
qbg_cursor_x_previous=(long*)calloc(qbg_pages,4); qbg_cursor_y_previous=(long*)calloc(qbg_pages,4);
qbg_pageoffsets[0]=(unsigned long)calloc(307200,1);
qbg_active_page=0;
qbg_active_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_visual_page=0;
qbg_visual_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_restorepalette();
}//11

//SCREEN 10: 640 x 350 graphics, monochrome monitor only
//  � 80 x 25 or 80 x 43 text format, 8 x 14 or 8 x 8 character box size
//  � 128K page size, page range is 0 (128K) or 0-1 (256K)
//  � Up to 9 pseudocolors assigned to 4 attributes
/*
'colors swap every half second!
'using PALETTE does NOT swap color indexes
'0 black-black
'1 black-grey
'2 black-white
'3 grey-black
'4 grey-grey
'5 grey-white
'6 white-black
'7 white-grey
'8 white-white
'*IMPORTANT* QB sets initial values up different to default palette!
'0 block-black(0)
'1 grey-grey(4)
'2 white-black(6)
'3 white-white(8)
*/
if (mode==10){
qbg_mode=10;
qbg_text_only=0;
//text & graphics modes
if ((qbg_width_in_characters==80)&&(qbg_height_in_characters==43)){
qbg_height_in_characters=43; qbg_width_in_characters=80; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=8; qbg_character_width=8;
}else{
qbg_height_in_characters=25; qbg_width_in_characters=80; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=14; qbg_character_width=8;
}
qbg_cursor_x=1; qbg_cursor_y=1;
qbg_color=3; qbg_background_color=0;
//text mode ONLY
qbg_cursor_show=0;
qbg_cursor_firstvalue=0; qbg_cursor_lastvalue=0;//these values need revision
//graphics modes ONLY
qbg_width=640; qbg_height=350;
qbg_x=320; qbg_y=175;
qbg_bits_per_pixel=2; qbg_pixel_mask=3; //for monochrome modes 1b, for 16 color 1111b, for 256 color 11111111b
qbg_bytes_per_pixel=1;
qbg_clipping_or_scaling=0;//1=clipping, 2=clipping and scaling
qbg_view_x1=0; qbg_view_y1=0; qbg_view_x2=qbg_width-1; qbg_view_y2=qbg_height-1;
qbg_view_offset_x=0; qbg_view_offset_y=0;
qbg_scaling_x=1; qbg_scaling_y=1;
qbg_scaling_offset_x=0; qbg_scaling_offset_y=0;
qbg_window_x1=0; qbg_window_y1=0; qbg_window_x2=qbg_width-1; qbg_window_y2=qbg_height-1;
qbg_pageoffsets=(unsigned long*)calloc(qbg_pages=2,4);
qbg_cursor_x_previous=(long*)calloc(qbg_pages,4); qbg_cursor_y_previous=(long*)calloc(qbg_pages,4);
qbg_pageoffsets[0]=(unsigned long)calloc(224000,1);
qbg_pageoffsets[1]=(unsigned long)calloc(224000,1);
qbg_active_page=0;
qbg_active_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_visual_page=0;
qbg_visual_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_restorepalette();
}//10

/*
SCREEN 9: 640 x 350 graphics
  � 80 x 25 or 80 x 43 text format, 8 x 14 or 8 x 8 character box size
  � 64K page size, page range is 0 (64K);
    128K page size, page range is 0 (128K) or 0-1 (256K)
  � 16 colors assigned to 4 attributes (64K adapter memory), or
    64 colors assigned to 16 attributes (more than 64K adapter memory)
*/
if (mode==9){
qbg_mode=9;
qbg_text_only=0;
//text & graphics modes
if ((qbg_width_in_characters==80)&&(qbg_height_in_characters==43)){
qbg_height_in_characters=43; qbg_width_in_characters=80; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=8; qbg_character_width=8;
}else{
qbg_height_in_characters=25; qbg_width_in_characters=80; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=14; qbg_character_width=8;
}
qbg_cursor_x=1; qbg_cursor_y=1;
qbg_color=15; qbg_background_color=0;
//text mode ONLY
qbg_cursor_show=0;
qbg_cursor_firstvalue=0; qbg_cursor_lastvalue=0;//these values need revision
//graphics modes ONLY
qbg_width=640; qbg_height=350;
qbg_x=320; qbg_y=175;
qbg_bits_per_pixel=4; qbg_pixel_mask=0xF; //for monochrome modes 1b, for 16 color 1111b, for 256 color 11111111b
qbg_bytes_per_pixel=1;
qbg_clipping_or_scaling=0;//1=clipping, 2=clipping and scaling
qbg_view_x1=0; qbg_view_y1=0; qbg_view_x2=qbg_width-1; qbg_view_y2=qbg_height-1;
qbg_view_offset_x=0; qbg_view_offset_y=0;
qbg_scaling_x=1; qbg_scaling_y=1;
qbg_scaling_offset_x=0; qbg_scaling_offset_y=0;
qbg_window_x1=0; qbg_window_y1=0; qbg_window_x2=qbg_width-1; qbg_window_y2=qbg_height-1;
qbg_pageoffsets=(unsigned long*)calloc(qbg_pages=1,4);
qbg_cursor_x_previous=(long*)calloc(qbg_pages,4); qbg_cursor_y_previous=(long*)calloc(qbg_pages,4);
qbg_pageoffsets[0]=(unsigned long)calloc(224000,1);
qbg_active_page=0;
qbg_active_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_visual_page=0;
qbg_visual_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_restorepalette();
}//9





/*
SCREEN 8: 640 x 200 graphics
  � 80 x 25 text format, 8 x 8 character box
  � 64K page size, page ranges are 0 (64K), 0-1 (128K), or 0-3 (246K)
  � Assignment of 16 colors to any of 16 attributes
*/
if (mode==8){
qbg_mode=8;
qbg_text_only=0;
//text & graphics modes
qbg_height_in_characters=25; qbg_width_in_characters=80; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=8; qbg_character_width=8;
qbg_cursor_x=1; qbg_cursor_y=1;
qbg_color=15; qbg_background_color=0;
//text mode ONLY
qbg_cursor_show=0;
qbg_cursor_firstvalue=0; qbg_cursor_lastvalue=0;//these values need revision
//graphics modes ONLY
qbg_width=640; qbg_height=200;
qbg_x=320; qbg_y=100;
qbg_bits_per_pixel=4; qbg_pixel_mask=0xF; //for monochrome modes 1b, for 16 color 1111b, for 256 color 11111111b
qbg_bytes_per_pixel=1;
qbg_clipping_or_scaling=0;//1=clipping, 2=clipping and scaling
qbg_view_x1=0; qbg_view_y1=0; qbg_view_x2=qbg_width-1; qbg_view_y2=qbg_height-1;
qbg_view_offset_x=0; qbg_view_offset_y=0;
qbg_scaling_x=1; qbg_scaling_y=1;
qbg_scaling_offset_x=0; qbg_scaling_offset_y=0;
qbg_window_x1=0; qbg_window_y1=0; qbg_window_x2=qbg_width-1; qbg_window_y2=qbg_height-1;
qbg_pageoffsets=(unsigned long*)calloc(qbg_pages=1,4);
qbg_cursor_x_previous=(long*)calloc(qbg_pages,4); qbg_cursor_y_previous=(long*)calloc(qbg_pages,4);
qbg_pageoffsets[0]=(unsigned long)calloc(128000,1);
qbg_active_page=0;
qbg_active_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_visual_page=0;
qbg_visual_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_restorepalette();
}//8



/*
SCREEN 7: 320 x 200 graphics
  � 40 x 25 text format, character box size 8 x 8
  � 32K page size, page ranges are 0-1 (64K), 0-3 (128K), or 0-7 (256K)
  � Assignment of 16 colors to any of 16 attributes
*/
if (mode==7){
qbg_mode=7;
qbg_text_only=0;
//text & graphics modes
qbg_height_in_characters=25; qbg_width_in_characters=40; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=8; qbg_character_width=8;
qbg_cursor_x=1; qbg_cursor_y=1;
qbg_color=15; qbg_background_color=0;
//text mode ONLY
qbg_cursor_show=0;
qbg_cursor_firstvalue=0; qbg_cursor_lastvalue=0;//these values need revision
//graphics modes ONLY
qbg_width=320; qbg_height=200;
qbg_x=160; qbg_y=100;
qbg_bits_per_pixel=4; qbg_pixel_mask=0xF; //for monochrome modes 1b, for 16 color 1111b, for 256 color 11111111b
qbg_bytes_per_pixel=1;
qbg_clipping_or_scaling=0;//1=clipping, 2=clipping and scaling
qbg_view_x1=0; qbg_view_y1=0; qbg_view_x2=qbg_width-1; qbg_view_y2=qbg_height-1;
qbg_view_offset_x=0; qbg_view_offset_y=0;
qbg_scaling_x=1; qbg_scaling_y=1;
qbg_scaling_offset_x=0; qbg_scaling_offset_y=0;
qbg_window_x1=0; qbg_window_y1=0; qbg_window_x2=qbg_width-1; qbg_window_y2=qbg_height-1;
qbg_pageoffsets=(unsigned long*)calloc(qbg_pages=1,4);
qbg_cursor_x_previous=(long*)calloc(qbg_pages,4); qbg_cursor_y_previous=(long*)calloc(qbg_pages,4);
qbg_pageoffsets[0]=(unsigned long)calloc(64000,1);
qbg_active_page=0;
qbg_active_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_visual_page=0;
qbg_visual_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_restorepalette();
}//7

/*
SCREEN 4:
  � Supports Olivetti (R) Personal Computers models M24, M240, M28,
    M280, M380, M380/C, M380/T and AT&T (R) Personal Computers 6300
    series
  � 640 x 400 graphics
  � 80 x 25 text format, 8 x 16 character box
  � 1 of 16 colors assigned as the foreground color (selected by the
    COLOR statement); background is fixed at black.
*/
//Note: QB64 will not support SCREEN 4

/*
SCREEN 3: Hercules adapter required, monochrome monitor only
  � 720 x 348 graphics
  � 80 x 25 text format, 9 x 14 character box
  � 2 screen pages (1 only if a second display adapter is installed)
  � PALETTE statement not supported
*/
//Note: QB64 will not support SCREEN 3

/*
SCREEN 2: 640 x 200 graphics
  � 80 x 25 text format with character box size of 8 x 8
  � 16 colors assigned to 2 attributes with EGA or VGA
*/
if (mode==2){
qbg_mode=2;
qbg_text_only=0;
//text & graphics modes
qbg_height_in_characters=25; qbg_width_in_characters=80; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=8; qbg_character_width=8;
qbg_cursor_x=1; qbg_cursor_y=1;
qbg_color=1; qbg_background_color=0;
//text mode ONLY
qbg_cursor_show=0;
qbg_cursor_firstvalue=0; qbg_cursor_lastvalue=0;//these values need revision
//graphics modes ONLY
qbg_width=640; qbg_height=200;
qbg_x=320; qbg_y=100;
qbg_bits_per_pixel=1; qbg_pixel_mask=0x1; //for monochrome modes 1b, for 16 color 1111b, for 256 color 11111111b
qbg_bytes_per_pixel=1;
qbg_clipping_or_scaling=0;//1=clipping, 2=clipping and scaling
qbg_view_x1=0; qbg_view_y1=0; qbg_view_x2=qbg_width-1; qbg_view_y2=qbg_height-1;
qbg_view_offset_x=0; qbg_view_offset_y=0;
qbg_scaling_x=1; qbg_scaling_y=1;
qbg_scaling_offset_x=0; qbg_scaling_offset_y=0;
qbg_window_x1=0; qbg_window_y1=0; qbg_window_x2=qbg_width-1; qbg_window_y2=qbg_height-1;
qbg_pageoffsets=(unsigned long*)calloc(qbg_pages=1,4);
qbg_cursor_x_previous=(long*)calloc(qbg_pages,4); qbg_cursor_y_previous=(long*)calloc(qbg_pages,4);
qbg_pageoffsets[0]=(unsigned long)calloc(128000,1);
qbg_active_page=0;
qbg_active_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_visual_page=0;
qbg_visual_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_restorepalette();
}//2

/*
SCREEN 1: 320 x 200 graphics
  � 40 x 25 text format, 8 x 8 character box
  � 16 background colors and one of two sets of 3 foreground colors assigned
    using COLOR statement with CGA
  � 16 colors assigned to 4 attributes with EGA or VGA
*/
if (mode==1){
qbg_mode=1;
qbg_text_only=0;
//text & graphics modes
qbg_height_in_characters=25; qbg_width_in_characters=40; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=8; qbg_character_width=8;
qbg_cursor_x=1; qbg_cursor_y=1;
qbg_color=3; qbg_background_color=0;
//text mode ONLY
qbg_cursor_show=0;
qbg_cursor_firstvalue=0; qbg_cursor_lastvalue=0;//these values need revision
//graphics modes ONLY
qbg_width=320; qbg_height=200;
qbg_x=160; qbg_y=100;
qbg_bits_per_pixel=2; qbg_pixel_mask=3; //for monochrome modes 1b, for 16 color 1111b, for 256 color 11111111b
qbg_bytes_per_pixel=1;
qbg_clipping_or_scaling=0;//1=clipping, 2=clipping and scaling
qbg_view_x1=0; qbg_view_y1=0; qbg_view_x2=qbg_width-1; qbg_view_y2=qbg_height-1;
qbg_view_offset_x=0; qbg_view_offset_y=0;
qbg_scaling_x=1; qbg_scaling_y=1;
qbg_scaling_offset_x=0; qbg_scaling_offset_y=0;
qbg_window_x1=0; qbg_window_y1=0; qbg_window_x2=qbg_width-1; qbg_window_y2=qbg_height-1;
qbg_pageoffsets=(unsigned long*)calloc(qbg_pages=1,4);
qbg_cursor_x_previous=(long*)calloc(qbg_pages,4); qbg_cursor_y_previous=(long*)calloc(qbg_pages,4);
qbg_pageoffsets[0]=(unsigned long)calloc(64000,1);
qbg_active_page=0;
qbg_active_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_visual_page=0;
qbg_visual_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_restorepalette();
}//1

/*
                MDPA, CGA, EGA, or VGA Adapter Boards
SCREEN 0: Text mode only
  � Either 40 x 25, 40 x 43, 40 x 50, 80 x 25, 80 x 43, or 80 x 50 text format
    with 8 x 8 character box size (8 x 14, 9 x 14, or 9 x 16 with EGA or VGA)
  � 16 colors assigned to 2 attributes
  � 16 colors assigned to any of 16 attributes (with CGA or EGA)
  � 64 colors assigned to any of 16 attributes (with EGA or VGA)
*/
if (mode==0){
qbg_mode=0;
qbg_text_only=1;
//text & graphics modes

if ((qbg_width_in_characters==80)&&(qbg_height_in_characters==50)){
qbg_width_in_characters=80; qbg_height_in_characters=50; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=8; qbg_character_width=8;
i=8000;
goto qbg_mode0_width_acquired;
}
if ((qbg_width_in_characters==40)&&(qbg_height_in_characters==50)){
qbg_width_in_characters=40; qbg_height_in_characters=50; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=8; qbg_character_width=16;
i=4000;
goto qbg_mode0_width_acquired;
}
if ((qbg_width_in_characters==80)&&(qbg_height_in_characters==43)){
qbg_width_in_characters=80; qbg_height_in_characters=43; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=8; qbg_character_width=8;
i=6880;
goto qbg_mode0_width_acquired;
}
if ((qbg_width_in_characters==40)&&(qbg_height_in_characters==43)){
qbg_width_in_characters=40; qbg_height_in_characters=43; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=8; qbg_character_width=16;
i=3440;
goto qbg_mode0_width_acquired;
}
if ((qbg_width_in_characters==40)&&(qbg_height_in_characters==25)){
qbg_width_in_characters=40; qbg_height_in_characters=25; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=16; qbg_character_width=16;
i=2048;
goto qbg_mode0_width_acquired;
}
qbg_width_in_characters=80; qbg_height_in_characters=25; qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
qbg_character_height=16; qbg_character_width=8;
i=4096;
qbg_mode0_width_acquired:
qbg_cursor_x=1; qbg_cursor_y=1;
qbg_color=7; qbg_background_color=0;
//text mode ONLY
qbg_cursor_show=0; qbg_cursor_firstvalue=4; qbg_cursor_lastvalue=4;


//graphics modes ONLY
//N/A
/*
granularity from &HB800
4096 in 80x25
2048 in 40x25
6880 in 80x43 (80x43x2=6880)
3440 in 40x43 (40x43x2=3440)
8000 in 80x50 (80x50x2=8000)
4000 in 40x50 (40x50x2=4000)
*/
qbg_pageoffsets=(unsigned long*)calloc(qbg_pages=8,4);
qbg_cursor_x_previous=(long*)calloc(qbg_pages,4); qbg_cursor_y_previous=(long*)calloc(qbg_pages,4);
qbg_pageoffsets[0]=(unsigned long)&cmem[753664+i*0];
qbg_pageoffsets[1]=(unsigned long)&cmem[753664+i*1];
qbg_pageoffsets[2]=(unsigned long)&cmem[753664+i*2];
qbg_pageoffsets[3]=(unsigned long)&cmem[753664+i*3];
qbg_pageoffsets[4]=(unsigned long)&cmem[753664+i*4];
qbg_pageoffsets[5]=(unsigned long)&cmem[753664+i*5];
qbg_pageoffsets[6]=(unsigned long)&cmem[753664+i*6];
qbg_pageoffsets[7]=(unsigned long)&cmem[753664+i*7];
qbg_active_page=0;
qbg_active_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_visual_page=0;
qbg_visual_page_offset=(unsigned char*)qbg_pageoffsets[0];
qbg_restorepalette();
//clear video page memory using [32,7] words
for (i=0;i<65536;i+=2){cmem[753664+i]=32; cmem[753664+i+1]=7;}

}//0

}//setmode
}//passed MODE

if ((passed&4)&&(active_page!=qbg_active_page)){
	validate_video_page(active_page);
	qbg_cursor_x_previous[qbg_active_page]=qbg_cursor_x; qbg_cursor_y_previous[qbg_active_page]=qbg_cursor_y;
	if (qbg_cursor_x_previous[active_page]){
		qbg_cursor_x=qbg_cursor_x_previous[active_page]; qbg_cursor_y=qbg_cursor_y_previous[active_page];
	}else{
		qbg_cursor_x=1; qbg_cursor_y=1;
	}
	qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
	select_default_colors();
	qbg_active_page_offset=(unsigned char*)qbg_pageoffsets[active_page];
	qbg_active_page=active_page;
}

if ((passed&8)&&(visual_page!=qbg_visual_page)){
	validate_video_page(visual_page);
	qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters-1;
	select_default_colors();
	qbg_visual_page_offset=(unsigned char*)qbg_pageoffsets[visual_page];
	qbg_visual_page=visual_page;
}



return;
error:
MessageBox(NULL,"Illegal Function Call","ERROR!",MB_OK);//ERROR!
return;
}//qbg_screen (end)


void sub_pcopy(long sourcepage,long destpage){
if (sourcepage<0) goto error;
if (destpage<0) goto error;
validate_video_page(sourcepage);
validate_video_page(destpage);
if (qbg_mode==0){
memcpy((char*)qbg_pageoffsets[destpage],(char*)qbg_pageoffsets[sourcepage],qbg_height_in_characters*qbg_width_in_characters*2);
}else{
memcpy((char*)qbg_pageoffsets[destpage],(char*)qbg_pageoffsets[sourcepage],qbg_height*qbg_width*qbg_bytes_per_pixel);
}
return;
error:
MessageBox(NULL,"Illegal Function Call","ERROR!",MB_OK);
return;
}


void qbsub_width(long option,long value1,long value2,long passed){
long i;
//[{#|LPRINT}][?],[?]
if (option==0){//change screen width (no special override character encountered)
//FIX UP PASSED BEFORE GOING ANY FURTHER WITH THIS FUNCTION!!
if (!(passed&1)) value1=qbg_width_in_characters;
if (!(passed&2)) value2=qbg_height_in_characters;
if ((qbg_width_in_characters==value1)&&(qbg_height_in_characters==value2)) return;
//check validity of input
if ((qbg_mode==13)||(qbg_mode==7)||(qbg_mode==7)){
if ((value1!=40)||(value2!=25)) goto qbsub_width_error;
}
if ((qbg_mode==12)||(qbg_mode==11)){
if (value1!=80) goto qbsub_width_error;
if ((value2!=30)&&(value2!=60)) goto qbsub_width_error;
}
if ((qbg_mode==10)||(qbg_mode==9)){
if (value1!=80) goto qbsub_width_error;
if ((value2!=25)&&(value2!=43)) goto qbsub_width_error;
}
if ((qbg_mode==8)||(qbg_mode==2)){
if (value1!=80) goto qbsub_width_error;
if (value2!=25) goto qbsub_width_error;
}
if (qbg_mode==0){
if ((value1!=80)&&(value1!=40)) goto qbsub_width_error;
if ((value2!=50)&&(value2!=43)&&(value2!=25)) goto qbsub_width_error;
}
//input is valid, force a screenmode changing the value of the current screen mode
qbg_width_in_characters=value1; qbg_height_in_characters=value2;
i=qbg_mode;
qbg_mode=-1;
qbg_screen(i,0,0,0,1);
return;
qbsub_width_error:
//DUE TO AN ERROR IN QBASIC, IT CAN JUMP-BACK TO TEXT MODE
//QB64 WILL HANDLE THIS CONDITION IN THE SAME MANNER
if ((value1!=80)&&(value1!=40)) goto qbsub_width_error2;
if ((value2!=50)&&(value2!=43)&&(value2!=25)) goto qbsub_width_error2;
qbg_width_in_characters=value1; qbg_height_in_characters=value2;
i=qbg_mode;
qbg_mode=-1;
qbg_screen(i,0,0,0,1);
return;
qbsub_width_error2:
MessageBox(NULL,"Illegal Function Call","ERROR!",MB_OK);//ERROR!
return;
}

//file/device?
//...
//printer?
//...
}

void pset(long x,long y,unsigned long col){//does not clip!
if (qbg_bytes_per_pixel==1){
qbg_active_page_offset[y*qbg_width+x]=col&qbg_pixel_mask;
}else{
//...(requires real color support)
}
return;
}


void qb32_boxfill(float x1f,float y1f,float x2f,float y2f,unsigned long col){
static long x1,y1,x2,y2,i,width;
static unsigned char *p;

//resolve coordinates
if (qbg_clipping_or_scaling){
if (qbg_clipping_or_scaling==2){
x1=qbr_float_to_long(x1f*qbg_scaling_x+qbg_scaling_offset_x)+qbg_view_offset_x;
y1=qbr_float_to_long(y1f*qbg_scaling_y+qbg_scaling_offset_y)+qbg_view_offset_y;
x2=qbr_float_to_long(x2f*qbg_scaling_x+qbg_scaling_offset_x)+qbg_view_offset_x;
y2=qbr_float_to_long(y2f*qbg_scaling_y+qbg_scaling_offset_y)+qbg_view_offset_y;
}else{
x1=qbr_float_to_long(x1f)+qbg_view_offset_x; y1=qbr_float_to_long(y1f)+qbg_view_offset_y;
x2=qbr_float_to_long(x2f)+qbg_view_offset_x; y2=qbr_float_to_long(y2f)+qbg_view_offset_y;
}
}else{
x1=qbr_float_to_long(x1f); y1=qbr_float_to_long(y1f);
x2=qbr_float_to_long(x2f); y2=qbr_float_to_long(y2f);
}

//swap coordinates (if necessary)
if (x1>x2){i=x1; x1=x2; x2=i;}
if (y1>y2){i=y1; y1=y2; y2=i;}

//exit without rendering if necessary
if (x2<qbg_view_x1) return;
if (x1>qbg_view_x2) return;
if (y2<qbg_view_y1) return;
if (y1>qbg_view_y2) return;

//crop coordinates
if (x1<qbg_view_x1) x1=qbg_view_x1;
if (y1<qbg_view_y1) y1=qbg_view_y1;
if (x1>qbg_view_x2) x1=qbg_view_x2;
if (y1>qbg_view_y2) y1=qbg_view_y2;
if (x2<qbg_view_x1) x2=qbg_view_x1;
if (y2<qbg_view_y1) y2=qbg_view_y1;
if (x2>qbg_view_x2) x2=qbg_view_x2;
if (y2>qbg_view_y2) y2=qbg_view_y2;

//apply mask to color to avoid incorrect color values
col&=qbg_pixel_mask;

if (qbg_bytes_per_pixel==1){
width=x2-x1+1;
p=qbg_active_page_offset+y1*qbg_width+x1;
i=y2-y1+1;
loop1:
memset(p,col,width);
p+=qbg_width;
if (--i) goto loop1;
return;
}//==1

//?

}

void qb32_line(float x1f,float y1f,float x2f,float y2f,unsigned long col,unsigned long style){
static long x1,y1,x2,y2,l,l2,mi;
static float m;

//resolve coordinates
if (qbg_clipping_or_scaling){
if (qbg_clipping_or_scaling==2){
x1=qbr_float_to_long(x1f*qbg_scaling_x+qbg_scaling_offset_x)+qbg_view_offset_x;
y1=qbr_float_to_long(y1f*qbg_scaling_y+qbg_scaling_offset_y)+qbg_view_offset_y;
x2=qbr_float_to_long(x2f*qbg_scaling_x+qbg_scaling_offset_x)+qbg_view_offset_x;
y2=qbr_float_to_long(y2f*qbg_scaling_y+qbg_scaling_offset_y)+qbg_view_offset_y;
}else{
x1=qbr_float_to_long(x1f)+qbg_view_offset_x; y1=qbr_float_to_long(y1f)+qbg_view_offset_y;
x2=qbr_float_to_long(x2f)+qbg_view_offset_x; y2=qbr_float_to_long(y2f)+qbg_view_offset_y;
}
}else{
x1=qbr_float_to_long(x1f); y1=qbr_float_to_long(y1f);
x2=qbr_float_to_long(x2f); y2=qbr_float_to_long(y2f);
}

lineclip(x1,y1,x2,y2,qbg_view_x1,qbg_view_y1,qbg_view_x2,qbg_view_y2);

style=(style&65535)+(style<<16);
lineclip_skippixels&=15;
style=_lrotl(style,lineclip_skippixels);

if (lineclip_draw){
l=abs(lineclip_x1-lineclip_x2);
l2=abs(lineclip_y1-lineclip_y2);
if (l>l2){

//x-axis distance is larger
y1f=lineclip_y1;
if (l){//following only applies if drawing more than one pixel
m=((float)lineclip_y2-(float)lineclip_y1)/(float)l;
if (lineclip_x2>=lineclip_x1) mi=1; else mi=-1;//direction of change
}
l++;
while (l--){
if (y1f<0) lineclip_y1=y1f-0.5f; else lineclip_y1=y1f+0.5f;

if ((style=_lrotl(style,1))&1){
pset(lineclip_x1,lineclip_y1,col);
}

lineclip_x1+=mi;
y1f+=m;
}

}else{

//y-axis distance is larger
x1f=lineclip_x1;
if (l2){//following only applies if drawing more than one pixel
m=((float)lineclip_x2-(float)lineclip_x1)/(float)l2;
if (lineclip_y2>=lineclip_y1) mi=1; else mi=-1;//direction of change
}
l2++;
while (l2--){
if (x1f<0) lineclip_x1=x1f-0.5f; else lineclip_x1=x1f+0.5f;
if ((style=_lrotl(style,1))&1){
pset(lineclip_x1,lineclip_y1,col);
}
lineclip_y1+=mi;
x1f+=m;
}

}

}//lineclip_draw
return;
}


void sub_line(long step1,float x1,float y1,long step2,float x2,float y2,unsigned long col,long bf,unsigned long style,long passed){
//format: [{STEP}][(?,?)]-[{STEP}](?,?),[?],[{B|BF}],[?]
//                  1 2                  4            8

//adjust coordinates and qb graphics cursor position based on STEP
if (passed&1){
if (step1){x1=qbg_x+x1; y1=qbg_y+y1;}
qbg_x=x1; qbg_y=y1;
}
if (step2){x2=qbg_x+x2; y2=qbg_y+y2;}
qbg_x=x2; qbg_y=y2;

if (bf==0){//line
if ((passed&8)==0) style=0xFFFF;
if ((passed&4)==0) col=qbg_color;
qb32_line(x1,y1,x2,y2,col,style);
return;
}

if (bf==1){//rectangle
if ((passed&8)==0) style=0xFFFF;
if ((passed&4)==0) col=qbg_color;
qb32_line(x1,y1,x2,y1,col,style);
qb32_line(x2,y1,x2,y2,col,style);
qb32_line(x2,y2,x1,y2,col,style);
qb32_line(x1,y2,x1,y1,col,style);
return;
}

if (bf==2){//filled box
if ((passed&4)==0) col=qbg_color;
qb32_boxfill(x1,y1,x2,y2,col);
return;
}

}//sub_line





unsigned long point(long x,long y){//does not clip!
if (qbg_bytes_per_pixel==1){
return qbg_active_page_offset[y*qbg_width+x]&qbg_pixel_mask;
}else{
//...(requires real color support)
}
return NULL;
}


void qbg_pset(long step,float x,float y,unsigned long col,long passed){
static long x2,y2;
if (qbg_text_only) return;
//Special Format: [{STEP}](?,?),[?]
if (step){qbg_x+=x; qbg_y+=y;}else{qbg_x=x; qbg_y=y;}
if (!(passed&1)) col=qbg_color;
if (qbg_clipping_or_scaling){
if (qbg_clipping_or_scaling==2){
x2=qbr(qbg_x*qbg_scaling_x+qbg_scaling_offset_x)+qbg_view_offset_x;
y2=qbr(qbg_y*qbg_scaling_y+qbg_scaling_offset_y)+qbg_view_offset_y;
}else{
x2=qbr(qbg_x)+qbg_view_offset_x; y2=qbr(qbg_y)+qbg_view_offset_y;
}
if (x2>=qbg_view_x1){ if (x2<=qbg_view_x2){
if (y2>=qbg_view_y1){ if (y2<=qbg_view_y2){
 pset(x2,y2,col);
}}}}
return;
}else{
 x2=qbr(qbg_x); if (x2>=0){ if (x2<qbg_width){
 y2=qbr(qbg_y); if (y2>=0){ if (y2<qbg_height){
  pset(x2,y2,col);
 }}}}
}
return;
}

void printchr(unsigned char character){
unsigned short x,x2;
unsigned short y,y2;
unsigned char *cp;

if (!qbg_text_only){
if (qbg_character_width==8){

if (qbg_character_height==8){ 
cp=&charset8x8[character][0][0];
for (y=0;y<8;y++){
y2=(qbg_cursor_y-1)*8+y;
x2=(qbg_cursor_x-1)*8;
for (x=0;x<8;x++){
if (*cp){
pset (x2,y2,qbg_color);
}else{
pset (x2,y2,qbg_background_color);
}
cp++;
x2++;
}}
return;
}//height 8

if (qbg_character_height==16){ 
cp=&charset8x16[character][0][0];
for (y=0;y<16;y++){
y2=(qbg_cursor_y-1)*16+y;
x2=(qbg_cursor_x-1)*8;
for (x=0;x<8;x++){
if (*cp){
pset (x2,y2,qbg_color);
}else{
pset (x2,y2,qbg_background_color);
}
cp++;
x2++;
}}
return;
}//height 16

if (qbg_character_height==14){ 
cp=&charset8x16[character][1][0];
for (y=0;y<14;y++){
y2=(qbg_cursor_y-1)*14+y;
x2=(qbg_cursor_x-1)*8;
for (x=0;x<8;x++){
if (*cp){
pset (x2,y2,qbg_color);
}else{
pset (x2,y2,qbg_background_color);
}
cp++;
x2++;
}}
return;
}//height 14

}//width 8

}else{//text only

qbg_active_page_offset[((qbg_cursor_y-1)*qbg_width_in_characters+qbg_cursor_x-1)*2]=character;
qbg_active_page_offset[((qbg_cursor_y-1)*qbg_width_in_characters+qbg_cursor_x-1)*2+1]=(qbg_color&0xF)+qbg_background_color*16+(qbg_color&16)*8;



}//text only


}//printchr


void qbs_print (qbs* str,unsigned char newline){

unsigned long i,i2,newlineadded;
newlineadded=0;

for (i=0;i<str->len;i++){
newlineadded=0;

if (str->chr[i]==7){
PlaySound(".\\data\\beep.wav");
SDL_Delay(200);
goto qbs_print_skipchar;
}

if ((str->chr[i]==10)||(str->chr[i]==13)){
qbg_cursor_x=32767;//force new line
goto qbs_print_skipchar;
}

printchr(str->chr[i]);

qbg_cursor_x++;

qbs_print_skipchar:;

if (qbg_cursor_x>qbg_width_in_characters){
qbs_print_newline:
newlineadded=1;

if (qbg_cursor_y==qbg_height_in_characters) qbg_cursor_y=qbg_bottom_row;

qbg_cursor_y++;
qbg_cursor_x=1;



if (qbg_cursor_y>qbg_bottom_row){
//move screen space within view print up 1 row
//if (qbg_mode==13){

///memmove(&cmem[655360+(qbg_top_row-1)*2560],&cmem[655360+qbg_top_row*2560],(qbg_bottom_row-qbg_top_row)*2560);
///memset(&cmem[655360+(qbg_bottom_row-1)*2560],0,2560);
if (qbg_text_only){

memmove(qbg_active_page_offset+(qbg_top_row-1)*qbg_width_in_characters*2,
        qbg_active_page_offset+(qbg_top_row)*qbg_width_in_characters*2,
        (qbg_bottom_row-qbg_top_row)*qbg_width_in_characters*2);
for (i2=0;i2<qbg_width_in_characters;i2++){
qbg_active_page_offset[(qbg_bottom_row-1)*qbg_width_in_characters*2+i2*2]=32;
qbg_active_page_offset[(qbg_bottom_row-1)*qbg_width_in_characters*2+i2*2+1]=7;

}

}else{
memmove(qbg_active_page_offset+(qbg_top_row-1)*qbg_bytes_per_pixel*qbg_width*qbg_character_height,
        qbg_active_page_offset+qbg_top_row*qbg_bytes_per_pixel*qbg_width*qbg_character_height,
        (qbg_bottom_row-qbg_top_row)*qbg_bytes_per_pixel*qbg_width*qbg_character_height);
memset(qbg_active_page_offset+(qbg_bottom_row-1)*qbg_bytes_per_pixel*qbg_width*qbg_character_height,0,qbg_bytes_per_pixel*qbg_width*qbg_character_height);
}


//}

qbg_cursor_y=qbg_bottom_row;
}



}


}

//begin new line?
if (newline&&(!newlineadded)) {newline=0; goto qbs_print_newline;}

return;
}


long qbs_cleanup(unsigned long base,long passvalue){
while (qbs_tmp_list_nexti>base) { qbs_tmp_list_nexti--; if(qbs_tmp_list[qbs_tmp_list_nexti]!=0xFFFFFFFF)qbs_free((qbs*)qbs_tmp_list[qbs_tmp_list_nexti]); }//clear any temp. strings created
return passvalue;
}



void qbg_sub_window(long screen,float x1,float y1,float x2,float y2,long passed){
float i;
if (qbg_text_only) goto qbg_sub_window_error;
if ((!passed)&&screen) goto qbg_sub_window_error;//SCREEEN passed without any other arguements!
if (passed){
if (x1==x2) goto qbg_sub_window_error;
if (y1==y2) goto qbg_sub_window_error;
//sort so x1 & y1 contain the lower values
if (x1>x2){i=x1; x1=x2; x2=i;}
if (y1>y2){i=y1; y1=y2; y2=i;}
if (!screen){
i=y1; y1=y2; y2=i;
}
//Note: Window's coordinates are not based on prev. WINDOW values
qbg_clipping_or_scaling=2;
qbg_scaling_x=((float)(qbg_view_x2-qbg_view_x1))/(x2-x1);
qbg_scaling_y=((float)(qbg_view_y2-qbg_view_y1))/(y2-y1);
qbg_scaling_offset_x=-x1;//scaling offset should be applied before scaling
qbg_scaling_offset_y=-y1;
qbg_window_x1=x1; qbg_window_x2=x2; qbg_window_y1=y1; qbg_window_y2=y2;
if (x1==0){ if (y1==0){ if (x2==(qbg_width-1)){ if (y2==(qbg_height-1)){
if ((qbg_scaling_x==1)&&(qbg_scaling_y==1)){
if ((qbg_scaling_offset_x==0)&&(qbg_scaling_offset_y==0)){
goto qbg_sub_window_restore_default;
}
}
}}}}
return;
}else{
//restore default WINDOW coordinates
qbg_sub_window_restore_default:
qbg_clipping_or_scaling=1;
qbg_scaling_x=1;
qbg_scaling_y=1;
qbg_scaling_offset_x=0;
qbg_scaling_offset_y=0;
qbg_window_x1=0; qbg_window_x2=qbg_width-1; qbg_window_y1=0; qbg_window_y2=qbg_height-1;
if (qbg_view_x1==0){ if (qbg_view_y1==0){ if (qbg_view_x2==(qbg_width-1)){ if (qbg_view_y2==(qbg_height-1)){
if (qbg_view_offset_x==0){ if (qbg_view_offset_y==0){
qbg_clipping_or_scaling=0;
}}
}}}}
return;
}
qbg_sub_window_error:
MessageBox(NULL,"Illegal Function Call","ERROR!",MB_OK);//ERROR!
return;
}



void qbg_sub_view_print(long print,long topline,long bottomline,long passed){
//PRE-ERROR CHECKING
if (!(passed&1)){//topline and bottomline not passed
qbg_top_row=1; qbg_bottom_row=qbg_height_in_characters;
qbg_cursor_y=1; qbg_cursor_x=1;
return;
}
if (topline<=0) goto qbg_sub_view_print_error;
if (topline>qbg_height_in_characters) goto qbg_sub_view_print_error;
if (bottomline<topline) goto qbg_sub_view_print_error;
if (bottomline>qbg_height_in_characters) goto qbg_sub_view_print_error;
qbg_top_row=topline;
qbg_bottom_row=bottomline;
qbg_cursor_y=qbg_top_row;
qbg_cursor_x=1;
return;
qbg_sub_view_print_error:
MessageBox(NULL,"Illegal Function Call","ERROR!",MB_OK);//ERROR!
return;
}

void qbg_sub_view(long coords_relative_to_screen,long x1,long y1,long x2,long y2,long fillcolor,long bordercolor,long passed){
//format: [{SCREEN}][(?,?)-(?,?)],[?],[?]
//bordercolor draws a line AROUND THE OUTSIDE of the specified viewport
//the current WINDOW settings do not affect inputted x,y values
//the current VIEW settings do not affect inputted x,y values
//REMEMBER! Recalculate WINDOW values based on new viewport dimensions
long i;

//PRE-ERROR CHECKING
if (passed&1){
if (x1<0) goto qbg_sub_view_error;
if (x1>=qbg_width) goto qbg_sub_view_error;
if (y1<0) goto qbg_sub_view_error;
if (y1>=qbg_height) goto qbg_sub_view_error;
if (x2<0) goto qbg_sub_view_error;
if (x2>=qbg_width) goto qbg_sub_view_error;
if (y2<0) goto qbg_sub_view_error;
if (y2>=qbg_height) goto qbg_sub_view_error;
}else{
if (coords_relative_to_screen) goto qbg_sub_view_error;
if (passed&16) goto qbg_sub_view_error;
if (passed&32) goto qbg_sub_view_error;
}

if (passed&1){
//force x1,y1 to be the top left corner
if (x2<x1){i=x1;x1=x2;x2=i;}
if (y2<y1){i=y1;y1=y2;y2=i;}
qbg_view_x1=x1; qbg_view_y1=y1; qbg_view_x2=x2; qbg_view_y2=y2;
if (coords_relative_to_screen==0){
qbg_view_offset_x=x1; qbg_view_offset_y=y1;
}else{
qbg_view_offset_x=0; qbg_view_offset_y=0;
}
if (!qbg_clipping_or_scaling) qbg_clipping_or_scaling=1;
}else{
//no argurments passed
qbg_view_x1=0; qbg_view_y1=0; qbg_view_x2=qbg_width-1; qbg_view_y2=qbg_height-1;
qbg_view_offset_x=0; qbg_view_offset_y=0;
if (qbg_clipping_or_scaling==1) qbg_clipping_or_scaling=0;
}

//STUB! for box & border
//need line command to perform these

//recalculate window values based on new viewport (if necessary)
if (qbg_clipping_or_scaling==2){//WINDOW'ing in use
qbg_scaling_x=((float)(qbg_view_x2-qbg_view_x1))/(qbg_window_x2-qbg_window_x1);
qbg_scaling_y=((float)(qbg_view_y2-qbg_view_y1))/(qbg_window_y2-qbg_window_y1);
qbg_scaling_offset_x=-qbg_window_x1;//scaling offset should be applied before scaling
qbg_scaling_offset_y=-qbg_window_y1;
}
return;
qbg_sub_view_error:
MessageBox(NULL,"Illegal Function Call","ERROR!",MB_OK);//ERROR!
return;
}


void qbg_sub_locate(long row,long column,long cursor,long start,long stop,long passed){
//PRE-ERROR CHECKING
if (passed&1){
if (row<qbg_top_row) goto qbg_sub_locate_error;
if ((row!=qbg_height_in_characters)&&(row>qbg_bottom_row)) goto qbg_sub_locate_error;
}
if (passed&2){
if (column<1) goto qbg_sub_locate_error;
if (column>qbg_width_in_characters) goto qbg_sub_locate_error;
}
if (passed&4){
if (cursor<0) goto qbg_sub_locate_error;
if (cursor>1) goto qbg_sub_locate_error;
}
if (passed&8){
if (start<0) goto qbg_sub_locate_error;
if (start>31) goto qbg_sub_locate_error;
if (stop<0) goto qbg_sub_locate_error;
if (stop>31) goto qbg_sub_locate_error;
}
if (passed&1) qbg_cursor_y=row;
if (passed&2) qbg_cursor_x=column;
if (passed&4){
if (cursor) qbg_cursor_show=1; else qbg_cursor_show=0;
}
if (passed&8){
qbg_cursor_firstvalue=start;
qbg_cursor_lastvalue=stop;
}
return;
qbg_sub_locate_error:
MessageBox(NULL,"Illegal Function Call","ERROR!",MB_OK);//ERROR!
return;
}


//IDEAS!
//pasting from clipboard (via keyboard buffer)
//autocomplete. if you press enter with nothing for a number it puts a 0


long ISSTRING = 1073741824;
long ISFLOAT = 536870912;
long ISUNSIGNED = 268435456;
long ISPOINTER = 134217728;
long ISFIXEDLENGTH = 67108864; //only set for strings with pointer flag
long ISINCONVENTIONALMEMORY = 33554432;
long ISOFFSETINBITS = 16777216;

//input helper functions:
long hex2uint64_failed;
unsigned __int64 hex2uint64(qbs* h){
static unsigned __int64 result;
static long i,i2;
hex2uint64_failed=0;
result=0;
if (!h->len) return 0;//shouldn't be called with no arguements
if (h->chr[0]!=38){hex2uint64_failed=1; return 0;}//not "&"
if (h->len==1) return 0;//& received, but awaiting further input
if ((h->chr[1]!=72)&&(h->chr[1]!=104)){hex2uint64_failed=1; return 0;}//not "H" or "h"
if (h->len==2) return 0;//&H received, but awaiting further input
if (h->len>18){hex2uint64_failed=1; return 0;}//larger than __int64 can hold!!!
for (i=2;i<h->len;i++){
result<<=4;
i2=h->chr[i];
//          0  -      9             A  -      F             a  -      f
if ( ((i2>=48)&&(i2<=57)) || ((i2>=65)&&(i2<=70)) || ((i2>=97)&&(i2<=102)) ){
if (i2>=97) i2-=32;
if (i2>=65) i2-=7;
i2-=48;
//i2 is now a values between 0 and 15
result+=i2;
}else{hex2uint64_failed=1; return 0;}//invalid character
}//i
return result;
}

//input method (complex, calls other qbs functions)
const char *uint64_max[] =    {"18446744073709551615"};
const char *int64_max[] =     {"9223372036854775807"};
const char *int64_max_neg[] = {"9223372036854775808"};
const char *single_max[] = {"3402823"};
const char *single_max_neg[] = {"1401298"};
const char *double_max[] = {"17976931"};
const char *double_max_neg[] = {"4940656"};
unsigned char significant_digits[1024];
long num_significant_digits;
void *qbs_input_variableoffsets[257];
long qbs_input_variabletypes[257];
qbs *qbs_input_arguements[257];
long qbg_cursor_show_old;
void qbs_input(long numvariables,unsigned char newline){
unsigned long qbs_tmp_base=qbs_tmp_list_nexti;
qbg_cursor_show_old=qbg_cursor_show;
qbg_cursor_show=1;


long i,i2,i3,i4,i5,i6;
long addspaces;
addspaces=0;
qbs* inpstr=qbs_new(0,0);//not temp so must be freed
qbs* inpstr2=qbs_new(0,0);//not temp so must be freed
qbs* key=qbs_new(0,0);//not temp so must be freed
qbs* c=qbs_new(1,0);//not temp so must be freed

for (i=1;i<=numvariables;i++) qbs_input_arguements[i]=qbs_new(0,0);

//init all passed variables to 0 or ""
for (i=1;i<=numvariables;i++){

if (qbs_input_variabletypes[i]&ISSTRING){//STRING
if (((qbs*)qbs_input_variableoffsets[i])->fixed){
memset(((qbs*)qbs_input_variableoffsets[i])->chr,32,((qbs*)qbs_input_variableoffsets[i])->len);
}else{
((qbs*)qbs_input_variableoffsets[i])->len=0;
}
}

if ((qbs_input_variabletypes[i]&ISOFFSETINBITS)==0){//reg. numeric variable
memset(qbs_input_variableoffsets[i],0,(qbs_input_variabletypes[i]&511)>>3);
}

//bit referenced?

}//i




qbs_input_next:

long argn,firstchr,toomany;
toomany=0;
argn=1;
i=0;
i2=0;
qbs_input_arguements[1]->len=0;
firstchr=1;
qbs_input_sep_arg:
if (i<inpstr->len){

if (inpstr->chr[i]==44){//","
if (i2!=1){//not in the middle of a string
i2=0;
argn=argn+1;
if (argn>numvariables){toomany=1; goto qbs_input_sep_arg_done;}
qbs_input_arguements[argn]->len=0;
firstchr=1;
goto qbs_input_next_arg;
}
/*
if (qbs_input_arguements[argn]->len>=1){
if (qbs_input_arguements[argn]->chr[qbs_input_arguements[argn]->len-1]==34){//"
i2=0;
qbs_input_arguements[argn]->len--;
argn=argn+1;
if (argn>numvariables){toomany=1; goto qbs_input_sep_arg_done;}
qbs_input_arguements[argn]->len=0;
firstchr=1;
goto qbs_input_next_arg;
}
}
*/
}

if (inpstr->chr[i]==34){//"
if (firstchr){
i2=1;//requires closure
firstchr=0;
goto qbs_input_next_arg;
}
if (i2==1){
i2=2;
goto qbs_input_next_arg;
}
}

if (i2==2){
goto backspace;//INVALID! Cannot have any characters after a closed "..."
}

c->chr[0]=inpstr->chr[i];
qbs_set(qbs_input_arguements[argn],qbs_add(qbs_input_arguements[argn],c));
firstchr=0;
qbs_input_next_arg:;
i++;
goto qbs_input_sep_arg;
}
qbs_input_sep_arg_done:
if (toomany) goto backspace;

//validate current arguements
//ASSUME LEADING & TRALING SPACES REMOVED!
unsigned char valid;
unsigned char neg;
long completewith;
long l;
unsigned char *cp,*cp2;
unsigned __int64 max,max_neg,multiple,value;
unsigned __int64 hexvalue;



completewith=-1;
valid=1;
l=qbs_input_arguements[argn]->len;
cp=qbs_input_arguements[argn]->chr;
neg=0;

if ((qbs_input_variabletypes[argn]&ISSTRING)==0){
if ((qbs_input_variabletypes[argn]&ISFLOAT)==0){
if ((qbs_input_variabletypes[argn]&511)<=32){//cannot handle INTEGER64 variables using this method!
__int64 finalvalue;
//it's an integer variable!
finalvalue=0;
if (l==0){completewith=48; goto typechecked_integer;}
//calculate max & max_neg (i4 used to store number of bits)
i4=qbs_input_variabletypes[argn]&511;
max=1;
max<<=i4;
max--;
//check for hex
hexvalue=hex2uint64(qbs_input_arguements[argn]);
if (hex2uint64_failed==0){//it's a hex number, so handle differently
//IMPORTANT: A hexidecimal value can be considered signed/unsigned
if (hexvalue>max){valid=0; goto typechecked;}
//are there too many hex digits? (calc num of hex digits in i)
value=max;
i=0;
for (i2=1;i2<=16;i2++){
if (value&0xF) i=i2;
value>>=4;
}
if (l>(2+i)){valid=0; goto typechecked;}
if (l==1) completewith=72;//"H"
if (l==2) completewith=48;//"0"
finalvalue=hexvalue;
goto typechecked_integer;
}
//max currently contains the largest UNSIGNED value possible, adjust as necessary
if (qbs_input_variabletypes[argn]&ISUNSIGNED){ 
max_neg=0;
}else{
max>>=1;
max_neg=max+1;
}
//check for - sign
i2=0;
 if ((qbs_input_variabletypes[argn]&ISUNSIGNED)==0){ 
 if (cp[i2]==45){//"-"
 if (l==1) {completewith=48; goto typechecked_integer;}
 i2++; neg=1;
 }
 }
//after a leading 0 no other digits are possible, return an error if this is the case
if (cp[i2]==48){
if (l>(i2+1)){valid=0; goto typechecked;}
}
//scan the "number"...
multiple=1;
value=0;
for (i=l-1;i>=i2;i--){
i3=cp[i]-48;
if ((i3>=0)&&(i3<=9)){
value+=multiple*i3;
 if (qbs_input_variabletypes[argn]&ISUNSIGNED){ 
 if (value>max){valid=0; goto typechecked;}
 }else{
 if (neg){
 if (value>max_neg){valid=0; goto typechecked;}
 }else{
 if (value>max){valid=0; goto typechecked;}
 }
 }
}else{valid=0; goto typechecked;}
multiple*=10;
}//next i
if (neg) finalvalue=-value; else finalvalue=value;
typechecked_integer:
//set variable to finalvalue
if ((qbs_input_variabletypes[argn]&ISOFFSETINBITS)==0){//reg. numeric variable
memcpy(qbs_input_variableoffsets[argn],&finalvalue,(qbs_input_variabletypes[argn]&511)>>3);
}
goto typechecked;
}
}
}

if (qbs_input_variabletypes[argn]&ISSTRING){
if (((qbs*)qbs_input_variableoffsets[argn])->fixed){
if (l>((qbs*)qbs_input_variableoffsets[argn])->len) {valid=0; goto typechecked;}
}
qbs_set((qbs*)qbs_input_variableoffsets[argn],qbs_input_arguements[argn]);
goto typechecked;
}

//INTEGER64 type
//__int64 range:          �9223372036854775808 to  9223372036854775807
//unsigned __int64 range: 0                    to 18446744073709551615
if ((qbs_input_variabletypes[argn]&ISSTRING)==0){
if ((qbs_input_variabletypes[argn]&ISFLOAT)==0){
if ((qbs_input_variabletypes[argn]&511)==64){
if (l==0){completewith=48; *(__int64*)qbs_input_variableoffsets[argn]=0; goto typechecked;}
//check for hex
hexvalue=hex2uint64(qbs_input_arguements[argn]);
if (hex2uint64_failed==0){//it's a hex number, so handle differently
if (l==1) completewith=72;//"H"
if (l==2) completewith=48;//"0"
*(unsigned __int64*)qbs_input_variableoffsets[argn]=hexvalue;
goto typechecked;
}
//check for - sign
i2=0;
 if ((qbs_input_variabletypes[argn]&ISUNSIGNED)==0){ 
 if (cp[i2]==45){//"-"
 if (l==1) {completewith=48; *(__int64*)qbs_input_variableoffsets[argn]=0; goto typechecked;}
 i2++; neg=1;
 }
 }
//after a leading 0 no other digits are possible, return an error if this is the case
if (cp[i2]==48){
if (l>(i2+1)){valid=0; goto typechecked;}
}
//count how many digits are in the number
i4=0;
for (i=l-1;i>=i2;i--){
i3=cp[i]-48;
if ((i3<0)||(i3>9)) {valid=0; goto typechecked;}
i4++;
}//i
if (qbs_input_variabletypes[argn]&ISUNSIGNED){
if (i4<20) goto typechecked_int64;
if (i4>20) {valid=0; goto typechecked;}
cp2=(unsigned char*)uint64_max[0];
}else{
if (i4<19) goto typechecked_int64;
if (i4>19) {valid=0; goto typechecked;}
if (neg) cp2=(unsigned char*)int64_max_neg[0]; else cp2=(unsigned char*)int64_max[0];
}
//number of digits valid, but exact value requires checking
cp=qbs_input_arguements[argn]->chr;
for (i=0;i<i4;i++){
if (cp[i+i2]<cp2[i]) goto typechecked_int64;
if (cp[i+i2]>cp2[i]) {valid=0; goto typechecked;}
}
typechecked_int64:
//add character 0 to end to make it a null terminated string
c->chr[0]=0; qbs_set(qbs_input_arguements[argn],qbs_add(qbs_input_arguements[argn],c));
if (qbs_input_variabletypes[argn]&ISUNSIGNED){
sscanf((char*)qbs_input_arguements[argn]->chr,"%u",(unsigned __int64*)qbs_input_variableoffsets[argn]);
}else{
sscanf((char*)qbs_input_arguements[argn]->chr,"%d",(__int64*)qbs_input_variableoffsets[argn]);
}
goto typechecked;
}
}
}

//check ISFLOAT type?
//[-]9999[.]9999[E/D][+/-]99999
if (qbs_input_variabletypes[argn]&ISFLOAT){
static long digits_before_point;
static long digits_after_point;
static long zeros_after_point;
static long neg_power;
digits_before_point=0;
digits_after_point=0;
neg_power=0;
value=0;
zeros_after_point=0;
num_significant_digits=0;

//set variable to 0
if ((qbs_input_variabletypes[argn]&511)==32) *(float*)qbs_input_variableoffsets[argn]=0;
if ((qbs_input_variabletypes[argn]&511)==64) *(double*)qbs_input_variableoffsets[argn]=0;
if ((qbs_input_variabletypes[argn]&511)==256) *(long double*)qbs_input_variableoffsets[argn]=0;

//begin with a generic assessment, regardless of whether it is single, double or float
if (l==0){completewith=48; goto typechecked;}
//check for hex
hexvalue=hex2uint64(qbs_input_arguements[argn]);
if (hex2uint64_failed==0){//it's a hex number, so handle differently
if (l==1) completewith=72;//"H"
if (l==2) completewith=48;//"0"
//nb. because VC6 didn't support...
//error C2520: conversion from unsigned __int64 to double not implemented, use signed __int64
//I've implemented a work-around so correct values will be returned
static __int64 transfer;
transfer=0x7FFFFFFF;
transfer<<=32;
transfer|=0xFFFFFFFF;
while(hexvalue>transfer){
hexvalue-=transfer;
if ((qbs_input_variabletypes[argn]&511)==32) *(float*)qbs_input_variableoffsets[argn]+=transfer;
if ((qbs_input_variabletypes[argn]&511)==64) *(double*)qbs_input_variableoffsets[argn]+=transfer;
if ((qbs_input_variabletypes[argn]&511)==256) *(long double*)qbs_input_variableoffsets[argn]+=transfer;
}
transfer=hexvalue;
if ((qbs_input_variabletypes[argn]&511)==32) *(float*)qbs_input_variableoffsets[argn]+=transfer;
if ((qbs_input_variabletypes[argn]&511)==64) *(double*)qbs_input_variableoffsets[argn]+=transfer;
if ((qbs_input_variabletypes[argn]&511)==256) *(long double*)qbs_input_variableoffsets[argn]+=transfer;
goto typechecked;
}
//check for - sign
i2=0;
 if (cp[i2]==45){//"-"
 if (l==1) {completewith=48; goto typechecked;}
 i2++; neg=1;
 }
//if it starts with 0, it may only have one leading 0
if (cp[i2]==48){
if (l>(i2+1)){
i2++;
if (cp[i2]==46) goto decimal_point;
valid=0; goto typechecked;//expected a decimal point
//nb. of course, user could have typed D or E BUT there is no point
//    calculating 0 to the power of anything!
}else goto typechecked;//validate, as no other data is required
}
//scan digits before decimal place
for (i=i2;i<l;i++){
i3=cp[i];
if ((i3==68)||(i3==(68+32))||(i3==69)||(i3==(69+32))){//d,D,e,E?
if (i==i2){valid=0; goto typechecked;}//cannot begin with d,D,e,E!
i2=i;
goto exponent;
}
if (i3==46){i2=i; goto decimal_point;}//nb. it can begin with a decimal point!
i3-=48;
if ((i3<0)||(i3>9)){valid=0; goto typechecked;}
digits_before_point++;
//nb. because leading 0 is handled differently, all digits are significant
significant_digits[num_significant_digits]=i3+48; num_significant_digits++;
}
goto assess_float;
////////////////////////////////
decimal_point:;
i4=1;
if (i2==(l-1)) {completewith=48; goto assess_float;}
i2++;
for (i=i2;i<l;i++){
i3=cp[i];
if ((i3==68)||(i3==(68+32))||(i3==69)||(i3==(69+32))){//d,D,e,E?
if (num_significant_digits){
if (i==i2){valid=0; goto typechecked;}//cannot begin with d,D,e,E just after a decimal point!
i2=i;
goto exponent;
}
}
i3-=48;
if ((i3<0)||(i3>9)){valid=0; goto typechecked;}
if (i3) i4=0;
if (i4) zeros_after_point++;
digits_after_point++;
if ((num_significant_digits)||i3){
significant_digits[num_significant_digits]=i3+48; num_significant_digits++;
}
}//i
goto assess_float;
////////////////////////////////
exponent:;
//ban d/D for SINGLE precision input
if ((qbs_input_variabletypes[argn]&511)==32){//SINGLE
i3=cp[i2];
if ((i3==68)||(i3==(68+32))){//d/D
valid=0; goto typechecked;
}
}
//correct "D" notation for c++ scanf
i3=cp[i2];
if ((i3==68)||(i3==(68+32))){//d/D
cp[i2]=69;//"E"
}
if (i2==(l-1)) {completewith=48; goto assess_float;}
i2++;
//check for optional + or -
i3=cp[i2];
if (i3==45){//"-"
if (i2==(l-1)) {completewith=48; goto assess_float;}
neg_power=1;
i2++;
}
if (i3==43){//"+"
if (i2==(l-1)) {completewith=48; goto assess_float;}
i2++;
}
//nothing valid after a leading 0
if (cp[i2]==48){//0
if (l>(i2+1)) {valid=0; goto typechecked;}
}
multiple=1;
value=0;
for (i=l-1;i>=i2;i--){
i3=cp[i]-48;
if ((i3>=0)&&(i3<=9)){
value+=multiple*i3;
}else{
valid=0; goto typechecked;
}
multiple*=10;
}//i
//////////////////////////
assess_float:;
//nb. 0.???? means digits_before_point==0

if ((qbs_input_variabletypes[argn]&511)==32){//SINGLE
//QB:           �3.402823    E+38 to �1.401298    E-45
//WIKIPEDIA:    �3.4028234   E+38 to ?
//OTHER SOURCE: �3.402823466 E+38 to �1.175494351 E-38
if (neg_power) value=-value;
//special case->single 0 after point
if ((zeros_after_point==1)&&(digits_after_point==1)){
digits_after_point=0;
zeros_after_point=0;
}
//upper overflow check
//i. check that value doesn't consist solely of 0's
if (zeros_after_point>43){valid=0; goto typechecked;}//cannot go any further without reversal by exponent
if ((digits_before_point==0)&&(digits_after_point==zeros_after_point)) goto nooverflow_float;
//ii. calculate the position of the first WHOLE digit (in i)
i=digits_before_point;
if (!i) i=-zeros_after_point;
/*EXAMPLES:
1.0			i=1
12.0		i=2
0.1			i=0
0.01		i=-1
*/
i=i+value;//apply exponent
if (i>39){valid=0; goto typechecked;}
//nb. the above blocks the ability to type a long-long number and use a neg exponent
//    to validate it
//********IMPORTANT: if i==39 then the first 7 digits MUST be scanned!!!
if (i==39){
cp2=(unsigned char*)single_max[0];
i2=num_significant_digits;
if (i2>7) i2=7;
for (i3=0;i3<i2;i3++){
if (significant_digits[i3]>*cp2){valid=0; goto typechecked;}
if (significant_digits[i3]<*cp2) break;
cp2++;
}
}
//check for pointless levels of precision (eg. 1.21351273512653625116212!)
if (digits_after_point){
if (digits_before_point){
if ((digits_after_point+digits_before_point)>8){valid=0; goto typechecked;}
}else{
if ((digits_after_point-zeros_after_point)>8){valid=0; goto typechecked;}
}
}
//check for "under-flow"
if (i<-44){valid=0; goto typechecked;}
//********IMPORTANT: if i==-44 then the first 7 digits MUST be scanned!!!
if (i==-44){
cp2=(unsigned char*)single_max_neg[0];
i2=num_significant_digits;
if (i2>7) i2=7;
for (i3=0;i3<i2;i3++){
if (significant_digits[i3]<*cp2){valid=0; goto typechecked;}
if (significant_digits[i3]>*cp2) break;
cp2++;
}
}
nooverflow_float:;
c->chr[0]=0; qbs_set(qbs_input_arguements[argn],qbs_add(qbs_input_arguements[argn],c));
sscanf((char*)qbs_input_arguements[argn]->chr,"%f",(float*)qbs_input_variableoffsets[argn]);
goto typechecked;
}

if ((qbs_input_variabletypes[argn]&511)==64){//DOUBLE
//QB: Double (15-digit) precision �1.7976931 D+308 to �4.940656 D-324
//WIKIPEDIA:    �1.7976931348623157 D+308 to ???
//OTHER SOURCE: �1.7976931348623157 D+308 to �2.2250738585072014E-308



if (neg_power) value=-value;
//special case->single 0 after point
if ((zeros_after_point==1)&&(digits_after_point==1)){
digits_after_point=0;
zeros_after_point=0;
}
//upper overflow check
//i. check that value doesn't consist solely of 0's
if (zeros_after_point>322){valid=0; goto typechecked;}//cannot go any further without reversal by exponent
if ((digits_before_point==0)&&(digits_after_point==zeros_after_point)) goto nooverflow_double;
//ii. calculate the position of the first WHOLE digit (in i)
i=digits_before_point;
if (!i) i=-zeros_after_point;
i=i+value;//apply exponent
if (i>309){valid=0; goto typechecked;}
//nb. the above blocks the ability to type a long-long number and use a neg exponent
//    to validate it
//********IMPORTANT: if i==309 then the first 8 digits MUST be scanned!!!
if (i==309){
cp2=(unsigned char*)double_max[0];
i2=num_significant_digits;
if (i2>8) i2=8;
for (i3=0;i3<i2;i3++){
if (significant_digits[i3]>*cp2){valid=0; goto typechecked;}
if (significant_digits[i3]<*cp2) break;
cp2++;
}
}
//check for pointless levels of precision (eg. 1.21351273512653625116212!)
if (digits_after_point){
if (digits_before_point){
if ((digits_after_point+digits_before_point)>16){valid=0; goto typechecked;}
}else{
if ((digits_after_point-zeros_after_point)>16){valid=0; goto typechecked;}
}
}
//check for "under-flow"
if (i<-323){valid=0; goto typechecked;}
//********IMPORTANT: if i==-323 then the first 7 digits MUST be scanned!!!
if (i==-323){
cp2=(unsigned char*)double_max_neg[0];
i2=num_significant_digits;
if (i2>7) i2=7;
for (i3=0;i3<i2;i3++){
if (significant_digits[i3]<*cp2){valid=0; goto typechecked;}
if (significant_digits[i3]>*cp2) break;
cp2++;
}
}
nooverflow_double:;
c->chr[0]=0; qbs_set(qbs_input_arguements[argn],qbs_add(qbs_input_arguements[argn],c));
sscanf((char*)qbs_input_arguements[argn]->chr,"%lf",(double*)qbs_input_variableoffsets[argn]);
goto typechecked;
}

if ((qbs_input_variabletypes[argn]&511)==32){//FLOAT
//at present, there is no defined limit for FLOAT type numbers, so no restrictions
//are applied!
c->chr[0]=0; qbs_set(qbs_input_arguements[argn],qbs_add(qbs_input_arguements[argn],c));
sscanf((char*)qbs_input_arguements[argn]->chr,"%lf",(long double*)qbs_input_variableoffsets[argn]);
}

}//ISFLOAT

//undefined/uncheckable types fall through as valid!
typechecked:;
if (!valid) goto backspace;



qbs_set(inpstr2,inpstr);


//input a key



qbs_input_invalidinput:
if (qbg_mode!=0){
//draw special box cursor
{
long x,y,x2,y2;
y2=(qbg_cursor_y-1)*qbg_character_height;
for (y=0;y<qbg_character_height;y++){
x2=(qbg_cursor_x-1)*qbg_character_width;
for (x=0;x<qbg_character_width;x++){
pset (x2,y2,point(x2,y2)^qbg_color);
x2++;
}
y2++;
}
}
//end special box cursor
}

qbs_input_wait_for_key:
if (addspaces){
addspaces--;
c->chr[0]=32; qbs_set(key,c);
}else{
SDL_Delay(10);
qbs_set(key,qbs_inkey());
qbs_cleanup(qbs_tmp_base,0);
}
if (stop_program) return;

if (key->len!=1) goto qbs_input_wait_for_key;

if (qbg_mode!=0){
//remove special box cursor
{
long x,y,x2,y2;
y2=(qbg_cursor_y-1)*qbg_character_height;
for (y=0;y<qbg_character_height;y++){
x2=(qbg_cursor_x-1)*qbg_character_width;
for (x=0;x<qbg_character_width;x++){
pset (x2,y2,point(x2,y2)^qbg_color);
x2++;
}
y2++;
}
}
//end special box cursor
}



//input should disallow certain characters
if (key->chr[0]==7) {qbs_print(key,0); goto qbs_input_next;}//beep!
if (key->chr[0]==10) goto qbs_input_next;//linefeed
if (key->chr[0]==9){//tab
i=8-(inpstr2->len&7);
addspaces=i;
goto qbs_input_next;
}
//other ASCII chars that cannot be printed
if (key->chr[0]==11) goto qbs_input_next;
if (key->chr[0]==12) goto qbs_input_next;
if (key->chr[0]==28) goto qbs_input_next;
if (key->chr[0]==29) goto qbs_input_next;
if (key->chr[0]==30) goto qbs_input_next;
if (key->chr[0]==31) goto qbs_input_next;

if (key->chr[0]==13){
//assume input is valid

//autofinish (if necessary)

//assume all parts entered





//c->chr[0]=217;
//qbs_print(c,1);
for (i=1;i<=numvariables;i++){

/* depricated
if (qbs_input_variabletypes[i]==1){//STRING
qbs_set((qbs*)qbs_input_variableoffsets[i],qbs_input_arguements[i]);
}
if (qbs_input_variabletypes[i]==2){//INTEGER (signed)
c->chr[0]=0; qbs_set(qbs_input_arguements[i],qbs_add(qbs_input_arguements[i],c));
sscanf((char*)qbs_input_arguements[i]->chr,"%d",(short*)qbs_input_variableoffsets[i]);
}
*/


qbs_free(qbs_input_arguements[i]);
}

if (newline){
c->len=0;
qbs_print(c,1);
}
qbs_free(c);
qbs_free(inpstr);
qbs_free(inpstr2);
qbs_free(key);

qbg_cursor_show=qbg_cursor_show_old;
return;
}


if (key->chr[0]==8){//backspace
backspace:
if (!inpstr->len) goto qbs_input_invalidinput;//can't backspace!
//clear previous character from buffer
inpstr->len--;
//move cursor back (this may involve redisplaying prev. line)
qbg_cursor_x--;
if (!qbg_cursor_x){
qbg_cursor_x=qbg_width_in_characters;
if (qbg_cursor_y==qbg_top_row){
//recall up to screen-width-in-characters worth of data and display it right justified
//also clear the line

 
}else{
qbg_cursor_y--;
}
}

/*
long qbg_height_in_characters, qbg_width_in_characters;
long qbg_top_row, qbg_bottom_row;
long qbg_cursor_x, qbg_cursor_y;
*/
//clear character on screen
i=qbg_cursor_x; i2=qbg_cursor_y;
*c->chr=32;
qbs_print(c,0);
qbg_cursor_x=i; qbg_cursor_y=i2;


goto qbs_input_next;
}

if (inpstr2->len>=255) goto qbs_input_next;



//affect inpstr2 with key
qbs_set(inpstr2,qbs_add(inpstr2,key));

//check possible string after keypress for validity
//if valid keep it, otherwise discard it!
//(todo)

//process input (and validate)




//perform actual update
qbs_print(key,0);

//i=qbg_cursor_x; i2=qbg_cursor_y;
//*c->chr=219;
//qbs_print(c,0);
//qbg_cursor_x=i; qbg_cursor_y=i2;


qbs_set(inpstr,inpstr2);

goto qbs_input_next;




}


long H3C8_palette_register_index=0;
long H3C9_next=0;
long palette_register_index=0;
void sub_out(long port,long data){
port=port&65535;
data=data&255;
if (port==968){//&H3C8, set palette register index
H3C8_palette_register_index=data;
goto done;
}
if (port==969){//&H3C9, set palette color
data=data&63;
if (H3C9_next==0){//red
pal[H3C8_palette_register_index]&=0x00FFFF;
pal[H3C8_palette_register_index]+=(qbr((double)data*4.063492f-0.4999999f)<<16);
}
if (H3C9_next==1){//green
pal[H3C8_palette_register_index]&=0xFF00FF;
pal[H3C8_palette_register_index]+=(qbr((double)data*4.063492f-0.4999999f)<<8);
}
if (H3C9_next==2){//blue
pal[H3C8_palette_register_index]&=0xFFFF00;
pal[H3C8_palette_register_index]+=qbr((double)data*4.063492f-0.4999999f);
}
H3C9_next=H3C9_next+1;
if (H3C9_next==3){
H3C9_next=0;
H3C8_palette_register_index=H3C8_palette_register_index+1;
H3C8_palette_register_index&=0xFF;
}
goto done;
}

done:
return;
error:
MessageBox(NULL,"Illegal Function Call","ERROR!",MB_OK);
}

//ALERT: OLD RANDOM FORMULAS, MADE OBSELETE BY 100% QB/QB4.5 COMPAT. FORMULA!
//Sourced from: http://support.microsoft.com/kb/28150
/*
' To try this example in VBDOS.EXE:
' 1. From the File menu, choose New Project.
' 2. Copy the code example to the Code window.
' 3. Press F5 to run the program.
DEFDBL A-Z  ' Requires double-precision intermediate variables.
a = 214013
c = 2531011
z = 2 ^ 24
INPUT "Input any seed value: ", x0
FOR count = 1 TO 25   ' print 25 random numbers between 0.0 and 1.0:
  temp = x0 * a + c
' Calculate (temp MOD z) and assign to x1:
  temp = temp / z
  x1 = (temp - FIX(temp)) * z
' Print the result as value between 0.0000000 and 1.0000000:
  result = x1 / z
  PRINT result
' Reseed the calculation before the next iteration:
  x0 = x1   ' x0 and x1 range from 0 to 16777216 (2^24)
NEXT
*/
/*
double rnd_seed=0.0;
void sub_randomize (float seed,long passed){
if (passed){
if (seed<0) seed=((double)-1.0f)/seed;
rnd_seed=seed;
return;
}
qbs_print(qbs_new_txt("Random-number seed (-32768 to 32767)? "),0);
static unsigned short integerseed;
qbs_input_variabletypes[1]=2;
qbs_input_variableoffsets[1]=&integerseed;
qbs_input(1,1);
rnd_seed=integerseed;
return;
}
float func_rnd(float value){
static double a=214013.0;//multiplier
static double c=2531011.0;//added
static double z=16777216.0;//2^24
static double temp,x1;
static double l=0;
if (value==0){
return l;
}
if (value<0){
rnd_seed=-value;
}
temp=(rnd_seed*a+c)/z;
x1=((double)(temp-(__int64)temp))*z;
rnd_seed=x1;
return l=x1/z;
}
*/

unsigned long rnd_seed=327680;
void sub_randomize (double seed,long passed){
if (passed){
//Dim As Uinteger m = cptr(Uinteger Ptr, @n)[1]
static unsigned long m;
m=((unsigned long*)&seed)[1];
//m Xor= (m Shr 16)
m^=(m>>16);
//rnd_seed = (m And &hffff) Shl 8 Or (rnd_seed And &hff)
rnd_seed=((m&0xffff)<<8)|(rnd_seed&0xff);
return;
}
qbs_print(qbs_new_txt("Random-number seed (-32768 to 32767)? "),0);
static short integerseed;
qbs_input_variabletypes[1]=16;//id.t=16 'a signed 16 bit integer
qbs_input_variableoffsets[1]=&integerseed;
qbs_input(1,1);
//rnd_seed = (m And &hffff) Shl 8 Or (rnd_seed And &hff) 'nb. same as above
rnd_seed=((integerseed&0xffff)<<8)|(rnd_seed&0xff);
return;
}
float func_rnd(float n){
static unsigned long m;
if (n!=0.0){
if (n<0.0){
m=*((unsigned long*)&n);
rnd_seed=(m&0xFFFFFF)+((m&0xFF000000)>>24);
}
rnd_seed=(rnd_seed*16598013+12820163)&0xFFFFFF;
}     
return (double)rnd_seed/0x1000000;
}
/*
Function Rnd(Byval n As Single = 1) As Double   
    If n <> 0.0 Then       
        If n < 0.0 Then
            Dim As Uinteger m = *cptr(Uinteger Ptr, @n)
            rnd_seed = (m And &hffffff) + (m And &hff000000) Shr 24
        End If       
        rnd_seed = (rnd_seed * 16598013 + 12820163) And &hffffff       
    End If
    Function = rnd_seed / &h1000000   
End Function
*/







/*
I had a look at QBASIC's rnd function, and worked out how to write a function that replicated its behaviour, working out how it was seeded and how it generated a new seed from the old one. Turns out it has three quite different ways of seeding it. One uses singles, one uses doubles and one uses 16-bit integers.
#undef Randomize
#undef Rnd
Declare Sub Randomize overload (Byval n As Double)
Declare Sub Randomize
Declare Function Rnd(Byval n As Single = 1) As Double

Dim Shared rnd_seed As Uinteger = 327680

Sub Randomize overload (Byval n As Double)   
    Dim As Uinteger m = cptr(Uinteger Ptr, @n)[1]
    m Xor= (m Shr 16)
    rnd_seed = (m And &hffff) Shl 8 Or (rnd_seed And &hff)
End Sub
Sub Randomize()  
    Dim m As Integer
    Input "Random-number seed (-32768 to 32767)"; m
    rnd_seed = (m And &hffff) Shl 8 Or (rnd_seed And &hff)   
End Sub
Function Rnd(Byval n As Single = 1) As Double   
    If n <> 0.0 Then       
        If n < 0.0 Then
            Dim As Uinteger m = *cptr(Uinteger Ptr, @n)
            rnd_seed = (m And &hffffff) + (m And &hff000000) Shr 24
        End If       
        rnd_seed = (rnd_seed * 16598013 + 12820163) And &hffffff       
    End If
    Function = rnd_seed / &h1000000   
End Function
*/



















float func_timer(){
static unsigned long x;
static double d;
x=SDL_GetTicks();
x-=sdl_firsttimervalue;
x+=qb64_firsttimervalue;
//make timer value loop after midnight
//note: there are 86400000 milliseconds in 24hrs(1 day)
func_timer_fixoffset:
if (x>=86400000){
x-=86400000;
goto func_timer_fixoffset;
}
d=x;
//reduce accuracy to 18.2 "ticks" per second
d*=18.2;
d/=1000.0;
d=(unsigned long)d;//round
d/=18.2;
return (float)d;
}

void sub_sound(double frequency,double lengthinclockticks){
//note: there are 18.2 clock ticks per second
if (frequency<37.0) goto error;
if (frequency>32767.0) goto error;
if (lengthinclockticks<0.0) goto error;
if (lengthinclockticks>65535.0) goto error;
if (lengthinclockticks==0.0) return;
qb64_musicforeground=1;
qb64_generatesound(frequency,lengthinclockticks/18.2);
qb64_musicforeground=0;
return;
error:
MessageBox(NULL,"Illegal Function Call","ERROR!",MB_OK);
}


//QB MAIN THREAD
int QBMAIN(void *unused)
{
goto skipper;
program_finished:
iloop:
if (stop_program) return(0);
SDL_Delay(100);//100Hz
goto iloop;
skipper:

unsigned long qbs_tmp_base=qbs_tmp_list_nexti;

#include "maindata.txt"

#include "main.txt"
goto program_finished;
}

int main( int argc, char* argv[] )
{



//WINDOWS SPECIFIC CONTENT
HWND hWnd = GetConsoleWindow();
ShowWindow( hWnd, SW_HIDE ); 
//END WINDOWS SPECIFIC CONTENT

//#ifndef _TM_DEFINED
//struct tm {
//        int tm_sec;     /* seconds after the minute - [0,59] */
//        int tm_min;     /* minutes after the hour - [0,59] */
//        int tm_hour;    /* hours since midnight - [0,23] */
//        int tm_mday;    /* day of the month - [1,31] */
//        int tm_mon;     /* months since January - [0,11] */
//        int tm_year;    /* years since 1900 */
//        int tm_wday;    /* days since Sunday - [0,6] */
//        int tm_yday;    /* days since January 1 - [0,365] */
//        int tm_isdst;   /* daylight savings time flag */
//        };
tm *qb64_tm;
time_t qb64_tm_val;
time_t qb64_tm_val_old;
//call both timing routines as close as possible to each other to maximize accuracy
//wait for second "hand" to "tick over"/move
time(&qb64_tm_val_old);
do{
time(&qb64_tm_val);
}while(qb64_tm_val==qb64_tm_val_old);
sdl_firsttimervalue=SDL_GetTicks();
qb64_tm=localtime(&qb64_tm_val);
//calculate localtime as milliseconds past midnight
//TODO: WHEN TIMER IS CALLED IT MUST SOMETIMES FORCE THE VALUE TO LOOP
qb64_firsttimervalue=qb64_tm->tm_hour*3600+qb64_tm->tm_min*60+qb64_tm->tm_sec;
qb64_firsttimervalue*=1000;

//init. main() temporary variables
long i,i2,i3,i4;
unsigned char c,c2,c3,c4;
long x,x2,x3,x4;
long y,y2,y3,y4;
long z,z2,z3,z4;

memset(&cmem[0],0,sizeof(cmem));
memset(&keyon[0],0,sizeof(keyon));
dblock=(unsigned long)&cmem+1280;//0:500h

//init SDL
if ( SDL_Init(SDL_INIT_AUDIO|SDL_INIT_VIDEO|SDL_INIT_CDROM|SDL_INIT_TIMER) < 0 ) {
        fprintf(stderr, "Unable to init SDL: %s\n", SDL_GetError());
        exit(1);
    }

memset(&sounds[0],0,sizeof(sample)*256);

/* Set 16-bit stereo audio at 22Khz */
fmt.freq = 44100;
fmt.format = AUDIO_S16;
fmt.channels = 2;
fmt.samples = 4096;
fmt.callback = mixaudio;
fmt.userdata = NULL;
/* Open the audio device and start playing sound! */
if ( SDL_OpenAudio(&fmt, NULL) < 0 ) {
fprintf(stderr, "Unable to open audio: %s\n", SDL_GetError());
exit(1);
}



SDL_PauseAudio(0);

//set key repeat rate
SDL_EnableKeyRepeat(500,50);

//enable unicode
SDL_EnableUNICODE(1);

//init fake keyb. cyclic buffer
cmem[0x41a]=30; cmem[0x41b]=0; //head
cmem[0x41c]=30; cmem[0x41d]=0; //tail

SDL_WM_SetIcon(SDL_LoadBMP(".\\data\\qb64icon.bmp"), NULL);
SDL_WM_SetCaption("Untitled",NULL);

screen = SDL_SetVideoMode(320, 240, 32, SDL_SWSURFACE);//|SDL_FULLSCREEN); SDL_SWSURFACE
    if ( screen == NULL ) {
        fprintf(stderr, "Unable to set video mode: %s\n", SDL_GetError());
        exit(1);
    }
unsigned long *pixel;
pixel=(unsigned long*)screen->pixels;
//SDL_ShowCursor(0);

//SDL_Cursor * mycursor=SDL_CreateCursor
		//(Uint8 *data, Uint8 *mask, int w, int h, int hot_x, int hot_y);
SDL_Cursor * mycursor=init_system_cursor(arrow);
SDL_SetCursor(mycursor);

ifstream fh;

//load the default 256 color palette
fh.open (".\\data\\qb64.pal",ios::binary|ios::out|ios::in);
if (fh.is_open()){
fh.read((char*)&qbg_palette_256,256*4);
fh.close();
}

fh.open (".\\data\\qb64ega.pal",ios::binary|ios::out|ios::in);
if (fh.is_open()){
fh.read((char*)&qbg_palette_64,64*4);
fh.close();
}

//manually set screen 10 palette
pal_mode10[0][0]=0;
pal_mode10[0][1]=0;
pal_mode10[0][2]=0;
pal_mode10[0][3]=0x808080;
pal_mode10[0][4]=0x808080;
pal_mode10[0][5]=0x808080;
pal_mode10[0][6]=0xFFFFFF;
pal_mode10[0][7]=0xFFFFFF;
pal_mode10[0][8]=0xFFFFFF;
pal_mode10[1][0]=0;
pal_mode10[1][1]=0x808080;
pal_mode10[1][2]=0xFFFFFF;
pal_mode10[1][3]=0;
pal_mode10[1][4]=0x808080;
pal_mode10[1][5]=0xFFFFFF;
pal_mode10[1][6]=0;
pal_mode10[1][7]=0x808080;
pal_mode10[1][8]=0xFFFFFF;

//load the 8x8 character set
fh.open (".\\data\\charset8.raw",ios::binary|ios::out|ios::in);
if (fh.is_open()){
fh.read((char*)&charset8x8,256*8*8);
fh.close();
}
//load the 8x16 character set
fh.open (".\\data\\charset16.raw",ios::binary|ios::out|ios::in);
if (fh.is_open()){
fh.read((char*)&charset8x16,256*16*8);
fh.close();
}

qbg_screen(0,NULL,NULL,NULL,1);
SDL_Delay(100);//Delay required to prevent thread accessing func. at same time

SDL_Thread *thread;
    thread = SDL_CreateThread(QBMAIN, NULL);
    if ( thread == NULL ) {
        fprintf(stderr, "Unable to create thread: %s\n", SDL_GetError());
        return 0;
    }


unsigned long subsystem_timer_next=0;
subsystem_timer_next=SDL_GetTicks();
unsigned long newtime;

subsystem_loop:
newtime=SDL_GetTicks();
if (newtime<subsystem_timer_next){
SDL_Delay(subsystem_timer_next-newtime);
goto subsystem_loop;
}
subsystem_timer_next+=16;



program_wait=1;//reminds main proc that this is a good time to wait, esp. if this thread is doing
               //some processing (yet to be properly integrated)
qbevent=1;

//note: having trouble implementing this
//if (lock_subsystem==1){
//lock_subsystem=2;
//locked_subsystem_wait:
//SDL_Delay(10);
//if (lock_subsystem) goto locked_subsystem_wait;
//}

//screen 2 special formula!
if (qbg_mode==2){
if (full_screen){
 if ((qbg_program_window_width!=640)||(qbg_program_window_height!=480)||(full_screen_in_use!=full_screen)){
  qbg_program_window_width=640; qbg_program_window_height=480;
  screen = SDL_SetVideoMode(qbg_program_window_width, qbg_program_window_height, 32, SDL_SWSURFACE|(SDL_FULLSCREEN*full_screen));//|SDL_FULLSCREEN); SDL_SWSURFACE
  pixel=(unsigned long*)screen->pixels;
  full_screen_in_use=full_screen;
 }
}else{
 if ((qbg_program_window_width!=640)||(qbg_program_window_height!=400)||(full_screen_in_use!=full_screen)){
  qbg_program_window_width=640; qbg_program_window_height=400;
  screen = SDL_SetVideoMode(qbg_program_window_width, qbg_program_window_height, 32, SDL_SWSURFACE|(SDL_FULLSCREEN*full_screen));//|SDL_FULLSCREEN); SDL_SWSURFACE
  pixel=(unsigned long*)screen->pixels;
  full_screen_in_use=full_screen;
 }
}


unsigned char *cp;
unsigned long *lp;
cp=qbg_visual_page_offset;
lp=pixel;
i2=qbg_program_window_width*qbg_program_window_height;
if (full_screen) {lp=lp+25600; i2=640*400;}
i3=0;
for (i=0;i<i2;i++){
//pixel[i+6400]=pal[cmem[i+655360]];
//pixel[i]=pal[cmem[i+655360]];
*lp=pal[*cp];
//*lp=pal[0];
i3++;
if (i3==640){cp-=640;i3=-640;}
cp++;
lp++;
}


goto screen_refreshed;
}//SCREEN 2 specific


//special refresh method required!
if (qbg_text_only){
qbg_width=qbg_width_in_characters*qbg_character_width;
qbg_height=qbg_height_in_characters*qbg_character_height;
}

long qbg_y_offset;
qbg_y_offset=0;
x=qbg_width; y=qbg_height;

//fix aspect ratio for full screen
if (full_screen){
x2=x/4; y2=y/3;
if (x2!=y2){//aspect incorrect!
if (x2>y2){
y=x2*3;
qbg_y_offset=(y-qbg_height)/2;
}
}
}

if ((qbg_program_window_width!=x)||(qbg_program_window_height!=y)||(full_screen_in_use!=full_screen)){
qbg_program_window_width=x; qbg_program_window_height=y;
screen = SDL_SetVideoMode(qbg_program_window_width, qbg_program_window_height, 32, SDL_SWSURFACE|(SDL_FULLSCREEN*full_screen));//|SDL_FULLSCREEN); SDL_SWSURFACE
pixel=(unsigned long*)screen->pixels;
full_screen_in_use=full_screen;
}




if (qbg_text_only){
unsigned char *cp,*cp2;
unsigned long *lp;
qbg_y_offset=qbg_y_offset*qbg_program_window_width;
i=SDL_GetTicks()&256;
i4=SDL_GetTicks()&128;
cp=qbg_visual_page_offset;
y2=0;
for (y=0;y<qbg_height_in_characters;y++){
x2=0;
for (x=0;x<qbg_width_in_characters;x++){
//draw the character
if (qbg_character_height==8){
cp2=&charset8x8[*cp][0][0];
}else{
if (qbg_character_height==16){
cp2=&charset8x16[*cp][0][0];
}else{//assume 14
cp2=&charset8x16[*cp][1][0];
}
}
if (qbg_character_width==16) z2=1; else z2=0;
//set the correct color
cp++;
c=*cp&0xF;//foreground col
c2=(*cp>>4)&7;//background col
c3=*cp>>7;//flashing?
if (c3&&i) c=c2;
i2=pal[c];
i3=pal[c2];
lp=pixel+y2*qbg_width_in_characters*qbg_character_width+x2+qbg_y_offset;
z=qbg_width_in_characters*qbg_character_width-qbg_character_width;
for (y3=0;y3<qbg_character_height;y3++){
for (x3=0;x3<qbg_character_width;x3++){
if (*cp2) *lp=i2; else *lp=i3;
if (z2){
if (x3&z2) cp2++;
}else{
cp2++;
}
lp++;
}
lp+=z;
}//y3,x3
//

//###DRAW CURSOR IF NECESSARY###
long cx,cy;
cx=qbg_cursor_x; cy=qbg_cursor_y;
if (qbg_visual_page!=qbg_active_page){
cx=qbg_cursor_x_previous[qbg_visual_page]; cy=qbg_cursor_y_previous[qbg_visual_page];
}

if (qbg_cursor_show&&i4&&((cx-1)==x)&&((cy-1)==y)){
long v1,v2;
unsigned char from_bottom;//bottom is the 2nd bottom scanline in width ?x25
unsigned char half_cursor;//if set, overrides all following values
unsigned char size;//if 0, no cursor is drawn, if 255, from begin to bottom
unsigned char begin;//only relevant if from_bottom was not specified
v1=qbg_cursor_firstvalue;
v2=qbg_cursor_lastvalue;
from_bottom=0;
half_cursor=0;
size=0;
begin=0;
//RULE: IF V2=0, NOTHING (UNLESS V1=0)
if (v2==0){
if (v1==0){size=1; goto cursor_created;}
goto cursor_created;//no cursor!
}
//RULE: IF V2<V1, FROM V2 TO BOTTOM
if (v2<v1){begin=v2; size=255; goto cursor_created;}
//RULE: IF V1=V2, SINGLE SCANLINE AT V1 (OR BOTTOM IF V1>=4)
if (v1==v2){
if (v1<=3){begin=v1; size=1; goto cursor_created;}
from_bottom=1; size=1; goto cursor_created;
}
//NOTE: V2 MUST BE LARGER THAN V1!
//RULE: IF V1>=3, CALC. DIFFERENCE BETWEEN V1 & V2
//                IF DIFF=1, 2 SCANLINES AT BOTTOM
//                IF DIFF=2, 3 SCANLINES AT BOTTOM
//                OTHERWISE HALF CURSOR
if (v1>=3){
if ((v2-v1)==1){from_bottom=1; size=2; goto cursor_created;}
if ((v2-v1)==2){from_bottom=1; size=3; goto cursor_created;}
half_cursor=1; goto cursor_created;
}
//RULE: IF V1<=1, IF V2<=3 FROM V1 TO V3 ELSE FROM V1 TO BOTTOM
if (v1<=1){
if (v2<=3){begin=v1;size=v2-v1+1; goto cursor_created;} 
begin=v1;size=255; goto cursor_created;
}
//RULE: IF V1=2, IF V2=3, 2 TO 3
//               IF V2=4, 3 SCANLINES AT BOTTOM
//               IF V2>=5, FROM 2 TO BOTTOM
//(assume V1=2)
if (v2==3){begin=2;size=2; goto cursor_created;}
if (v2==4){from_bottom=1; size=3; goto cursor_created;}
begin=2;size=255;
cursor_created:

if (half_cursor){
//half cursor
y3=qbg_character_height-1;
size=qbg_character_height/2;
c=*cp&0xF;//foreground col
i2=pal[c];
draw_half_curs:
lp=pixel+(y2+y3)*qbg_width_in_characters*qbg_character_width+x2+qbg_y_offset;
for (x3=0;x3<qbg_character_width;x3++){
*lp=i2;
lp++;
}
y3--;
size--;
if (size) goto draw_half_curs;
}else{
if (from_bottom){
//cursor from bottom
y3=qbg_character_height-1;
if (y3==15) y3=14;//leave bottom line blank in 8x16 char set
c=*cp&0xF;//foreground col
i2=pal[c];
draw_curs_from_bottom:
lp=pixel+(y2+y3)*qbg_width_in_characters*qbg_character_width+x2+qbg_y_offset;
for (x3=0;x3<qbg_character_width;x3++){
*lp=i2;
lp++;
}
y3--;
size--;
if (size) goto draw_curs_from_bottom;
}else{
//cursor from begin using size
if (begin<qbg_character_height){
y3=begin;
c=*cp&0xF;//foreground col
i2=pal[c];
if (size==255) size=qbg_character_height-begin;
draw_curs_from_begin:
lp=pixel+(y2+y3)*qbg_width_in_characters*qbg_character_width+x2+qbg_y_offset;
for (x3=0;x3<qbg_character_width;x3++){
*lp=i2;
lp++;
}
y3++;
size--;
if (size) goto draw_curs_from_begin;
}
}
}



}//draw cursor?






cp++;
x2=x2+qbg_character_width;
}
y2=y2+qbg_character_height;
}
goto screen_refreshed;
}//text only



if (qbg_mode==10){
//pal_mode10[0-1][0-8]
//long qbg_color_assign[256];//for modes with quasi palettes!
i2=SDL_GetTicks()&512;
if (i2) i2=1;

for (i=0;i<=3;i++){
pal[i]=pal_mode10[i2][qbg_color_assign[i]];

}
}

if (qbg_bytes_per_pixel==1){
unsigned char *cp;
unsigned long *lp;

cp=qbg_visual_page_offset;
lp=pixel+(qbg_y_offset*qbg_program_window_width);
i=0xA000*16;
i2=qbg_program_window_width*(qbg_program_window_height-qbg_y_offset*2);


for (i=0;i<i2;i++){
//pixel[i+6400]=pal[cmem[i+655360]];
//pixel[i]=pal[cmem[i+655360]];
*lp=pal[*cp];
cp++;
lp++;
}
}

screen_refreshed:
qbg_vertical_retrace_port=8;
SDL_UpdateRect(screen, 0, 0, 0, 0);


//update input
SDL_Event event;
    while ( SDL_PollEvent(&event) ) {

        switch (event.type) {

case SDL_KEYUP:
if (event.key.keysym.sym<65536){
keyon[event.key.keysym.sym]=0;
}
break;

case SDL_KEYDOWN:
/*
(&H417 in QB)
40:0017   2  Keyboard status bits; see Keyboard Shift Status Flags
40:0019   1  Current (accumulating) value of Alt+numpad pseudo-key input;
             normally 0.  When [Alt] is released, value is stored in
             keyboard buffer at 001e.
40:001a   2  Addr of keyboard buffer head (keystroke at that addr is next)
40:001c   2  Address of keyboard buffer tail
***range from 30 to 60 even number only***
***if head=tail then no data is available***
40:001e  32  Keyboard buffer.  BIOS stores keystrokes here (head and tail
             point to addresses from 041eH to 043dH inclusive).
***first byte is ASCII CHR or 0***
***second byte is the scancode***
*/
//"If the high 9 bits of the character are 0, then this maps to the equivalent ASCII character"
if (event.key.keysym.sym<65536){
keyon[event.key.keysym.sym]=1;
}

if ((event.key.keysym.sym==SDLK_KP_ENTER)||(event.key.keysym.sym==SDLK_RETURN)){
if (keyon[SDLK_RALT]||keyon[SDLK_LALT]){
full_screen++; if (full_screen==2) full_screen=0;
}
}

if ((event.key.keysym.sym==SDLK_BREAK)||(event.key.keysym.sym==SDLK_PAUSE)){
goto close_program;
}


if ((event.key.keysym.unicode&0xFF80)==0){
c=event.key.keysym.unicode&0x7F;
if (c){
//add to cyclic buffer
i=cmem[0x41a];
i2=cmem[0x41c];
//only add keypress if it fits in buffer
i3=i2+2;
if (i3==62) i3=30;
if (i!=i3){
cmem[0x400+i2]=c;
cmem[0x400+i2+1]=event.key.keysym.scancode;
cmem[0x41c]=i3;//fix tail location
goto gotkey;
}
}//c!=0
}else{
//printf("An International Character.\n");
goto gotkey;
}
//pass scancode only
i=cmem[0x41a];
i2=cmem[0x41c];
i3=i2+2;
if (i3==62) i3=30;
if (i!=i3){
cmem[0x400+i2]=0;
cmem[0x400+i2+1]=event.key.keysym.scancode;
cmem[0x41c]=i3;//fix tail location
goto gotkey;
}
gotkey:;
break;

case SDL_MOUSEMOTION:
//         printf("Mouse moved by %d,%d to (%d,%d)\n", 
//                event.motion.xrel, event.motion.yrel,
//                event.motion.x, event.motion.y);
break;

case SDL_MOUSEBUTTONDOWN:
//                printf("Mouse button %d pressed at (%d,%d)\n",
//                       event.button.button, event.button.x, event.button.y);
break;

case SDL_QUIT:
goto close_program;
}
}

goto subsystem_loop;

close_program:
stop_program=1;
qbevent=1;
SDL_WaitThread(thread, NULL);
SDL_ShowCursor(0);
SDL_FreeCursor(mycursor);
SDL_CloseAudio();
atexit(SDL_Quit);
exit(0);
}

