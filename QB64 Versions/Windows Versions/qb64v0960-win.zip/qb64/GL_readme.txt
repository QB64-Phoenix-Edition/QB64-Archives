QB64[GL] Version 0.960
======================

DO NOT:
 -Replace your primary QB64 folder with this (QB64-GL is still under early development and some parts are incomplete or have bugs)
 -Try to UPDATE this version of QB64
 -I'm sure there must be other things that go here...

YOU CANNOT:
 -Use joystick
 -Use RELATIVE mouse movement
 -Use PLAY, SOUND or BEEP
 -Use $CONSOLE (I think)

YOU CAN NOW:
 -Use _SNDPLAY/_SND...etc commands to play MP3, uncompressed WAV and _SNDRAW sounds
  (Sounds can really be 3D positioned thanks to OpenAL, use _SNDBAL)
 -Use TTF Fonts
 -Use TCP/IP networking

NEW COMMANDS:
 -_SNDOPENRAW function opens a new _SNDRAW channel, use _SNDCLOSE when finished
  handle = _SNDOPENRAW
  _SNDRAW leftsample, rightsample, handle
  _SNDCLOSE handle 'won't actually close until sound has finished playing

UNDER THE HOOD FACTS:
 -Check out the 'internal\c\parts' folder, all the 3rd party components ("parts") QB64
  relies on can be found in here in an organised fashion
 -"parts" need to be precompiled which makes the first "Run (F5)" take a while but things
  are just as fast (if not faster) than older versions of QB64 thereafter
 -Only "parts" which are needed are included. Watch how your executable file size changes
  as you add a reference to _SNDRAW, and how it grows again if you load an MP3. I'm not
  'proud' of the executable size, but it's much better than the old "include everything"
  approach.
 -For the fist time ever you can edit ALL of the internal source code of QB64, including
  3rd party libraries, and test the results in seconds. It's a 1,2,3 process...
  1) edit the .C source file of the thing you want to change
  2) run 'internal\c\purge_compiled_content.bat' which forces QB64 to rebuild that content
     (or, find the "part"'s .BAT file which rebuilds it and call the batch file directly)
  3) run your .BAS program
 -Where's the DLL files? Where's SDL? You can look but you won't find anything!

LINUX-- WHERE ART THOU?
 I did have a version of QB64-GL that ran in Linux but that was before another code
 restructure, the good news is that the code restructure will make it easier to provide
 a Linux version in the next release. If you want to help, take a look at the "parts"
 folder, particularly in the OS subfolders, you'll see that the Linux .SH files don't
 exist yet... maybe you can help me write some of those? Some of the parts have a file
 called 'config.h' which is OS specific and we need to write them for each OS we support
 or make then OS-independent based on other QB64 defines.

DEV. COMMENT
Wow! Time for a nap. I'm delighted that all the major components of QB64 are back in place,
though some are obviously more polished than others. This means I can properly begin
the porting to Android, Linux & MacOSX and start exploring how OpenGL graphics should
best be incorporated. It's painful to say this but SDL-based QB64 is still much better
than GL-based QB64, but I think QB64-GL will being to overtake SDL-QB64 later this year.