Unzip to your QBasic folder or a different folder or make a game folder like KONG and unzip files into it.

NOTE: This game requires graphics files created by the accompanying programs K1 and K2. K1 CHAIN's K2, so only run K1.bas. After K1.bas ends, Kong.bas is ready to play!
