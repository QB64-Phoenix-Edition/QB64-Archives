This folder contains the source code for the QB64 compiler(which includes the IDE) written in QB64 code

All other QB64 source files are written in C++ and can be found here: \internal\c\*.cpp