#if 1
#ifndef MINGW_HAS_DDRAW_H

#define MINGW_HAS_DDRAW_H 1
#define MINGW_DDRAW_VERSION	7
#endif
#else
#undef MINGW_HAS_DDRAW_H
#undef MINGW_DDRAW_VERSION
#endif
