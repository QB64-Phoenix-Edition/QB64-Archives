                           ****RoboRaider****
                           ****README.TXT****

                Robo Raider is Copyright 2004 by Kevin

                     >> Maximize to whole screen <<
             >>Print this off, it makes it easier to read<<

                            ---Contents---
                         
                        (I) Starting The Game
                       (II) Command Reference
                      (III) Introduction
                       (IV) Complete Controls
                        (V) Setting up the Game
                            Main Menu
                            Levelcodes
                       (VI) Playing the Game
                      

----------------------------------------------------------------------

                        (I) Starting The Game

     To start the game, locate the file you dowloaded the game to.
(1) Take the (RoboRaid.BAS) to you QBasic foled and open it from there.
(2) Locate the (RoboRaider) folder with the QBasic <Open> option, and
    open the (RoboRaid.BAS).

----------------------------------------------------------------------
                      
                   (II) Command Reference

  | SPACEBAR | ENTER | Arrow keys | F1 | Esc | Page Up | Page Down |

----------------------------------------------------------------------

                     (III) Introduction

     RoboRaider puts you in control of 6 different robots to explore 6 
different mission including 3 test of skills. Although it has limited 
graphics, it has a unfolding RPG game play that should prove 
interesting at most. So grab the keyboard, and take on this 
MiniRPG!
     PS: Be careful of Dr. Robo, he loves his robots, and will fire 
you if any harm comes to them. Pilot them with care!

     Features:
       
       320 x 200 Graphics screen size (At least its easy to read :P)

       16 Colors

       6 Robots (All are used)

       9 Levels plus a bonus to unlock

       xtrGRAPHICS(TM) Level 1 (Uses QBasic's graphic engine)
            {Classic Style Game}

       TPT(Third Person Top) Veiw

----------------------------------------------------------------------
                  
                  (IV) Complete Controls


                     Menu Controls:

            Highligh Menu Options = UP & DOWN Arrows
         Select/Go to next screen = Enter/Return
                        Help file = F1
                        Exit Game = Esc

                    Robot Controls: 

                        UP = UP Arrow
                      DOWN = DOWN Arrow
                      LEFT = LEFT Arrow
                     RIGHT = RIGHT Arrow
                    PageUp = Drill on*
                  PageDown = Drill off*

                  *In Mission 5 only. 

----------------------------------------------------------------------

                 (V) Setting up the Game

                     Main Menu:

           ---------------------------------------
     A---> | RoboRaider >>Test1>>                |
           |                                     |
	   |            >>Start>>                |
           |            >>Levelcodes<<           |
           |            >>Credits<<              |
           |                                     |
           | Press SPACEBAR to select            |
     B---> | F1 = Help   Esc = Exit              |
           ---------------------------------------

       (A) Menu Title: This tells you where you are at.
       (Start) Takes you to the level displayed on the Menu Title.
       (Levelcodes) Since there is no save feature, you use the                  
          passwords (collect after defeating a level) to get back 
          where you left off.
       (Credits) Takes you to my very short credits screen.
       (B) Command Highlights: Gives you basic commands.

                 
                   Levelcodes:

        When you get a levelcode its normaly like this after a
      copleted level:

          This level's code is: TEST001
          Next level's code it: TEST002
 
       If you exit the whole game and went back to the Levelcodes
     and typed the first one, it gives you the level
     you just did. But if you type the bottom one, it gives you
     the next level. 
       If you stay with the game after each level, the next level
     is loaded up automaticaly.

---------------------------------------------------------------------

                       (VI) Playing the Game

     You start the game with three tests. To complete the first two
test you just simply guide the robot through the levels dodging the
obsticals. But the second one requiers picking up small items. This 
is done by getting the center of the item between the two fingers of the
robot's grip. It takes a little practic at the most, its very simple.
     Sorry, there was to be a (.EXE) to make it easy to use all the
time, but the file is to big. Enjoy my game anyway!!

EMAIL: Rattrapmax6@aol.com
WEBPAGE: http://hometown.aol.com/rattrapmax6/index.html