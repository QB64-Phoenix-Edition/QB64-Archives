#!/bin/sh
Pause()
{
OLDCONFIG=`stty -g`
stty -icanon -echo min 1 time 0
dd count=1 2>/dev/null
stty $OLDCONFIG
}
echo "QB64 Setup"
echo ""
echo "Make sure the following packages are installed before continuing:"
echo "(SDL packages should be version 1.2 or 1.2.???)"
echo "    libsdl-dev"
echo "    libsdl-image-dev"
echo "    libsdl-mixer-dev"
echo "    libsdl-net-dev"
echo "    libsdl-ttf-dev (may report as version 2.0)"
echo "    timidity (only required if playing MIDI files)"
echo ""
echo "Press any key to continue..."
Pause
echo ""
echo "Checking for existance of 'g++'"
echo "****************************************"
g++
echo "****************************************"
echo "The above line should read 'g++: no input files'. If it doesn't you need to install the g++ compiler before continuing."
echo ""
echo "Press any key to continue..."
Pause
echo ""
echo "Creating 'qb64'..."
echo "(Notes: Warnings can be ignored. This process could take a minute or so.)"
cp ./internal/source/* ./internal/temp/
cd ./internal/c
g++ -c -w -Wall libqbx.cpp -o libqbx_lnx.o  `sdl-config --cflags`
g++ `sdl-config --cflags --libs` -lSDL_mixer -lSDL_ttf -lSDL_net -lSDL_image -lX11 libqbx_lnx.o qbx.cpp -o ../../qb64
cd ../..
echo ""
echo "Setup complete!"
echo ""
echo "Launching 'qb64'..."
./qb64
echo ""
echo "Note: 'qb64' is located in same folder as this setup program."
echo "Press any key to exit..."
Pause

