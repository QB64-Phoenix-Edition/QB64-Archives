#!/bin/sh
Pause()
{
OLDCONFIG=`stty -g`
stty -icanon -echo min 1 time 0
dd count=1 2>/dev/null
stty $OLDCONFIG
}
echo "Recompiling..."
cd ../c
g++ `sdl-config --cflags --libs` -lSDL_mixer -lSDL_ttf -lSDL_net -lSDL_image -lX11 libqbx_lnx.o qbx.cpp -o '../../qb64y62'
echo "Press ENTER to exit..."
Pause
