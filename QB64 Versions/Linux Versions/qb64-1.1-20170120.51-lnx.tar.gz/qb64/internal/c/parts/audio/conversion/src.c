#ifndef DEPENDENCY_AUDIO_CONVERSION
//Stubs:
//(none required)
#else

#ifdef QB64_BACKSLASH_FILESYSTEM
 #include "src\\speex_resampler.h"
#else
 #include "src/speex_resampler.h"
#endif

#endif
