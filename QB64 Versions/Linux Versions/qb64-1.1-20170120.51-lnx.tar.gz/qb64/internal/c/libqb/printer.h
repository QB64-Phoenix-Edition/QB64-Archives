//forward references
void sub__printimage(int32 i);
