#include <stdio.h>
#include <math.h>
#include <time.h>
#include <iostream>
#include <fstream>
#include <SDL.h>
#include <SDL_ttf.h>
int main(int argc,char* argv[]){
system("cp ./common/freetype/buildA/libfreetype.dylib ./common/freetype/libfreetype.dylib");
exit(0);
}