These files are auto-generated each time 'gl.h' is parsed.
