/* Routines by Luke
 * The actual code is in luke_mods.cpp
 * Write me at <flukiluke@gmail.com> if I broke something
 */
void sub__keyclear(int32 buf, int32 passed);
