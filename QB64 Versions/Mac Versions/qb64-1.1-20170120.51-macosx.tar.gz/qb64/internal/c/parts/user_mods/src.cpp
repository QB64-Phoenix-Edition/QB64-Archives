#ifndef DEPENDENCY_USER_MODS
//No stubs required
#else
#include "include/user_mods.h"
#endif
